# HDF v3 Evidence Provenance: Confluence bundle

## Which page file to use

| File | Use it when |
|---|---|
| `hdf-v3-provenance.confluence.wiki` | Pasting by hand: **Insert > Markup > Confluence wiki** (Cloud or Data Center). No `ac:`/`ri:` tags, so nothing to trip on `:`. |
| `hdf-v3-provenance.confluence.xml` | REST API or a storage/source editor that accepts Confluence storage format (a fragment; Confluence supplies the `ac:`/`ri:` namespaces). |
| `hdf-v3-provenance.confluence.full.xml` | Any XML validator or pipeline tool: same content with the namespaces declared. Not for pasting into Confluence. |

Attach these to the page first: `hdf-v3-1-target-array.png` `hdf-v3-2-system-document.png` `hdf-v3-3-correlation.png` 

## Publish with the script (creates or updates the page and its attachments)

```bash
export CONFLUENCE_URL=https://confluence.agency.gov      # Cloud: https://yoursite.atlassian.net/wiki
export CONFLUENCE_SPACE=SECAUTO
export CONFLUENCE_TOKEN=...                              # Data Center PAT, or Cloud API token
# export CONFLUENCE_USER=you@agency.gov                  # Cloud only
export CONFLUENCE_TITLE="HDF v3 Evidence Provenance"
export PAGE_FILE=hdf-v3-provenance.confluence.wiki                   # or hdf-v3-provenance.confluence.xml
DRY_RUN=1 ./publish-confluence.sh hdf-v3-1-target-array.png hdf-v3-2-system-document.png hdf-v3-3-correlation.png
./publish-confluence.sh hdf-v3-1-target-array.png hdf-v3-2-system-document.png hdf-v3-3-correlation.png
```

With a `.wiki` page file the script asks Confluence to convert it to storage format, so Confluence writes the markup itself.
Needs bash, curl and jq.

## Mermaid

The `.mmd` sources (and the copies inside the page files) are plain ASCII with no `:`, `;`, `<`, `>` or `&` in label text,
so they paste cleanly into Confluence Mermaid macros, including older Mermaid versions. The page itself shows PNG diagrams and needs no Mermaid app.
