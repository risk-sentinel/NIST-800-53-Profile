# HDF and OSCAL Automation Coverage: Confluence bundle

## Option 1: script (recommended)

```bash
export CONFLUENCE_URL=https://confluence.agency.gov      # Cloud: https://yoursite.atlassian.net/wiki
export CONFLUENCE_SPACE=SECAUTO
export CONFLUENCE_TOKEN=...                              # Data Center PAT, or Cloud API token
# export CONFLUENCE_USER=you@agency.gov                  # Cloud only
# export CONFLUENCE_PARENT=123456                        # optional parent page ID (first publish)
DRY_RUN=1 ./publish-confluence.sh                        # preview
./publish-confluence.sh                                  # create or update the page + attachments
```

Re-running updates the same page (matched by space + title) and replaces the attachments.
Needs bash, curl and jq.

## Option 2: by hand

1. Create the page and attach `control-coverage-venn.png`, `control-coverage-hdf-sources.png`,
   `control-coverage-poam-loop.png` and `control-coverage.csv`.
2. Open the page's source/storage editor and paste `control-coverage.confluence.xml`.

## Files

| File | Use |
|---|---|
| control-coverage.confluence.xml | Page body in Confluence storage format (native tables, image and CSV attachments, expand with all 300 controls) |
| control-coverage.md | Same content as Markdown (GitLab/GitHub, or the Confluence Markdown macro) |
| *.png | Attachments the page displays |
| *.svg | Vector versions for slides or print |
| control-coverage.csv | All 300 Rev 5 base controls with region, OSCAL tier, HDF sources and basis |
| publish-confluence.sh | Create-or-update script (Confluence REST API v1) |
