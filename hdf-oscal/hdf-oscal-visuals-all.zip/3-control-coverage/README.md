# HDF and OSCAL Automation Coverage: Confluence bundle

## Which page file to use

| File | Use it when |
|---|---|
| `control-coverage.confluence.wiki` | Pasting by hand: **Insert > Markup > Confluence wiki** (Cloud or Data Center). No `ac:`/`ri:` tags, so nothing to trip on `:`. |
| `control-coverage.confluence.xml` | REST API or a storage/source editor that accepts Confluence storage format (a fragment; Confluence supplies the `ac:`/`ri:` namespaces). |
| `control-coverage.confluence.full.xml` | Any XML validator or pipeline tool: same content with the namespaces declared. Not for pasting into Confluence. |

Attach these to the page first: `control-coverage-venn.png` `control-coverage-hdf-sources.png` `control-coverage-poam-loop.png` `control-coverage.csv` 

## Publish with the script (creates or updates the page and its attachments)

```bash
export CONFLUENCE_URL=https://confluence.agency.gov      # Cloud: https://yoursite.atlassian.net/wiki
export CONFLUENCE_SPACE=SECAUTO
export CONFLUENCE_TOKEN=...                              # Data Center PAT, or Cloud API token
# export CONFLUENCE_USER=you@agency.gov                  # Cloud only
export CONFLUENCE_TITLE="HDF and OSCAL Automation Coverage"
export PAGE_FILE=control-coverage.confluence.wiki                   # or control-coverage.confluence.xml
DRY_RUN=1 ./publish-confluence.sh control-coverage-venn.png control-coverage-hdf-sources.png control-coverage-poam-loop.png control-coverage.csv
./publish-confluence.sh control-coverage-venn.png control-coverage-hdf-sources.png control-coverage-poam-loop.png control-coverage.csv
```

With a `.wiki` page file the script asks Confluence to convert it to storage format, so Confluence writes the markup itself.
Needs bash, curl and jq.
