# HDF and OSCAL Automation Coverage

Each format automates evidence for a different set of controls, and each works without the other. HDF reaches the technical controls through InSpec profiles and scanner mappings. OSCAL reaches the documentary and management controls through its models, including POA&M. Together they produce automated evidence for 166 of the 300 active base controls, with 12 counted by both. OSCAL adds a layer HDF has no equivalent for: it can validate the written claim for every control in the baseline, including the ones no tool can test.

## Summary

| Count | Meaning |
|---|---|
| 166 of 300 | Base controls with automated evidence from either format (55%) |
| 108 | HDF: 105 from mapped checks, 3 from its document types |
| 70 | OSCAL: 49 where the document is the evidence, 21 inherited (cloud-hosted) |
| 12 | Counted by both: HDF tests and OSCAL tracks |
| 300 | Claims OSCAL can validate: completeness, references, ODP values, freshness |
| 134 | Without automated evidence: human or attested |

## Where each format reaches

HDF's circle is measured: every control that at least one published mapping or InSpec profile tags. OSCAL reaches in three tiers. Its circle holds the controls where an OSCAL document is the evidence, plus physical controls inherited from a leveraged cloud authorization (the dashed subset). The frame is the third tier: every control's written response can be validated automatically, even where the evidence behind it is human.

![Venn diagram of HDF and OSCAL control coverage](control-coverage-venn.png)

*Counts are Rev 5 base controls; an enhancement tag such as AC-2(1) counts toward AC-2. \*SI-1 lands in the overlap because the Docker CIS profile tags it. The inherited subset assumes a system hosted on a FedRAMP-authorized cloud whose authorization provides the PE controls; on-premises, those move outside the circles. Validation proves a claim is complete, consistent and current, not that the control is implemented.*

| Region | Controls | Which |
|---|---|---|
| Both | 12 | CA-2, CA-3, CA-5, CA-7, CA-9, CM-8, CM-9, CP-2, RA-5, RA-7, SI-1, SI-2 |
| HDF only | 96 | By family: SC 20, AC 16, AU 12, SI 10, IA 8, CM 7, SA 6, CP 4, IR 4, SR 4, MA 2, MP 2, RA 1 |
| OSCAL only, evidence | 37 | AC-1, AT-1, AU-1, CA-1, CA-6, CA-8, CM-1, CP-1, CP-4, IA-1, IR-1, IR-3, IR-8, MA-1, MP-1, PE-1, PL-1, PL-2, PL-4, PL-7, PL-8, PL-10, PL-11, PM-1, PM-4, PM-5, PS-1, PT-1, RA-1, RA-2, SA-1, SA-4, SA-5, SA-9, SC-1, SR-1, SR-2 |
| OSCAL only, inherited (cloud-hosted) | 21 | PE-2, PE-3, PE-4, PE-5, PE-6, PE-8, PE-9, PE-10, PE-11, PE-12, PE-13, PE-14, PE-15, PE-16, PE-17, PE-18, PE-19, PE-20, PE-21, PE-22, PE-23 |
| Outside both circles | 134 | By family: PM 29, SC 26, SI 10, PS 8, PT 7, SA 7, AC 6, SR 6, CP 5, MP 5, AT 4, CM 4, IA 4, MA 4, RA 4, AU 2, IR 2, PL 1 |

## What drives HDF's reach

InSpec profiles carry the most control coverage, and AWS Config's rule set is the widest converter mapping. The sources overlap heavily: together they reach 105 base controls, not the sum of the bars.

![Base controls reached by each HDF source](control-coverage-hdf-sources.png)

| HDF source | Base controls | Basis |
|---|---|---|
| InSpec profiles (MITRE SAF) | 83 | tag nist on controls in 44 published baselines |
| AWS Config | 56 | 788 managed rules mapped to NIST (Rev 4 and 5) |
| Checkov (IaC) | 41 | check_id to CCI to NIST |
| ScoutSuite | 25 | 139 cloud rules |
| CWE (SAST/SCA) | 17 | 404 CWE IDs (Semgrep, Sonar, Snyk and others) |
| Nessus | 14 | 86 plugin families |
| Hipcheck (supply chain) | 8 | 9 analyses mapped to the SR family |
| OWASP (DAST) | 7 | Top 10 mapped to NIST (ZAP, Burp) |
| Nikto | 5 | 8,941 checks |

## POA&M: automated management, not just a list

An OSCAL POA&M risk is a record with a lifecycle: `status` (open, investigating, remediating, deviation-requested, deviation-approved, closed), a `deadline`, `remediations` with milestone tasks, and a `risk-log` of dated status changes. Fed by HDF results on every run, it tracks RA-5 and SI-2 remediation windows without a spreadsheet. HDF can also manage the same loop alone through Amendments.

![POA&M remediation loop](control-coverage-poam-loop.png)

*This loop is why CA-5, RA-5, RA-7 and SI-2 sit in the overlap. HDF detects and re-tests; the POA&M carries deadline, owner, milestones and an auditable status history. HDF Amendments have no permanent entries: every override requires `expiresAt`.*

## Coverage by family

HDF carries the technical families (AC, AU, CM, IA, SC, SI). OSCAL carries CA, PL and the -1 policy control in every family, and PE through inheritance on a cloud-hosted system. PS, PT and most of PM stay with people, with their claims still validated.

| Family | Active base | HDF | OSCAL evidence | OSCAL inherited | Either | Either % |
|---|---|---|---|---|---|---|
| AC | 23 | 16 | 1 | 0 | 17 | 74% |
| AT | 5 | 0 | 1 | 0 | 1 | 20% |
| AU | 15 | 12 | 1 | 0 | 13 | 87% |
| CA | 8 | 5 | 8 | 0 | 8 | 100% |
| CM | 14 | 9 | 3 | 0 | 10 | 71% |
| CP | 12 | 5 | 3 | 0 | 7 | 58% |
| IA | 13 | 8 | 1 | 0 | 9 | 69% |
| IR | 9 | 4 | 3 | 0 | 7 | 78% |
| MA | 7 | 2 | 1 | 0 | 3 | 43% |
| MP | 8 | 2 | 1 | 0 | 3 | 38% |
| PE | 22 | 0 | 1 | 21 | 22 | 100% |
| PL | 8 | 0 | 7 | 0 | 7 | 88% |
| PM | 32 | 0 | 3 | 0 | 3 | 9% |
| PS | 9 | 0 | 1 | 0 | 1 | 11% |
| PT | 8 | 0 | 1 | 0 | 1 | 12% |
| RA | 9 | 3 | 4 | 0 | 5 | 56% |
| SA | 17 | 6 | 4 | 0 | 10 | 59% |
| SC | 47 | 20 | 1 | 0 | 21 | 45% |
| SI | 22 | 12 | 2 | 0 | 12 | 55% |
| SR | 12 | 4 | 2 | 0 | 6 | 50% |
| All | 300 | 108 | 49 | 21 | 166 | 55% |

## How this was counted

- **Universe:** the 300 active base controls in NIST's official SP 800-53 Rev 5 OSCAL catalog (24 withdrawn controls excluded).
- **HDF, mapped (105):** the union of NIST IDs in the `hdf-mappings` tables for AWS Config, ScoutSuite, Nessus, Nikto, Checkov, CWE, OWASP and Hipcheck, plus `tag nist` on controls in 44 of the 55 MITRE SAF InSpec baselines that could be cloned (11 listed on the SAF site were private or moved). Rev 4 tags count where the base control is still active in Rev 5.
- **HDF, structural (+3):** CA-2 from the Plan document, CA-5 from Amendments of type `poam`, RA-7 from waivers and risk adjustments. CA-7, CM-8, CA-3 and SR-4 were already mapped.
- **OSCAL, evidence (49):** my classification of where the document itself is the evidence: SSP (PL-2, PL-8 boundary and architecture, RA-2 categorization, CA-9 internal connections), profile (PL-10, PL-11), SAP and SAR (CA-2, CA-7, CA-8 pen testing, CP-4 and IR-3 exercise results), POA&M (CA-5, PM-4, RA-7, and the remediation windows in RA-5 and SI-2), authorization actions (CA-6), interconnections (CA-3), leveraged authorizations (SA-9), inventory (CM-8, PM-5), component definitions (SA-4), and hashed plans in back-matter with review dates (the 20 -1 controls, PL-4, PL-7, CP-2, IR-8, CM-9, SA-5, SR-2).
- **OSCAL, inherited (21):** PE-2 through PE-23, marked `inherited` with a `provided-uuid` pointing at what the cloud provider's authorization exports. This holds for cloud-hosted systems only.
- **OSCAL, validated (300):** not counted as coverage. Every baselined control's response can be checked for a matching statement, resolvable component, role and evidence references, allowed ODP values, and unexpired observations.
- **What a count means:** at least one tool can produce evidence tagged to the control. It does not mean every part of the control is satisfied; most mappings cover one part (for example AC-2(j)).

The full 300-control classification is in [control-coverage.csv](control-coverage.csv).

## Sources

- [mitre/hdf-libs](https://github.com/mitre/hdf-libs)
- [MITRE SAF validation content](https://saf.mitre.org/content/?pillar=validate)
- [NIST SP 800-53 Rev 5 OSCAL catalog](https://github.com/usnistgov/oscal-content)
- [OSCAL v1.2.3 POA&M model](https://pages.nist.gov/OSCAL-Reference/models/v1.2.3/plan-of-action-and-milestones/json-outline/)
- [HDF v3.7.0 specification](https://mitre.github.io/hdf-libs/docs/specification/hdf-specification.html)
