# HDF v3 Evidence Provenance: Confluence bundle

Mermaid sources are plain ASCII with no characters Confluence entity-encodes, so they paste
cleanly into a Mermaid macro. The page itself shows the PNG diagrams and needs no Mermaid app.

## Publish with the script

```bash
export CONFLUENCE_URL=https://confluence.agency.gov      # Cloud: https://yoursite.atlassian.net/wiki
export CONFLUENCE_SPACE=SECAUTO
export CONFLUENCE_TOKEN=...                              # Data Center PAT, or Cloud API token
# export CONFLUENCE_USER=you@agency.gov                  # Cloud only
export CONFLUENCE_TITLE="HDF v3 Evidence Provenance"
export PAGE_FILE=hdf-v3-provenance.confluence.xml
DRY_RUN=1 ./publish-confluence.sh hdf-v3-1-target-array.png hdf-v3-2-system-document.png hdf-v3-3-correlation.png
./publish-confluence.sh hdf-v3-1-target-array.png hdf-v3-2-system-document.png hdf-v3-3-correlation.png
```

## By hand

Create the page, attach `hdf-v3-1-target-array.png` `hdf-v3-2-system-document.png` `hdf-v3-3-correlation.png` , then paste `hdf-v3-provenance.confluence.xml` into the source editor.
