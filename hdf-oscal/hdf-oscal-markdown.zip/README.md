# HDF and OSCAL visuals: Markdown with Mermaid

| File | Content |
|---|---|
| hdf-v3-provenance.md | HDF v3 target array, System document, Results-to-System correlation (3 Mermaid flowcharts) |
| oscal-provenance.md | OSCAL metadata, control responses, back-matter, SSP-to-SAR assessment chain (4 Mermaid flowcharts) |
| control-coverage.md | Statement-part coverage of NIST SP 800-53 Rev 5 by HDF and OSCAL, with a per-converter reach chart covering all 47 hdf-libs converters plus saf CLI prowler2hdf, and a table of tools that reach HDF through a standard format (Mermaid venn-beta, pie, xychart-beta, flowchart) |
| control-coverage-parts.csv | All 1,749 statement parts: HDF mechanisms that reach each part, OSCAL tier and basis, region, part text |
| control-coverage-base-controls.csv | The earlier base-control view (300 controls) |
| mermaid/ | Every diagram as a standalone .mmd file |
| tools/ | wcag_mermaid.py (adds accTitle/accDescr and a generated text description after every diagram), contrast.py (WCAG contrast check of Mermaid colors), mmd_safe.py (Confluence-safe label check) |

## Accessibility (WCAG 2.1 AA)

- 1.1.1 Non-text content: every diagram is followed by a "Text description of the diagram above" list generated from the
  diagram source. Flowcharts, pie and bar charts also carry accTitle and accDescr, which Mermaid renders as an SVG title,
  desc and aria-labelledby. venn-beta has no accessibility keywords, so its text description is the alternative.
- 1.3.1 Info and relationships: one H1 per file, H2 sections with no skipped levels, tables with header rows.
- 1.4.1 Use of color: no instruction relies on color; groups and connections are labeled in text.
- 1.4.3 and 1.4.11 Contrast: node text at least 4.5:1, node borders and chart marks at least 3:1 against white, pie labels
  white on fully opaque slices (at least 6.2:1), bar segments at least 3:1 against the background and against the segment next to them.
- 2.4.4 Link purpose: every link names its destination.
- Abbreviations are expanded in a Terms section in each file.
- Re-run after edits: python3 tools/wcag_mermaid.py *.md  (idempotent), then python3 tools/contrast.py mermaid/*.mmd

Mermaid notes: labels are plain ASCII with no colons, semicolons, angle brackets or ampersands. Colons that remain are
Mermaid syntax (classDef/style, accTitle/accDescr, venn sizes, pie values, init directives). venn-beta needs a recent
Mermaid 11 release. Page language (WCAG 3.1.1) is set by the host page, not the Markdown.
