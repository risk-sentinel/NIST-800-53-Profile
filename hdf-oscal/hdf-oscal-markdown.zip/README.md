# HDF and OSCAL visuals: Markdown with Mermaid

| File | Content |
|---|---|
| hdf-v3-provenance.md | HDF v3 target array, System document, Results-to-System correlation (3 Mermaid flowcharts) |
| oscal-provenance.md | OSCAL metadata, control responses, back-matter, SSP-to-SAR assessment chain (4 Mermaid flowcharts) |
| control-coverage.md | Statement-part coverage of NIST SP 800-53 Rev 5 by HDF and OSCAL (Mermaid venn-beta, pie, xychart-beta, flowchart) |
| control-coverage-parts.csv | All 1,749 statement parts: HDF sources, OSCAL tier and basis, region, part text |
| control-coverage-base-controls.csv | The earlier base-control view (300 controls) |
| mermaid/ | Every diagram as a standalone .mmd file |

Mermaid notes: labels are plain ASCII with no colons, semicolons, angle brackets or ampersands. Colons that remain are
Mermaid syntax (classDef/style, venn sizes, pie values, init directives). venn-beta needs a recent Mermaid 11 release.
