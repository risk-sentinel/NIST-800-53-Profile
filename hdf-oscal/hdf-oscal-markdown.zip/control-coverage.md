# HDF and OSCAL Automation Coverage

Coverage of every statement part in NIST SP 800-53 Rev 5: 1749 parts across the 1014 active controls and enhancements
(each lettered item such as AC-2 d.3 is one part; a control or enhancement with no lettered items is one part).
HDF and OSCAL each work on their own. HDF proves how the system is configured; OSCAL records the claim, its evidence and its
parameters. Together they give 852 parts (49%) automated evidence, and OSCAL can validate the
organization-defined parameter (ODP) values in 486 of the remaining parts.

## Summary

| Measure | Parts | Share |
|---|---|---|
| Automated evidence from HDF or OSCAL | 852 | 49% |
| HDF (explicit part tag, single-part control, or HDF document type) | 465 | 27% |
| HDF counting control-level tags too | 591 | 34% |
| OSCAL evidence (document, record or inheritance) | 454 | 26% |
| Both HDF and OSCAL evidence | 67 | 4% |
| No evidence, but OSCAL validates the ODP value | 486 | 28% |
| Neither: evidence stays human or attested | 411 | 23% |

```mermaid
%%{init: {"themeVariables": {"pie1": "#009683", "pie2": "#5b8f5a", "pie3": "#b4541a", "pie4": "#c9a24a", "pie5": "#b8c1c8", "pieStrokeColor": "#ffffff"}}}%%
pie showData
  title All 1749 statement parts
  "HDF only" : 398
  "HDF and OSCAL" : 67
  "OSCAL evidence only" : 387
  "OSCAL ODP check only" : 486
  "Neither" : 411
```

## Where each format reaches

The circles are area-proportional. OSCAL evidence and ODP validation do not overlap by construction: a part counts as an
ODP check only when OSCAL has no stronger evidence for it.

```mermaid
venn-beta
  title Statement parts with automated evidence or checks
  set HDF["HDF 465"]:465
  set OSCAL["OSCAL evidence 454"]:454
  set ODP["ODP validated 715"]:715
  union HDF,OSCAL["67"]:67
  union HDF,ODP["229"]:229
  union OSCAL,ODP:0
  union HDF,OSCAL,ODP:0
  style HDF fill:#009683
  style OSCAL fill:#b4541a
  style ODP fill:#8a6d1a
```

| OSCAL tier | Parts | What makes it automatable |
|---|---|---|
| Evidence | 261 | The OSCAL document is the evidence: SSP, profile, SAP, SAR, POAM, authorization actions, leveraged authorizations, inventory, hashed plans in back-matter |
| Documentary | 116 | The part asks for a record (document, define, designate, review and update, maintain a list or plan): back-matter resource with hash, metadata dates, responsible role |
| Inherited | 77 | PE parts marked inherited with provided-uuid pointing at a leveraged cloud authorization (cloud-hosted systems only) |
| ODP validated | 715 | The part has an organization-defined parameter: the value lives in SSP set-parameters and can be checked against profile constraints and against tool settings such as InSpec inputs or AWS Config rule parameters |

## What drives HDF's reach

HDF converters reach NIST in three ways. Content converters pass through whatever NIST references the scanner content carries;
mapping-table converters look the finding up in a table shipped with hdf-mappings; default-tag converters stamp every finding
with a fixed control.

| How the converter tags | Converters | Where the NIST reference comes from |
|---|---|---|
| Content passthrough | InSpec; CKL, CKLB, XCCDF results (STIG CCIs); OpenSCAP and SCAP; ASFF (Prowler, Security Hub); OSCAL SAR and SSP; Splunk and legacy HDF | The benchmark or compliance content itself: InSpec tag nist, STIG CCI to NIST, ComplianceAsCode references, Prowler requirement IDs |
| Mapping table | AWS Config, Checkov, ScoutSuite, Nessus (plugin families), Nikto, Hipcheck; OWASP category for Netsparker, SonarQube, Semgrep | hdf-mappings data files |
| CWE table (17 converters) | Burp Suite, ZAP, Fortify, Semgrep, Snyk, SonarQube, Veracode, GitLab, gosec, KICS, JFrog Xray, NeuVector, DefectDojo, Dependency-Track, CycloneDX, SARIF, Netsparker | CWE ID on the finding, through the 404-entry CWE to NIST table; SA-11 and RA-5 when no CWE maps |
| Fixed default (11 converters) | Grype, Trivy, Conveyor, DBProtect, Defender for Endpoint, Secure Score, JUnit (SA-11, RA-5); Twistlock, Prisma (SI-2, RA-5); Ion Channel (CM-8); TruffleHog (IA-5(7)) | A constant in the converter |

```mermaid
%%{init: {"themeVariables": {"xyChart": {"plotColorPalette": "#9fd3ca, #00796a"}}}}%%
xychart-beta horizontal
  title "Statement parts by HDF source"
  x-axis ["OpenSCAP SCAP", "InSpec", "AWS Config", "Prowler ASFF", "Checkov", "ScoutSuite", "Nessus plugins", "CWE converters 17", "Default tag 11", "Hipcheck", "OWASP", "Nikto"]
  y-axis "Statement parts" 0 --> 300
  bar [297, 285, 277, 257, 116, 91, 57, 32, 24, 21, 16, 12]
  bar [174, 196, 119, 255, 50, 17, 3, 12, 1, 2, 3, 2]
```

Dark bars: parts the tag names. Light extension: further parts under a control-level tag from that source.

| Source | Parts named by the tag | Parts under a control-level tag only |
|---|---|---|
| OpenSCAP / SCAP (ComplianceAsCode) | 174 | 123 |
| InSpec profiles (MITRE SAF) | 196 | 89 |
| AWS Config | 119 | 158 |
| Prowler / Security Hub (ASFF) | 255 | 2 |
| Checkov (IaC) | 50 | 66 |
| ScoutSuite | 17 | 74 |
| Nessus | 3 | 54 |
| CWE-based converters (17) | 12 | 20 |
| Default-tag scanners (11) | 1 | 23 |
| Hipcheck (supply chain) | 2 | 19 |
| OWASP (DAST) | 3 | 13 |
| Nikto | 2 | 10 |

Control-level tags (for example "SI-2" or "SA-11" with no letter) do not say which part the check proves, so they are not counted
in the HDF total. That is why the default-tag and CWE converters, which mostly emit control-level tags, add little at part level
even though they run in most pipelines. Tagging to the part letter in profiles and mapping tables would move them over.

| How HDF reaches a counted part | Parts |
|---|---|
| Tag names the whole control or enhancement, which has a single part | 235 |
| Tag names the part letter, Rev 5 | 147 |
| Tag names the part letter, revision not stated | 55 |
| Tag names the part letter, Rev 4 only (letter may have shifted in Rev 5) | 18 |
| HDF document type (Plan for CA-2, Amendments for CA-5 and RA-7) | 10 |

Not yet counted, because the content is not public or not in these repositories: the DISA STIG library beyond the InSpec and
ComplianceAsCode benchmarks (Windows, network devices, applications), Security Hub's own NIST 800-53 Rev 5 standard, Nessus
compliance audit files, Azure and GCP NIST mappings, and 11 SAF InSpec profiles that could not be cloned. Each would add reach.

## POAM: automated management, not just a list

An OSCAL POAM risk has a status lifecycle (open, investigating, remediating, deviation-requested, deviation-approved, closed),
a deadline, remediation tasks of type milestone, and a risk-log of dated status changes. Fed by HDF results on every run, it
tracks the remediation windows in RA-5 d and SI-2 c. HDF can run a simpler version on its own with Amendments of type poam,
waivers and risk adjustments, each with a required expiresAt.

```mermaid
flowchart LR
  r1["HDF result - check tagged RA-5 d or SI-2 c - status failed"] --> r2["SAR finding - hdf convert --to oscal-sar - state not-satisfied"]
  r2 --> r3["POAM item and risk - status open - deadline - remediation tasks, type milestone"]
  r3 --> r4["risk-log entries - status-change remediating, or deviation-requested then deviation-approved"]
  r4 --> r5["Rescan - HDF result passed - risk status closed"]
  r5 -.->|every pipeline run| r1
  classDef hdf fill:#e0f2ef,stroke:#009683,color:#17212a
  classDef oscal fill:#f8e9df,stroke:#b4541a,color:#17212a
  class r1,r5 hdf
  class r2,r3,r4 oscal
```

## Coverage by family

| Family | Parts | HDF | OSCAL evidence | Either | ODP validated only | Neither |
|---|---|---|---|---|---|---|
| AC | 214 | 91 | 20 | 107 | 71 | 36 |
| AT | 29 | 0 | 8 | 8 | 12 | 9 |
| AU | 84 | 50 | 15 | 58 | 20 | 6 |
| CA | 57 | 16 | 37 | 40 | 6 | 11 |
| CM | 108 | 45 | 37 | 64 | 30 | 14 |
| CP | 82 | 27 | 29 | 44 | 13 | 25 |
| IA | 96 | 46 | 7 | 52 | 26 | 18 |
| IR | 77 | 7 | 22 | 29 | 20 | 28 |
| MA | 57 | 7 | 12 | 19 | 14 | 24 |
| MP | 35 | 2 | 8 | 10 | 13 | 12 |
| PE | 83 | 2 | 83 | 83 | 0 | 0 |
| PL | 46 | 0 | 39 | 39 | 3 | 4 |
| PM | 98 | 5 | 47 | 51 | 10 | 37 |
| PS | 45 | 0 | 13 | 13 | 11 | 21 |
| PT | 42 | 0 | 7 | 7 | 18 | 17 |
| RA | 48 | 12 | 13 | 21 | 12 | 15 |
| SA | 185 | 14 | 28 | 42 | 79 | 64 |
| SC | 175 | 81 | 9 | 88 | 54 | 33 |
| SI | 151 | 58 | 7 | 63 | 55 | 33 |
| SR | 37 | 2 | 13 | 14 | 19 | 4 |
| All | 1749 | 465 | 454 | 852 | 486 | 411 |

## How this was counted

- Universe: every leaf statement item of the 1014 active controls and enhancements in NIST's official SP 800-53 Rev 5 OSCAL catalog; 24 withdrawn base controls and withdrawn enhancements excluded.
- HDF: NIST tags from the hdf-mappings tables (AWS Config, ScoutSuite, Nessus, Nikto, Checkov, CWE, OWASP, Hipcheck), tag nist in 44 MITRE SAF InSpec baselines, NIST references in 1,239 ComplianceAsCode rules (the content OpenSCAP and SCAP scans report), Prowler's AWS NIST 800-53 Rev 5 requirements with checks, and the fixed defaults in 11 converters, parsed to the part (IA-5 (1) (a) becomes ia-5.1_smt.a). A tag naming a lettered parent covers its child items.
- OSCAL evidence: the control-level classification (SSP, profile, SAP, SAR, POAM, actions, inventory, back-matter plans) applied to every part of those base controls, except RA-5 and SI-2 where only the remediation-window parts (RA-5 d, SI-2 c) count.
- OSCAL documentary: parts whose text starts with a record-keeping verb, or with establish, maintain, update or develop followed by a record word (policy, plan, procedure, criteria, list, inventory, baseline, agreement and similar).
- ODP validated: any remaining part whose text contains an organization-defined parameter.
- A count means a tool can produce evidence tagged to that part, not that the part is satisfied.
- At the base-control level (previous view) the same data gave 166 of 300 controls. Part level is stricter: a control-level tag no longer credits every part.

The full classification of all 1749 parts is in control-coverage-parts.csv.

## Sources

- [mitre/hdf-libs (hdf-mappings data)](https://github.com/mitre/hdf-libs)
- [MITRE SAF validation content](https://saf.mitre.org/content/?pillar=validate)
- [ComplianceAsCode content](https://github.com/ComplianceAsCode/content)
- [Prowler NIST 800-53 Rev 5 compliance (AWS)](https://github.com/prowler-cloud/prowler/tree/master/prowler/compliance/aws)
- [NIST SP 800-53 Rev 5 OSCAL catalog](https://github.com/usnistgov/oscal-content)
- [OSCAL v1.2.3 POAM model](https://pages.nist.gov/OSCAL-Reference/models/v1.2.3/plan-of-action-and-milestones/json-outline/)
- [HDF v3.7.0 specification](https://mitre.github.io/hdf-libs/docs/specification/hdf-specification.html)
