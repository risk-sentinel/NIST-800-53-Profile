# HDF and OSCAL Automation Coverage

Coverage of every statement part in NIST SP 800-53 Rev 5: 1749 parts across the 1014 active controls and enhancements
(each lettered item such as AC-2 d.3 is one part; a control or enhancement with no lettered items is one part).
HDF and OSCAL each work on their own. HDF proves how the system is configured; OSCAL records the claim, its evidence and its
parameters. Together they give 711 parts (41%) automated evidence, and OSCAL can validate the
organization-defined parameter (ODP) values in 565 of the remaining parts.

## Summary

| Measure | Parts | Share |
|---|---|---|
| Automated evidence from HDF or OSCAL | 711 | 41% |
| HDF (explicit part tag, single-part control, or HDF document type) | 287 | 16% |
| HDF counting control-level tags too | 467 | 27% |
| OSCAL evidence (document, record or inheritance) | 454 | 26% |
| Both HDF and OSCAL evidence | 30 | 2% |
| No evidence, but OSCAL validates the ODP value | 565 | 32% |
| Neither: evidence stays human or attested | 473 | 27% |

```mermaid
%%{init: {"themeVariables": {"pie1": "#009683", "pie2": "#5b8f5a", "pie3": "#b4541a", "pie4": "#c9a24a", "pie5": "#b8c1c8", "pieStrokeColor": "#ffffff"}}}%%
pie showData
  title All 1749 statement parts
  "HDF only" : 257
  "HDF and OSCAL" : 30
  "OSCAL evidence only" : 424
  "OSCAL ODP check only" : 565
  "Neither" : 473
```

## Where each format reaches

The circles are area-proportional. OSCAL evidence and ODP validation do not overlap by construction: a part counts as an
ODP check only when OSCAL has no stronger evidence for it.

```mermaid
venn-beta
  title Statement parts with automated evidence or checks
  set HDF["HDF 287"]:287
  set OSCAL["OSCAL evidence 454"]:454
  set ODP["ODP validated 715"]:715
  union HDF,OSCAL["30"]:30
  union HDF,ODP["150"]:150
  union OSCAL,ODP:0
  union HDF,OSCAL,ODP:0
  style HDF fill:#009683
  style OSCAL fill:#b4541a
  style ODP fill:#8a6d1a
```

| OSCAL tier | Parts | What makes it automatable |
|---|---|---|
| Evidence | 261 | The OSCAL document is the evidence: SSP, profile, SAP, SAR, POAM, authorization actions, leveraged authorizations, inventory, hashed plans in back-matter |
| Documentary | 116 | The part asks for a record (document, define, designate, review and update, maintain a list or plan): back-matter resource with hash, metadata dates, responsible role |
| Inherited | 77 | PE parts marked inherited with provided-uuid pointing at a leveraged cloud authorization (cloud-hosted systems only) |
| ODP validated | 715 | The part has an organization-defined parameter: the value lives in SSP set-parameters and can be checked against profile constraints and against tool settings such as InSpec inputs or AWS Config rule parameters |

## What drives HDF's reach

| How HDF reaches a part | Parts |
|---|---|
| Tag names the whole control or enhancement, which has a single part | 172 |
| Tag names the part letter, revision not stated | 82 |
| Tag names the part letter, Rev 4 only (letter may have shifted in Rev 5) | 22 |
| HDF document type (Plan for CA-2, Amendments for CA-5 and RA-7) | 11 |

A further 180 parts sit under controls that HDF tags only at control level (for example "AC-2" with no letter);
they are not counted above because the tag does not say which part the check proves.

```mermaid
%%{init: {"themeVariables": {"xyChart": {"plotColorPalette": "#009683"}}}}%%
xychart-beta horizontal
  title "Statement parts reached by each HDF source"
  x-axis ["InSpec", "AWS Config", "Checkov", "ScoutSuite", "CWE", "OWASP", "Nessus", "Nikto", "Hipcheck"]
  y-axis "Statement parts" 0 --> 200
  bar [196, 119, 50, 17, 12, 3, 3, 2, 2]
```

## POAM: automated management, not just a list

An OSCAL POAM risk has a status lifecycle (open, investigating, remediating, deviation-requested, deviation-approved, closed),
a deadline, remediation tasks of type milestone, and a risk-log of dated status changes. Fed by HDF results on every run, it
tracks the remediation windows in RA-5 d and SI-2 c. HDF can run a simpler version on its own with Amendments of type poam,
waivers and risk adjustments, each with a required expiresAt.

```mermaid
flowchart LR
  r1["HDF result - check tagged RA-5 d or SI-2 c - status failed"] --> r2["SAR finding - hdf convert --to oscal-sar - state not-satisfied"]
  r2 --> r3["POAM item and risk - status open - deadline - remediation tasks, type milestone"]
  r3 --> r4["risk-log entries - status-change remediating, or deviation-requested then deviation-approved"]
  r4 --> r5["Rescan - HDF result passed - risk status closed"]
  r5 -.->|every pipeline run| r1
  classDef hdf fill:#e0f2ef,stroke:#009683,color:#17212a
  classDef oscal fill:#f8e9df,stroke:#b4541a,color:#17212a
  class r1,r5 hdf
  class r2,r3,r4 oscal
```

## Coverage by family

| Family | Parts | HDF | OSCAL evidence | Either | ODP validated only | Neither |
|---|---|---|---|---|---|---|
| AC | 214 | 48 | 20 | 68 | 100 | 46 |
| AT | 29 | 0 | 8 | 8 | 12 | 9 |
| AU | 84 | 40 | 15 | 48 | 23 | 13 |
| CA | 57 | 13 | 37 | 38 | 7 | 12 |
| CM | 108 | 27 | 37 | 58 | 34 | 16 |
| CP | 82 | 11 | 29 | 40 | 16 | 26 |
| IA | 96 | 30 | 7 | 37 | 33 | 26 |
| IR | 77 | 6 | 22 | 28 | 20 | 29 |
| MA | 57 | 6 | 12 | 18 | 15 | 24 |
| MP | 35 | 1 | 8 | 9 | 14 | 12 |
| PE | 83 | 0 | 83 | 83 | 0 | 0 |
| PL | 46 | 0 | 39 | 39 | 3 | 4 |
| PM | 98 | 0 | 47 | 47 | 10 | 41 |
| PS | 45 | 0 | 13 | 13 | 11 | 21 |
| PT | 42 | 0 | 7 | 7 | 18 | 17 |
| RA | 48 | 4 | 13 | 16 | 14 | 18 |
| SA | 185 | 10 | 28 | 38 | 79 | 68 |
| SC | 175 | 53 | 9 | 60 | 72 | 43 |
| SI | 151 | 36 | 7 | 42 | 65 | 44 |
| SR | 37 | 2 | 13 | 14 | 19 | 4 |
| All | 1749 | 287 | 454 | 711 | 565 | 473 |

## How this was counted

- Universe: every leaf statement item of the 1014 active controls and enhancements in NIST's official SP 800-53 Rev 5 OSCAL catalog; 24 withdrawn base controls and withdrawn enhancements excluded.
- HDF: NIST tags from the hdf-mappings tables (AWS Config, ScoutSuite, Nessus, Nikto, Checkov, CWE, OWASP, Hipcheck) and tag nist in 44 MITRE SAF InSpec baselines, parsed to the part (IA-5 (1) (a) becomes ia-5.1_smt.a). A tag naming a lettered parent covers its child items.
- OSCAL evidence: the control-level classification (SSP, profile, SAP, SAR, POAM, actions, inventory, back-matter plans) applied to every part of those base controls, except RA-5 and SI-2 where only the remediation-window parts (RA-5 d, SI-2 c) count.
- OSCAL documentary: parts whose text starts with a record-keeping verb, or with establish, maintain, update or develop followed by a record word (policy, plan, procedure, criteria, list, inventory, baseline, agreement and similar).
- ODP validated: any remaining part whose text contains an organization-defined parameter.
- A count means a tool can produce evidence tagged to that part, not that the part is satisfied.
- At the base-control level (previous view) the same data gave 166 of 300 controls. Part level is stricter: a control-level tag no longer credits every part.

The full classification of all 1749 parts is in control-coverage-parts.csv.

## Sources

- [mitre/hdf-libs (hdf-mappings data)](https://github.com/mitre/hdf-libs)
- [MITRE SAF validation content](https://saf.mitre.org/content/?pillar=validate)
- [NIST SP 800-53 Rev 5 OSCAL catalog](https://github.com/usnistgov/oscal-content)
- [OSCAL v1.2.3 POAM model](https://pages.nist.gov/OSCAL-Reference/models/v1.2.3/plan-of-action-and-milestones/json-outline/)
- [HDF v3.7.0 specification](https://mitre.github.io/hdf-libs/docs/specification/hdf-specification.html)
