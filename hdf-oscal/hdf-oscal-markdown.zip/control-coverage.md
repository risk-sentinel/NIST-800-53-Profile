# HDF and OSCAL Automation Coverage

Coverage of every statement part in NIST SP 800-53 Rev 5: 1749 parts across the 1014 active controls and enhancements
(each lettered item such as AC-2 d.3 is one part; a control or enhancement with no lettered items is one part).
HDF and OSCAL each work on their own. HDF proves how the system is configured; OSCAL records the claim, its evidence and its
parameters. Together they give 765 parts (44%) automated evidence, and OSCAL can validate the
organization-defined parameter (ODP) values in 530 of the remaining parts.

## Terms

- **HDF**: Heimdall Data Format
- **OSCAL**: Open Security Controls Assessment Language
- **ODP**: Organization-defined parameter, the [Assignment] values in a control
- **POAM**: Plan of Action and Milestones
- **SSP / SAP / SAR**: System Security Plan / Security Assessment Plan / Security Assessment Results
- **ASFF**: AWS Security Finding Format
- **SCAP**: Security Content Automation Protocol
- **CWE**: Common Weakness Enumeration
- **CCI**: Control Correlation Identifier (DISA STIG)
- **STIG**: Security Technical Implementation Guide
- **SRG**: Security Requirements Guide (DISA)
- **SARIF**: Static Analysis Results Interchange Format
- **SBOM**: Software Bill of Materials
- **VEX**: Vulnerability Exploitability eXchange

## Summary

| Measure | Parts | Share |
|---|---|---|
| Automated evidence from HDF or OSCAL | 765 | 44% |
| HDF (explicit part tag, single-part control, or HDF document type) | 348 | 20% |
| HDF counting control-level tags too | 529 | 30% |
| OSCAL evidence (document, record or inheritance) | 454 | 26% |
| Both HDF and OSCAL evidence | 37 | 2% |
| No evidence, but OSCAL validates the ODP value | 530 | 30% |
| Neither: evidence stays human or attested | 454 | 26% |

```mermaid
%%{init: {"themeVariables": {"pie1": "#00695c", "pie2": "#33691e", "pie3": "#9a4a12", "pie4": "#6d5a00", "pie5": "#455a64", "pieStrokeColor": "#ffffff", "pieStrokeWidth": "2px", "pieSectionTextColor": "#ffffff", "pieOuterStrokeColor": "#455a64", "pieOpacity": "1"}}}%%
pie showData
  accTitle: All 1749 statement parts
  accDescr: Pie chart with 5 slices. A full text description follows the diagram.
  title All 1749 statement parts
  "HDF only" : 311
  "HDF and OSCAL" : 37
  "OSCAL evidence only" : 417
  "OSCAL ODP check only" : 530
  "Neither" : 454
```

**Text description of the diagram above**

All 1749 statement parts. Pie chart with 5 slices.

- HDF only: 311 (18%).
- HDF and OSCAL: 37 (2%).
- OSCAL evidence only: 417 (24%).
- OSCAL ODP check only: 530 (30%).
- Neither: 454 (26%).

## Where each format reaches

The circles are area-proportional. OSCAL evidence and ODP validation do not overlap by construction: a part counts as an
ODP check only when OSCAL has no stronger evidence for it.

```mermaid
venn-beta
  title Statement parts with automated evidence or checks
  set HDF["HDF 348"]:348
  set OSCAL["OSCAL evidence 454"]:454
  set ODP["ODP validated 715"]:715
  union HDF,OSCAL["37"]:37
  union HDF,ODP["185"]:185
  union OSCAL,ODP:0
  union HDF,OSCAL,ODP:0
  style HDF fill:#009683
  style OSCAL fill:#b4541a
  style ODP fill:#8a6d1a
```

**Text description of the diagram above**

Statement parts with automated evidence or checks. Venn diagram.

- Set HDF 348.
- Set OSCAL evidence 454.
- Set ODP validated 715.
- Overlap of HDF 348 and OSCAL evidence 454: 37.
- Overlap of HDF 348 and ODP validated 715: 185.
- Overlap of OSCAL evidence 454 and ODP validated 715: none.
- Overlap of HDF 348 and OSCAL evidence 454 and ODP validated 715: none.

| OSCAL tier | Parts | What makes it automatable |
|---|---|---|
| Evidence | 261 | The OSCAL document is the evidence: SSP, profile, SAP, SAR, POAM, authorization actions, leveraged authorizations, inventory, hashed plans in back-matter |
| Documentary | 116 | The part asks for a record (document, define, designate, review and update, maintain a list or plan): back-matter resource with hash, metadata dates, responsible role |
| Inherited | 77 | PE parts marked inherited with provided-uuid pointing at a leveraged cloud authorization (cloud-hosted systems only) |
| ODP validated | 715 | The part has an organization-defined parameter: the value lives in SSP set-parameters and can be checked against profile constraints and against tool settings such as InSpec inputs or AWS Config rule parameters |

## What drives HDF's reach

All 47 inbound converters in hdf-libs, plus saf CLI's prowler2hdf entry point, are charted below; legacy HDF and Splunk
share the InSpec row, CKL and CKLB share one row, and the four VEX converters share one. Each tags findings to NIST in one of
four ways, and the way it tags sets its reach. Content converters pass through the controls the benchmark itself names.
Mapping-table converters look each rule or plugin up in a table shipped with hdf-mappings. CWE converters map the weakness
on the finding through the 404-entry CWE table. Default-tag converters stamp every finding with a fixed control.

```mermaid
%%{init: {"xyChart": {"width": 900, "height": 1096}, "themeVariables": {"xyChart": {"plotColorPalette": "#6a2c05, #43978b, #083029"}}}}%%
xychart-beta horizontal
  accTitle: Statement parts reached by each HDF converter
  accDescr: Bar chart of 39 categories. A full text description follows the diagram.
  %% series: today plus dropped references, today with control-level tags, parts the tag names
  title "Statement parts reached by each HDF converter"
  x-axis ["InSpec (native HDF)", "CKL and CKLB checklists", "XCCDF results (SCAP)", "AWS Config", "AWS Security Hub (ASFF)", "Nessus and Tenable", "Checkov", "ScoutSuite", "Nikto", "Hipcheck", "SonarQube", "Netsparker (Invicti)", "Burp Suite", "CycloneDX SBOM", "DefectDojo", "Dependency-Track", "Fortify", "GitLab", "JFrog Xray", "KICS", "SARIF", "Semgrep", "Snyk", "ZAP", "gosec", "NeuVector", "Veracode", "Prisma Cloud", "Twistlock", "Prowler (ASFF)", "Grype and Anchore", "Trivy", "Conveyor", "DbProtect", "Defender for Endpoint", "Microsoft Secure Score", "JUnit", "Ion Channel", "TruffleHog"]
  y-axis "Statement parts" 0 --> 350
  bar [285, 253, 324, 271, 276, 296, 129, 91, 25, 21, 43, 51, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 44, 44, 44, 17, 12, 268, 13, 13, 13, 13, 13, 13, 5, 6, 1]
  bar [285, 253, 253, 271, 276, 296, 129, 91, 25, 21, 43, 51, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 44, 44, 44, 17, 12, 13, 13, 13, 13, 13, 13, 13, 5, 6, 1]
  bar [196, 211, 211, 92, 92, 212, 50, 17, 2, 2, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]
```

**Text description of the diagram above**

Statement parts reached by each HDF converter. Bar chart of 39 categories.

- InSpec (native HDF): today plus dropped references 285, today with control-level tags 285, parts the tag names 196.
- CKL and CKLB checklists: today plus dropped references 253, today with control-level tags 253, parts the tag names 211.
- XCCDF results (SCAP): today plus dropped references 324, today with control-level tags 253, parts the tag names 211.
- AWS Config: today plus dropped references 271, today with control-level tags 271, parts the tag names 92.
- AWS Security Hub (ASFF): today plus dropped references 276, today with control-level tags 276, parts the tag names 92.
- Nessus and Tenable: today plus dropped references 296, today with control-level tags 296, parts the tag names 212.
- Checkov: today plus dropped references 129, today with control-level tags 129, parts the tag names 50.
- ScoutSuite: today plus dropped references 91, today with control-level tags 91, parts the tag names 17.
- Nikto: today plus dropped references 25, today with control-level tags 25, parts the tag names 2.
- Hipcheck: today plus dropped references 21, today with control-level tags 21, parts the tag names 2.
- SonarQube: today plus dropped references 43, today with control-level tags 43, parts the tag names 12.
- Netsparker (Invicti): today plus dropped references 51, today with control-level tags 51, parts the tag names 12.
- Burp Suite: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- CycloneDX SBOM: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- DefectDojo: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- Dependency-Track: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- Fortify: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- GitLab: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- JFrog Xray: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- KICS: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- SARIF: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- Semgrep: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- Snyk: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- ZAP: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- gosec: today plus dropped references 44, today with control-level tags 44, parts the tag names 12.
- NeuVector: today plus dropped references 44, today with control-level tags 44, parts the tag names 12.
- Veracode: today plus dropped references 44, today with control-level tags 44, parts the tag names 12.
- Prisma Cloud: today plus dropped references 17, today with control-level tags 17, parts the tag names 0.
- Twistlock: today plus dropped references 12, today with control-level tags 12, parts the tag names 0.
- Prowler (ASFF): today plus dropped references 268, today with control-level tags 13, parts the tag names 0.
- Grype and Anchore: today plus dropped references 13, today with control-level tags 13, parts the tag names 0.
- Trivy: today plus dropped references 13, today with control-level tags 13, parts the tag names 0.
- Conveyor: today plus dropped references 13, today with control-level tags 13, parts the tag names 0.
- DbProtect: today plus dropped references 13, today with control-level tags 13, parts the tag names 0.
- Defender for Endpoint: today plus dropped references 13, today with control-level tags 13, parts the tag names 0.
- Microsoft Secure Score: today plus dropped references 13, today with control-level tags 13, parts the tag names 0.
- JUnit: today plus dropped references 5, today with control-level tags 5, parts the tag names 0.
- Ion Channel: today plus dropped references 6, today with control-level tags 6, parts the tag names 0.
- TruffleHog: today plus dropped references 1, today with control-level tags 1, parts the tag names 1.

Each bar has up to three segments. The inner segment, starting at zero, counts parts the tag names. The middle segment adds
parts reached only through a control-level tag. The outer segment, on XCCDF results and Prowler only, adds the parts the
converter would reach if it kept references that its input carries but it drops today. OSCAL to HDF, Defender for Cloud,
Defender for DevOps and the VEX converters have no bar: the first carries whatever the OSCAL names, the next two emit no NIST
tags, and VEX converters emit amendments. The same values are in the table below and in the text description.

| How it tags | Converter | Mechanisms | Reach today | Reach it drops | Notes |
|---|---|---|---|---|---|
| Content carries its own tags | InSpec (native HDF) | InSpec tag nist | 196 named, 285 with control-level tags |  | saf CLI and Heimdall read InSpec JSON directly; legacyhdf, hdf-passthrough and the Splunk fetcher carry the same tags |
| Content carries its own tags | CKL and CKLB checklists | DISA SRG/STIG CCI | 211 named, 253 with control-level tags |  | STIG Viewer, Evaluate-STIG and SCC checklists; CCI to NIST |
| Content carries its own tags | XCCDF results (SCAP) | DISA SRG/STIG CCI | 211 named, 253 with control-level tags | +71 parts if it kept ComplianceAsCode NIST references | OpenSCAP and SCC results; NIST only from CCI idents, so ComplianceAsCode NIST references are dropped |
| Content carries its own tags | OSCAL to HDF | - | set by the OSCAL content |  | control-ids from the OSCAL SAR, POAM or SSP; reach is whatever the OSCAL names |
| Per-rule or per-plugin mapping table | AWS Config | AWS Config table, default CM-6 | 92 named, 271 with control-level tags |  | also the awsconfig fetcher |
| Per-rule or per-plugin mapping table | AWS Security Hub (ASFF) | AWS Config table, default CM-6, default SA-11 RA-5, default SI-2 RA-5 | 92 named, 276 with control-level tags |  | Config-rule findings through the AWS Config table; also the aws-securityhub fetcher |
| Per-rule or per-plugin mapping table | Nessus and Tenable | Nessus plugin-family table, DISA SRG/STIG CCI, default SI-2 RA-5 | 212 named, 296 with control-level tags |  | plugin-family table, plus CCI from compliance-audit results (DISA STIG audits) |
| Per-rule or per-plugin mapping table | Checkov | Checkov table, default SA-11 RA-5 | 50 named, 129 with control-level tags |  |  |
| Per-rule or per-plugin mapping table | ScoutSuite | ScoutSuite table | 17 named, 91 with control-level tags |  |  |
| Per-rule or per-plugin mapping table | Nikto | Nikto table, default SA-11 RA-5 | 2 named, 25 with control-level tags |  |  |
| Per-rule or per-plugin mapping table | Hipcheck | Hipcheck table | 2 named, 21 with control-level tags |  |  |
| CWE or OWASP on the finding | SonarQube | CWE table, OWASP table | 12 named, 43 with control-level tags |  | also the sonarqube fetcher |
| CWE or OWASP on the finding | Netsparker (Invicti) | CWE table, OWASP table, default SA-11 RA-5 | 12 named, 51 with control-level tags |  |  |
| CWE or OWASP on the finding | Burp Suite | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  |  |
| CWE or OWASP on the finding | CycloneDX SBOM | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  | CWE on vulnerabilities |
| CWE or OWASP on the finding | DefectDojo | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  | also the defectdojo fetcher |
| CWE or OWASP on the finding | Dependency-Track | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  |  |
| CWE or OWASP on the finding | Fortify | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  | plus control-level NIST from rulepack references in the FVDL |
| CWE or OWASP on the finding | GitLab | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  | also the gitlab fetcher |
| CWE or OWASP on the finding | JFrog Xray | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  |  |
| CWE or OWASP on the finding | KICS | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  | per-query table is defined but empty today |
| CWE or OWASP on the finding | SARIF | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  |  |
| CWE or OWASP on the finding | Semgrep | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  |  |
| CWE or OWASP on the finding | Snyk | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  |  |
| CWE or OWASP on the finding | ZAP | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  |  |
| CWE or OWASP on the finding | gosec | CWE table, default SI-2 RA-5 | 12 named, 44 with control-level tags |  |  |
| CWE or OWASP on the finding | NeuVector | CWE table, default SI-2 RA-5 | 12 named, 44 with control-level tags |  |  |
| CWE or OWASP on the finding | Veracode | CWE table, default SI-2 RA-5 | 12 named, 44 with control-level tags |  |  |
| Fixed default tags | Prisma Cloud | default SI-2 RA-5, default SA-11 RA-5 | 0 named, 17 with control-level tags |  |  |
| Fixed default tags | Twistlock | default SI-2 RA-5 | 0 named, 12 with control-level tags |  |  |
| Fixed default tags | Prowler (ASFF) | default SA-11 RA-5 | 0 named, 13 with control-level tags | +255 parts if it kept Prowler requirement IDs | saf CLI prowler2hdf; ASFF drops Compliance.RelatedRequirements |
| Fixed default tags | Grype and Anchore | default SA-11 RA-5 | 0 named, 13 with control-level tags |  |  |
| Fixed default tags | Trivy | default SA-11 RA-5 | 0 named, 13 with control-level tags |  |  |
| Fixed default tags | Conveyor | default SA-11 RA-5 | 0 named, 13 with control-level tags |  |  |
| Fixed default tags | DbProtect | default SA-11 RA-5 | 0 named, 13 with control-level tags |  |  |
| Fixed default tags | Defender for Endpoint | default SA-11 RA-5 | 0 named, 13 with control-level tags |  |  |
| Fixed default tags | Microsoft Secure Score | default SA-11 RA-5 | 0 named, 13 with control-level tags |  |  |
| Fixed default tags | JUnit | default SA-11 | 0 named, 5 with control-level tags |  |  |
| Fixed default tags | Ion Channel | default CM-8 | 0 named, 6 with control-level tags |  |  |
| Fixed default tags | TruffleHog | default IA-5 (7) | 1 named, 1 with control-level tags |  |  |
| No NIST tags today | Defender for Cloud | - | none |  | findings carry categories and MITRE tactics, no NIST |
| No NIST tags today | Defender for DevOps | - | none |  | no NIST |
| Amendments, not results | VEX converters (4) | - | none |  | emit HDF Amendments that adjust findings; no control reach of their own |

Three findings from reading the converter code:

- **XCCDF results take NIST only from CCI idents.** DISA STIG benchmarks carry CCIs, so SCC and OpenSCAP runs against DISA
  content are tagged. ComplianceAsCode content (CIS, PCI, OSPP and other non-STIG profiles) carries NIST 800-53 as
  `reference` elements, which the converter keeps as references but not as tags, so those results arrive with an empty
  tags.nist.
- **ASFF drops Compliance.RelatedRequirements.** Prowler writes its NIST 800-53 Rev 5 requirement IDs there; both the
  hdf-libs converter and saf CLI's prowler2hdf fall back to SA-11 and RA-5 instead. Security Hub findings from AWS Config
  rules still map through the AWS Config table.
- **The KICS per-query table is defined but empty,** and Defender for Cloud and Defender for DevOps emit no NIST tags at
  all. KICS falls back to the CWE table.

Carrying those references would add 168 parts to HDF's reach.

### Tools that reach HDF through a standard format

Many tools have no converter of their own but export a format one of the converters reads. Their reach is the carrier's row
above.

| Tool | Export | Converter that reads it |
|---|---|---|
| Sonatype Lifecycle (Nexus IQ) | CycloneDX SBOM with vulnerabilities | CycloneDX |
| Tenable Vulnerability Management (Tenable.io) | .nessus export | Nessus and Tenable |
| Tenable Security Center (Tenable.sc) | .nessus export, or the Tenable.sc API loader in Heimdall | Nessus and Tenable |
| Tenable compliance audits (DISA STIG .audit) | .nessus export with compliance results | Nessus and Tenable (CCI path) |
| GitHub CodeQL and code scanning | SARIF | SARIF |
| Checkmarx One | SARIF report | SARIF |
| Bandit, ESLint, hadolint, tfsec and other SARIF emitters | SARIF | SARIF |
| OWASP Dependency-Check | SARIF report | SARIF |
| Syft and other SBOM generators with a vulnerability pass | CycloneDX | CycloneDX |
| Anchore Enterprise and Grype | Grype JSON (saf convert anchoregrype2hdf) | Grype and Anchore |
| DISA SCC, OpenSCAP | XCCDF results or ARF | XCCDF results (SCAP) |
| DISA STIG Viewer, Evaluate-STIG | CKL or CKLB | CKL and CKLB checklists |
| AWS Security Hub sources (GuardDuty, Inspector, Firewall Manager, Prowler) | ASFF | AWS Security Hub (ASFF) |
| Any tool already exporting to DefectDojo, GitLab or Splunk | the platform API (fetchers) | DefectDojo, GitLab, Splunk |

Control-level tags (for example "SI-2" or "SA-11" with no letter) do not say which part the check proves, so they are not
counted in the HDF total. That is why the default-tag and CWE converters add little at part level even though they run in
most pipelines. Tagging to the part letter in mapping tables would move them over.

| How HDF reaches a counted part | Parts |
|---|---|
| Tag names the whole control or enhancement, which has a single part | 212 |
| Tag names the part letter, Rev 5 | 0 |
| Tag names the part letter, revision not stated | 82 |
| Tag names the part letter, Rev 4 only (letter may have shifted in Rev 5) | 43 |
| HDF document type (Plan for CA-2, Amendments for CA-5 and RA-7) | 11 |

Not yet counted, because the content is not in these repositories: the DISA STIG library beyond the 7 SRGs and 4 STIGs in
the Vulcan seed set, Tenable's audit library beyond its DISA STIG audits, Fortify rulepack NIST references, Azure and GCP
NIST mappings, and SAF InSpec profiles that could not be cloned. Each would add reach.

## POAM: automated management, not just a list

An OSCAL POAM risk has a status lifecycle (open, investigating, remediating, deviation-requested, deviation-approved, closed),
a deadline, remediation tasks of type milestone, and a risk-log of dated status changes. Fed by HDF results on every run, it
tracks the remediation windows in RA-5 d and SI-2 c. HDF can run a simpler version on its own with Amendments of type poam,
waivers and risk adjustments, each with a required expiresAt.

```mermaid
flowchart LR
  accTitle: POAM - automated management, not just a list
  accDescr: Flowchart with 5 items and 5 connections. A full text description follows the diagram.
  r1["HDF result - check tagged RA-5 d or SI-2 c - status failed"] --> r2["SAR finding - hdf convert --to oscal-sar - state not-satisfied"]
  r2 --> r3["POAM item and risk - status open - deadline - remediation tasks, type milestone"]
  r3 --> r4["risk-log entries - status-change remediating, or deviation-requested then deviation-approved"]
  r4 --> r5["Rescan - HDF result passed - risk status closed"]
  r5 -.->|every pipeline run| r1
  classDef hdf fill:#e0f2ef,stroke:#009683,color:#17212a
  classDef oscal fill:#f8e9df,stroke:#b4541a,color:#17212a
  class r1,r5 hdf
  class r2,r3,r4 oscal
```

**Text description of the diagram above**

POAM - automated management, not just a list. Flowchart with 5 items and 5 connections.

- HDF result - check tagged RA-5 d or SI-2 c - status failed points to SAR finding - hdf convert --to oscal-sar - state not-satisfied.
- SAR finding - hdf convert --to oscal-sar - state not-satisfied points to POAM item and risk - status open - deadline - remediation tasks, type milestone.
- POAM item and risk - status open - deadline - remediation tasks, type milestone points to risk-log entries - status-change remediating, or deviation-requested then deviation-approved.
- risk-log entries - status-change remediating, or deviation-requested then deviation-approved points to Rescan - HDF result passed - risk status closed.
- Rescan - HDF result passed - risk status closed points to HDF result - check tagged RA-5 d or SI-2 c - status failed (dashed): every pipeline run.

## Coverage by family

| Family | Parts | HDF | OSCAL evidence | Either | ODP validated only | Neither |
|---|---|---|---|---|---|---|
| AC | 214 | 53 | 20 | 73 | 94 | 47 |
| AT | 29 | 1 | 8 | 9 | 12 | 8 |
| AU | 84 | 43 | 15 | 51 | 21 | 12 |
| CA | 57 | 12 | 37 | 39 | 6 | 12 |
| CM | 108 | 31 | 37 | 61 | 32 | 15 |
| CP | 82 | 21 | 29 | 43 | 14 | 25 |
| IA | 96 | 33 | 7 | 40 | 32 | 24 |
| IR | 77 | 6 | 22 | 28 | 20 | 29 |
| MA | 57 | 11 | 12 | 23 | 14 | 20 |
| MP | 35 | 2 | 8 | 10 | 14 | 11 |
| PE | 83 | 0 | 83 | 83 | 0 | 0 |
| PL | 46 | 0 | 39 | 39 | 3 | 4 |
| PM | 98 | 1 | 47 | 48 | 10 | 40 |
| PS | 45 | 0 | 13 | 13 | 11 | 21 |
| PT | 42 | 0 | 7 | 7 | 18 | 17 |
| RA | 48 | 4 | 13 | 16 | 14 | 18 |
| SA | 185 | 19 | 28 | 46 | 74 | 65 |
| SC | 175 | 67 | 9 | 74 | 66 | 35 |
| SI | 151 | 42 | 7 | 48 | 56 | 47 |
| SR | 37 | 2 | 13 | 14 | 19 | 4 |
| All | 1749 | 348 | 454 | 765 | 530 | 454 |

## How this was counted

- Universe: every leaf statement item of the 1014 active controls and enhancements in NIST's official SP 800-53 Rev 5 OSCAL catalog; 24 withdrawn base controls and withdrawn enhancements excluded.
- HDF: what each converter emits today. Mapping tables (AWS Config, ScoutSuite, Nessus, Nikto, Checkov, CWE, OWASP, Hipcheck) were run through hdf-mappings' own Go lookups at Rev 5, so the Rev 4 to Rev 5 crosswalk is the library's. InSpec content is tag nist in the MITRE SAF baselines. STIG content is the CCIs in 7 DISA SRGs and 4 STIGs, mapped CCI to NIST by the same library. Fixed defaults are read from each converter. Tags are parsed to the part (IA-5 (1) (a) becomes ia-5.1_smt.a), and a tag naming a lettered parent covers its child items.
- Dropped references (outer bar segment, not in any total): NIST references in ComplianceAsCode rules and Prowler's AWS NIST 800-53 Rev 5 requirements with checks.
- OSCAL evidence: the control-level classification (SSP, profile, SAP, SAR, POAM, actions, inventory, back-matter plans) applied to every part of those base controls, except RA-5 and SI-2 where only the remediation-window parts (RA-5 d, SI-2 c) count.
- OSCAL documentary: parts whose text starts with a record-keeping verb, or with establish, maintain, update or develop followed by a record word (policy, plan, procedure, criteria, list, inventory, baseline, agreement and similar).
- ODP validated: any remaining part whose text contains an organization-defined parameter.
- A count means a tool can produce evidence tagged to that part, not that the part is satisfied.

The full classification of all 1749 parts is in control-coverage-parts.csv.

## Sources

- [mitre/hdf-libs (hdf-mappings data)](https://github.com/mitre/hdf-libs)
- [MITRE SAF validation content](https://saf.mitre.org/content/?pillar=validate)
- [ComplianceAsCode content](https://github.com/ComplianceAsCode/content)
- [Prowler NIST 800-53 Rev 5 compliance (AWS)](https://github.com/prowler-cloud/prowler/tree/master/prowler/compliance/aws)
- [MITRE SAF CLI convert commands](https://github.com/mitre/saf)
- [MITRE Vulcan (DISA SRG and STIG seed content)](https://github.com/mitre/vulcan)
- [NIST SP 800-53 Rev 5 OSCAL catalog](https://github.com/usnistgov/oscal-content)
- [OSCAL v1.2.3 POAM model](https://pages.nist.gov/OSCAL-Reference/models/v1.2.3/plan-of-action-and-milestones/json-outline/)
- [HDF v3.7.0 specification](https://mitre.github.io/hdf-libs/docs/specification/hdf-specification.html)
