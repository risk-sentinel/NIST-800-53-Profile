#!/usr/bin/env bash
# Publish a Confluence storage-format page and its attachments (create or update).
# Works with Confluence Data Center/Server (Personal Access Token) and Cloud (email + API token)
# through the v1 REST API. Needs: bash, curl, jq.
#
# Required:
#   CONFLUENCE_URL     Base URL, e.g. https://confluence.agency.gov  or  https://yoursite.atlassian.net/wiki
#   CONFLUENCE_SPACE   Space key, e.g. SECAUTO
#   CONFLUENCE_TOKEN   PAT (Data Center/Server) or API token (Cloud)
# Optional:
#   CONFLUENCE_USER    Set for Cloud (your Atlassian email); leave unset to send the token as a Bearer PAT
#   CONFLUENCE_TITLE   Page title (default: "HDF and OSCAL Automation Coverage")
#   CONFLUENCE_PARENT  Parent page ID, used only when the page is created
#   PAGE_FILE          Storage XML (default: control-coverage.confluence.xml next to this script)
#   DRY_RUN=1          Print what would happen; send nothing
#
# Usage: ./publish-confluence.sh [attachment ...]
#   With no arguments, attaches the three PNG diagrams and the CSV that sit next to this script.
set -euo pipefail

here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
: "${CONFLUENCE_URL:?set CONFLUENCE_URL}" "${CONFLUENCE_SPACE:?set CONFLUENCE_SPACE}" "${CONFLUENCE_TOKEN:?set CONFLUENCE_TOKEN}"
TITLE="${CONFLUENCE_TITLE:-HDF and OSCAL Automation Coverage}"
PAGE_FILE="${PAGE_FILE:-$here/control-coverage.confluence.xml}"
API="${CONFLUENCE_URL%/}/rest/api"
DRY_RUN="${DRY_RUN:-0}"

for bin in curl jq; do command -v "$bin" >/dev/null || { echo "missing dependency: $bin" >&2; exit 1; }; done
[[ -f "$PAGE_FILE" ]] || { echo "page file not found: $PAGE_FILE" >&2; exit 1; }

if [[ $# -gt 0 ]]; then files=("$@"); else
  files=("$here"/control-coverage-venn.png "$here"/control-coverage-hdf-sources.png "$here"/control-coverage-poam-loop.png "$here"/control-coverage.csv)
fi
for f in "${files[@]}"; do [[ -f "$f" ]] || { echo "attachment not found: $f" >&2; exit 1; }; done

auth=()
if [[ -n "${CONFLUENCE_USER:-}" ]]; then auth=(-u "$CONFLUENCE_USER:$CONFLUENCE_TOKEN")
else auth=(-H "Authorization: Bearer $CONFLUENCE_TOKEN"); fi

# api METHOD PATH [curl args...] -> prints body, fails loudly on HTTP >= 400
api() {
  local method=$1 path=$2; shift 2
  local out code
  out="$(mktemp)"
  code="$(curl -sS -o "$out" -w '%{http_code}' -X "$method" "${auth[@]}" "$@" "$API$path")"
  if (( code >= 400 )); then
    echo "HTTP $code on $method $path" >&2; head -c 600 "$out" >&2; echo >&2; rm -f "$out"; return 1
  fi
  cat "$out"; rm -f "$out"
}

# 1. Find the page by space + title
q_title="$(jq -rn --arg t "$TITLE" '$t|@uri')"
found="$(api GET "/content?spaceKey=$CONFLUENCE_SPACE&title=$q_title&type=page&expand=version")"
page_id="$(jq -r '.results[0].id // empty' <<<"$found")"
version="$(jq -r '.results[0].version.number // 0' <<<"$found")"

body_json() {  # $1 = version number or empty for create
  jq -n --rawfile v "$PAGE_FILE" --arg t "$TITLE" --arg s "$CONFLUENCE_SPACE" \
        --arg p "${CONFLUENCE_PARENT:-}" --arg ver "${1:-}" --arg id "${page_id:-}" '
    {type:"page", title:$t, space:{key:$s}, body:{storage:{value:$v, representation:"storage"}}}
    + (if $ver != "" then {id:$id, version:{number:($ver|tonumber), message:"Updated by publish-confluence.sh"}} else {} end)
    + (if $ver == "" and $p != "" then {ancestors:[{id:$p}]} else {} end)'
}

if [[ "$DRY_RUN" == 1 ]]; then
  if [[ -n "$page_id" ]]; then echo "[dry run] would update page $page_id to version $((version+1)): $TITLE"
  else echo "[dry run] would create page in $CONFLUENCE_SPACE: $TITLE"; fi
  printf '[dry run] would attach: %s\n' "${files[@]##*/}"; exit 0
fi

# 2. Create the page if it does not exist, so attachments have a home
if [[ -z "$page_id" ]]; then
  created="$(body_json "" | api POST /content -H 'Content-Type: application/json' --data-binary @-)"
  page_id="$(jq -r .id <<<"$created")"; version=1
  echo "created page $page_id"
  just_created=1
else
  just_created=0
fi

# 3. Upload or replace each attachment
for f in "${files[@]}"; do
  name="${f##*/}"
  q_name="$(jq -rn --arg n "$name" '$n|@uri')"
  att_id="$(api GET "/content/$page_id/child/attachment?filename=$q_name" | jq -r '.results[0].id // empty')"
  if [[ -n "$att_id" ]]; then
    api POST "/content/$page_id/child/attachment/$att_id/data" -H 'X-Atlassian-Token: no-check' \
        -F "file=@$f" -F 'minorEdit=true' >/dev/null
    echo "replaced attachment $name"
  else
    api POST "/content/$page_id/child/attachment" -H 'X-Atlassian-Token: no-check' \
        -F "file=@$f" -F 'minorEdit=true' >/dev/null
    echo "added attachment $name"
  fi
done

# 4. Update the body on an existing page (a new page already has it)
if [[ "$just_created" == 0 ]]; then
  body_json "$((version+1))" | api PUT "/content/$page_id" -H 'Content-Type: application/json' --data-binary @- >/dev/null
  echo "updated page $page_id to version $((version+1))"
fi
echo "done: ${CONFLUENCE_URL%/}/pages/viewpage.action?pageId=$page_id"
