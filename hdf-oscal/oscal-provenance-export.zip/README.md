# OSCAL Provenance Chain: Confluence bundle

Mermaid sources are plain ASCII with no characters Confluence entity-encodes, so they paste
cleanly into a Mermaid macro. The page itself shows the PNG diagrams and needs no Mermaid app.

## Publish with the script

```bash
export CONFLUENCE_URL=https://confluence.agency.gov      # Cloud: https://yoursite.atlassian.net/wiki
export CONFLUENCE_SPACE=SECAUTO
export CONFLUENCE_TOKEN=...                              # Data Center PAT, or Cloud API token
# export CONFLUENCE_USER=you@agency.gov                  # Cloud only
export CONFLUENCE_TITLE="OSCAL Provenance Chain"
export PAGE_FILE=oscal-provenance.confluence.xml
DRY_RUN=1 ./publish-confluence.sh oscal-1-metadata.png oscal-2-control-responses.png oscal-3-back-matter.png oscal-4-assessment-chain.png
./publish-confluence.sh oscal-1-metadata.png oscal-2-control-responses.png oscal-3-back-matter.png oscal-4-assessment-chain.png
```

## By hand

Create the page, attach `oscal-1-metadata.png` `oscal-2-control-responses.png` `oscal-3-back-matter.png` `oscal-4-assessment-chain.png` , then paste `oscal-provenance.confluence.xml` into the source editor.
