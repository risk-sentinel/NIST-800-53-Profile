# Evidence Provenance in HDF v3

Three views of the same question: where did this piece of evidence come from, and which authorization boundary does it count toward? Field names follow the HDF v3.7.0 specification.

In v3 the Results `components[]` array is the target array. The legacy SAF `target` supplement (`id`, `type`, `boundary`) is absorbed into a `components[]` entry, with `boundary` moved to `labels`.

> How to read the diagrams: every box sits inside a labeled group that names its document (for example "hdf-results" or "hdf-system"), and every connection is labeled with the field that links it. Color repeats the grouping but carries no extra meaning. Each figure has a numbered caption and a text description.

## Terms

- **HDF**: Heimdall Data Format
- **SAF**: MITRE Security Automation Framework
- **OSCAL**: Open Security Controls Assessment Language
- **SSP**: System Security Plan
- **CMDB**: Configuration Management Database
- **eMASS**: Enterprise Mission Assurance Support Service

## 1. The target array as a provenance record

*hdf-results*

Each entry in `components[]` is typed (`repository`, `containerImage`, `cloudAccount` and ten others), and each type carries its own identity fields. With `labels`, `externalIds`, and the document-level `systemRef`, `runner` and `tool`, one Results file can say which boundary, code, build, account, asset record and environment produced the finding.

```figure
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 510" width="960" height="510" role="img" aria-labelledby="fig-title fig-desc"> <title id="fig-title">The target array as a provenance record</title>
<desc id="fig-desc">An hdf-results document whose root fields and components array each answer one provenance question: boundary, pipeline, source repository, built artifact, cloud account, CMDB record, and environment.</desc>
<rect x="0" y="0" width="960" height="510" fill="#ffffff" />
<defs> <marker id="a1" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="8" markerHeight="8" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#16202a" />
</marker>
 </defs>
 <rect x="40" y="30" width="380" height="464" rx="6" fill="#e2f1ef" stroke="#0d7069" stroke-width="1.5" />
 <text x="56" y="56" font-family="Courier New, Courier, monospace" fill="#0d7069" font-size="13" font-weight="600">hdf-results</text>
 <text x="404" y="56" text-anchor="end" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">one assessment run</text>
 <line x1="40" y1="70" x2="420" y2="70" stroke="#c7d1d9" stroke-width="1" />
 <text x="56" y="100" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">systemRef <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">"portal-prod.hdf-system.json"</tspan></text>
 <text x="56" y="126" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">runner <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">CI job execution context</tspan></text>
 <text x="56" y="152" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">tool, generator <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">{ name, version }</tspan></text>
 <text x="56" y="178" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">baselines[] to requirements[] to results[]</text>
 <text x="56" y="204" font-family="Arial, Helvetica, sans-serif" fill="#0d7069" font-size="13" font-weight="600">components[], the target array</text>
 <rect x="56" y="214" width="348" height="56" rx="4" fill="#ffffff" stroke="#0d7069" stroke-width="1" />
 <text x="70" y="236" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">type: <tspan font-weight="600">repository</tspan> <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">portal-api</tspan></text>
 <text x="70" y="257" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">url, branch: main, commit: 4f9c2e1</text>
 <rect x="56" y="280" width="348" height="56" rx="4" fill="#ffffff" stroke="#0d7069" stroke-width="1" />
 <text x="70" y="302" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">type: <tspan font-weight="600">containerImage</tspan> <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">portal-api:1.8.2</tspan></text>
 <text x="70" y="323" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">registry, repository, tag, integrity[] sha256</text>
 <rect x="56" y="346" width="348" height="78" rx="4" fill="#ffffff" stroke="#0d7069" stroke-width="1" />
 <text x="70" y="368" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">type: <tspan font-weight="600">cloudAccount</tspan> <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">portal-govcloud</tspan></text>
 <text x="70" y="390" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">provider: aws, accountId, us-gov-west-1</text>
 <text x="70" y="412" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">externalIds { cmdb: CI0045, aws: ... }</text>
 <rect x="56" y="434" width="348" height="46" rx="4" fill="#ffffff" stroke="#0d7069" stroke-width="1" stroke-dasharray="4 3" />
 <text x="70" y="453" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">labels <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">on every component</tspan></text>
 <text x="70" y="472" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">system, component, environment, team</text>
 <path d="M420,96 C510,96 510,65 596,65" marker-end="url(#a1)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <path d="M420,122 C510,122 510,129 596,129" marker-end="url(#a1)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <path d="M420,148 C510,148 510,129 596,129" fill="none" stroke="#16202a" stroke-width="1.4" />
 <path d="M404,246 C510,246 510,193 596,193" marker-end="url(#a1)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <path d="M404,311 C510,311 510,257 596,257" marker-end="url(#a1)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <path d="M404,386 C510,386 510,321 596,321" marker-end="url(#a1)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <path d="M404,408 C510,408 510,385 596,385" marker-end="url(#a1)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <path d="M404,459 C510,459 510,449 596,449" marker-end="url(#a1)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <g> <rect x="600" y="40" width="320" height="50" rx="4" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="614" y="59" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Boundary / ATO system</text>
 <text x="614" y="78" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">systemRef, labels.system</text>
 <rect x="600" y="104" width="320" height="50" rx="4" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="614" y="123" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Pipeline / CI job</text>
 <text x="614" y="142" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">runner, tool, generator, pipeline-id*</text>
 <rect x="600" y="168" width="320" height="50" rx="4" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="614" y="187" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Source repository</text>
 <text x="614" y="206" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">repository: url, branch, commit</text>
 <rect x="600" y="232" width="320" height="50" rx="4" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="614" y="251" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Built artifact</text>
 <text x="614" y="270" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">containerImage: registry, tag, integrity[]</text>
 <rect x="600" y="296" width="320" height="50" rx="4" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="614" y="315" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Cloud account</text>
 <text x="614" y="334" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">cloudAccount: provider, accountId, region</text>
 <rect x="600" y="360" width="320" height="50" rx="4" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="614" y="379" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">CMDB / asset record</text>
 <text x="614" y="398" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">externalIds.cmdb, externalIds.emass</text>
 <rect x="600" y="424" width="320" height="50" rx="4" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="614" y="443" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Environment and owner</text>
 <text x="614" y="462" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">labels.environment, labels.team, owner</text>
 </g>
 <text x="920" y="496" text-anchor="end" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">* custom label, the five well-known keys are system, component, environment, region, team</text>
 </svg>
```

*Figure 1. Every provenance question is answered by a schema field, not by free text. Typed component fields carry identity (commit, digest, account), labels carry grouping (boundary, environment, team), externalIds carry the link to the system of record.*

**Text description of Figure 1**

The target array as a provenance record. An hdf-results document whose root fields and components array each answer one provenance question: boundary, pipeline, source repository, built artifact, cloud account, CMDB record, and environment.

- Group "hdf-results (one assessment run)" contains: systemRef - portal-prod.hdf-system.json; runner, tool, generator - CI job execution context.
- Group "components[] - the target array" contains: type = repository - url, branch, commit; type = containerImage - registry, repository, tag, integrity[]; type = cloudAccount - provider, accountId, region - externalIds { cmdb, aws }; labels (on every component) - system, component, environment, team.
- systemRef - portal-prod.hdf-system.json points to Boundary / ATO system: systemRef.
- labels (on every component) - system, component, environment, team points to Boundary / ATO system (dashed): labels.system.
- runner, tool, generator - CI job execution context points to Pipeline / CI job: runner, tool, generator - + custom label pipeline-id.
- type = repository - url, branch, commit points to Source repository: url, branch, commit.
- type = containerImage - registry, repository, tag, integrity[] points to Built artifact: integrity[] digest, tag.
- type = cloudAccount - provider, accountId, region - externalIds { cmdb, aws } points to Cloud account: accountId, region.
- type = cloudAccount - provider, accountId, region - externalIds { cmdb, aws } points to CMDB / asset record: externalIds.cmdb / .emass.
- labels (on every component) - system, component, environment, team points to Environment and owner: labels.environment, labels.team, owner.

| Provenance question | HDF v3 field(s) | Kind |
|---|---|---|
| Boundary / ATO system | `systemRef`, `labels.system` | document link, well-known label |
| Pipeline / CI job | `runner`, `tool`, `generator`, `labels.pipeline-id` | root fields, custom label |
| Source repository | `repository` component: `url`, `branch`, `commit` | typed component |
| Built artifact | `containerImage` component: `registry`, `tag`, `integrity[]` | typed component |
| Cloud account | `cloudAccount` component: `provider`, `accountId`, `region` | typed component |
| CMDB / asset record | `externalIds.cmdb`, `externalIds.emass` | external ID map |
| Environment and owner | `labels.environment`, `labels.team`, `owner` | well-known labels, identity |

> **Note:** `pipeline-id` is a custom label. The five well-known label keys are `system`, `component`, `environment`, `region` and `team`.

<details>
<summary>Example components[] with provenance</summary>

```json
{
  "systemRef": "portal-prod.hdf-system.json",
  "components": [
    { "type": "repository", "name": "portal-api",
      "url": "https://gitlab.example.gov/portal/portal-api",
      "branch": "main", "commit": "4f9c2e1",
      "labels": { "system": "Enterprise Portal", "component": "API",
                  "environment": "production", "team": "platform-eng",
                  "pipeline-id": "88231" } },
    { "type": "containerImage", "name": "portal-api:1.8.2",
      "registry": "registry.example.gov", "repository": "portal/portal-api", "tag": "1.8.2",
      "integrity": [ { "algorithm": "sha256", "value": "9b2d..." } ] },
    { "type": "cloudAccount", "name": "portal-govcloud",
      "provider": "aws", "accountId": "123456789012", "region": "us-gov-west-1",
      "externalIds": { "cmdb": "CI0045", "aws": "123456789012" } }
  ]
}
```

</details>

<details>
<summary>Stamp labels in the pipeline</summary>

```bash
# stamp labels at conversion time, or afterward in the pipeline
hdf convert --from nessus scan.nessus -o results.json \
  --labels system="Enterprise Portal",environment=production,region=us-gov-west-1
hdf label set results.json component=API pipeline-id=$CI_PIPELINE_ID
```

</details>

## 2. The System document as the provenance authority

*hdf-system*

Results say what was scanned. The System document says what the boundary contains, and it is the authority those claims are checked against. Components here require a `componentId`, `identifier` ties the system to its FedRAMP or eMASS record, `dataFlows` show which edges cross the boundary, and `controlDesignations` record who provides each control.

```figure
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 520" width="960" height="520" role="img" aria-labelledby="fig-title fig-desc"> <title id="fig-title">The System document as the provenance authority</title>
<desc id="fig-desc">An hdf-system document: system identity fields, an authorization boundary containing five components with componentIds, data flows to an external user endpoint and a cross-system identity provider, and control designations bound to components.</desc>
<rect x="0" y="0" width="960" height="520" fill="#ffffff" />
<defs> <marker id="a2" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="8" markerHeight="8" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#9a5a08" />
</marker>
 </defs>
 <rect x="20" y="20" width="920" height="76" rx="6" fill="#f6ebdc" stroke="#9a5a08" stroke-width="1.5" />
 <text x="36" y="44" font-family="Courier New, Courier, monospace" fill="#9a5a08" font-size="13" font-weight="600">hdf-system</text>
 <text x="924" y="44" text-anchor="end" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">the authorization boundary, maps to OSCAL SSP system-characteristics</text>
 <text x="36" y="68" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">name <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">"Enterprise Portal"</tspan> systemId <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">3b1f...c7d2</tspan> identifier <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">"FR2405012345"</tspan> identifierScheme <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">"fedramp"</tspan></text>
 <text x="36" y="86" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">categorizationLevel <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">moderate</tspan> authorizationStatus <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">authorized</tspan> owner <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">system-owner</tspan> boms[] <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">system-scoped</tspan></text>
 <rect x="200" y="116" width="560" height="384" rx="8" fill="none" stroke="#9a5a08" stroke-width="1.6" stroke-dasharray="7 5" />
 <text x="216" y="137" font-family="Arial, Helvetica, sans-serif" fill="#9a5a08" font-size="10.5">components[] inside the boundary, boundaryDescription</text>
 <rect x="230" y="150" width="190" height="96" rx="4" fill="#ffffff" stroke="#9a5a08" stroke-width="1" />
 <text x="244" y="172" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">API Service</text>
 <text x="244" y="190" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">containerPlatform</text>
 <text x="244" y="208" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">id 9a4e...41c0</text>
 <text x="244" y="226" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">labels.component=API</text>
 <rect x="530" y="150" width="190" height="96" rx="4" fill="#ffffff" stroke="#9a5a08" stroke-width="1" />
 <text x="544" y="172" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">WebTier</text>
 <text x="544" y="190" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">application</text>
 <text x="544" y="208" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">id 7f3c...a91e</text>
 <text x="544" y="226" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">labels.component=WebTier</text>
 <rect x="230" y="300" width="190" height="96" rx="4" fill="#ffffff" stroke="#9a5a08" stroke-width="1" />
 <text x="244" y="322" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Portal DB</text>
 <text x="244" y="340" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">database</text>
 <text x="244" y="358" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">id 2d88...0b17</text>
 <text x="244" y="376" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">externalIds.cmdb CI0112</text>
 <rect x="530" y="300" width="190" height="96" rx="4" fill="#ffffff" stroke="#9a5a08" stroke-width="1" />
 <text x="544" y="322" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Source repo</text>
 <text x="544" y="340" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">repository</text>
 <text x="544" y="358" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">id 5e20...f3aa</text>
 <text x="544" y="376" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">boms[] sbom, cyclonedx</text>
 <rect x="230" y="420" width="490" height="56" rx="4" fill="#ffffff" stroke="#9a5a08" stroke-width="1" />
 <text x="244" y="442" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">GovCloud Account <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#16202a" font-weight="400">id c14a...e704</tspan></text>
 <text x="244" y="462" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">cloudAccount, us-gov-west-1, externalIds.cmdb CI0045</text>
 <rect x="780" y="150" width="160" height="60" rx="4" fill="#f3f6f7" stroke="#56636f" stroke-width="1.2" stroke-dasharray="4 3" />
 <text x="794" y="174" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Internet users</text>
 <text x="794" y="194" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">external: true</text>
 <rect x="20" y="150" width="160" height="96" rx="4" fill="#f3f6f7" stroke="#56636f" stroke-width="1.2" stroke-dasharray="4 3" />
 <text x="34" y="172" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Enterprise IdP</text>
 <text x="34" y="190" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">another hdf-system</text>
 <text x="34" y="208" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">OAuth2, cross-system</text>
 <text x="34" y="226" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">{systemRef,</text>
 <text x="34" y="240" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5"> componentId}</text>
 <line x1="780" y1="180" x2="725" y2="180" marker-end="url(#a2)" fill="none" stroke="#9a5a08" stroke-width="1.5" />
 <text x="790" y="228" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">https :443 inbound</text>
 <line x1="530" y1="198" x2="425" y2="198" marker-end="url(#a2)" fill="none" stroke="#9a5a08" stroke-width="1.5" />
 <text x="477" y="190" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">https, mTLS</text>
 <line x1="325" y1="246" x2="325" y2="295" marker-end="url(#a2)" fill="none" stroke="#9a5a08" stroke-width="1.5" />
 <text x="333" y="276" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">jdbc :5432</text>
 <line x1="230" y1="198" x2="185" y2="198" marker-end="url(#a2)" fill="none" stroke="#9a5a08" stroke-width="1.5" />
 <rect x="780" y="262" width="160" height="238" rx="4" fill="#ffffff" stroke="#9a5a08" stroke-width="1" />
 <text x="792" y="284" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="11.5" font-weight="600">controlDesignations[]</text>
 <line x1="780" y1="294" x2="940" y2="294" stroke="#c7d1d9" stroke-width="1" />
 <text x="794" y="316" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">IA-2, common</text>
 <text x="794" y="332" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">systemRef to IdP</text>
 <text x="794" y="368" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">AC-2, hybrid</text>
 <text x="794" y="384" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">inheritedBy [API,</text>
 <text x="794" y="398" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5"> WebTier]</text>
 <text x="794" y="432" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">SC-7, common</text>
 <text x="794" y="448" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">providedBy to Account</text>
 <line x1="780" y1="448" x2="725" y2="448" marker-end="url(#a2)" fill="none" stroke="#9a5a08" stroke-width="1.4" stroke-dasharray="5 4" />
 </svg>
```

*Figure 2. The System document is the authoritative inventory. Its componentIds are the keys that Plans, Amendments, Evidence Packages and control designations bind to, and its dataFlows show every edge that leaves the boundary, whether to an external endpoint or to a component in another system's document.*

**Text description of Figure 2**

The System document as the provenance authority. An hdf-system document: system identity fields, an authorization boundary containing five components with componentIds, data flows to an external user endpoint and a cross-system identity provider, and control designations bound to components.

- Group "hdf-system - Enterprise Portal, identifier FR2405012345 (fedramp), moderate, authorized" contains: controlDesignations[] - SC-7 common, providedBy - IA-2 common, systemRef - AC-2 hybrid, inheritedBy.
- Group "authorization boundary (boundaryDescription)" contains: WebTier, application - id 7f3c...a91e - targetSelector labels.component=WebTier; API Service, containerPlatform - id 9a4e...41c0 - targetSelector labels.component=API; Portal DB, database - id 2d88...0b17 - externalIds.cmdb CI0112; Source repo, repository - id 5e20...f3aa - boms[] sbom (cyclonedx); GovCloud Account, cloudAccount - id c14a...e704 - us-gov-west-1, externalIds.cmdb CI0045.
- Internet users - external = true points to WebTier, application - id 7f3c...a91e - targetSelector labels.component=WebTier: dataFlow https port 443.
- WebTier, application - id 7f3c...a91e - targetSelector labels.component=WebTier points to API Service, containerPlatform - id 9a4e...41c0 - targetSelector labels.component=API: dataFlow https, mTLS.
- API Service, containerPlatform - id 9a4e...41c0 - targetSelector labels.component=API points to Portal DB, database - id 2d88...0b17 - externalIds.cmdb CI0112: dataFlow jdbc port 5432.
- API Service, containerPlatform - id 9a4e...41c0 - targetSelector labels.component=API points to Enterprise IdP - another hdf-system - { systemRef, componentId }: dataFlow OAuth2 (cross-system).
- controlDesignations[] - SC-7 common, providedBy - IA-2 common, systemRef - AC-2 hybrid, inheritedBy points to GovCloud Account, cloudAccount - id c14a...e704 - us-gov-west-1, externalIds.cmdb CI0045 (dashed): SC-7 providedBy.
- controlDesignations[] - SC-7 common, providedBy - IA-2 common, systemRef - AC-2 hybrid, inheritedBy points to Enterprise IdP - another hdf-system - { systemRef, componentId } (dashed): IA-2 systemRef.
- controlDesignations[] - SC-7 common, providedBy - IA-2 common, systemRef - AC-2 hybrid, inheritedBy points to API Service, containerPlatform - id 9a4e...41c0 - targetSelector labels.component=API (dashed): AC-2 inheritedBy.
- controlDesignations[] - SC-7 common, providedBy - IA-2 common, systemRef - AC-2 hybrid, inheritedBy points to WebTier, application - id 7f3c...a91e - targetSelector labels.component=WebTier (dashed): AC-2 inheritedBy.

| System field | Provenance role |
|---|---|
| `systemId`, `identifier`, `identifierScheme` | Stable identity; link to the FedRAMP package or eMASS record |
| `components[].componentId` | Required here; the key Plans, Amendments, Evidence Packages and control designations bind to |
| `components[].targetSelector` | Label selector that pulls matching Results components into this System component |
| `components[].externalIds` | Link to CMDB, AWS, Azure or eMASS inventory |
| `dataFlows[]` | Edges between components, to another system (`{systemRef, componentId}`), or to an external endpoint |
| `controlDesignations[]` | `common` / `system-specific` / `hybrid`, with `providedBy`, `systemRef` or `inheritedBy` |
| `boms[]` | System-scoped BOMs; component-scoped BOMs attach on the component |

<details>
<summary>Example hdf-system (abridged)</summary>

```json
{
  "name": "Enterprise Portal",
  "systemId": "3b1f6a0e-2c4d-4e8a-9f1b-6d2e8c47c7d2",
  "identifier": "FR2405012345", "identifierScheme": "fedramp",
  "categorizationLevel": "moderate", "authorizationStatus": "authorized",
  "components": [
    { "componentId": "7f3c2b10-5d4e-4a61-8c2f-0b9e1d6aa91e",
      "name": "WebTier", "type": "application",
      "targetSelector": { "labels.component": "WebTier" },
      "baselineRefs": [ "RHEL9-STIG" ],
      "externalIds": { "cmdb": "CI0101" } },
    { "componentId": "c14a9e62-7d0b-4f38-8e5a-2b6f3d91e704",
      "name": "GovCloud Account", "type": "cloudAccount",
      "provider": "aws", "accountId": "123456789012", "region": "us-gov-west-1",
      "externalIds": { "cmdb": "CI0045" } }
  ],
  "dataFlows": [
    { "from": "7f3c2b10-5d4e-4a61-8c2f-0b9e1d6aa91e",
      "to":   "9a4e7c21-3f5b-4d8e-a2c6-7e1f0d9b41c0",
      "protocol": "https", "port": 443, "authentication": "mTLS",
      "direction": "unidirectional" },
    { "from": "9a4e7c21-3f5b-4d8e-a2c6-7e1f0d9b41c0",
      "to": { "systemRef": "enterprise-idp.hdf-system.json",
              "componentId": "0e61d2c8-4a97-4b3e-9c15-8f2a7d6b3e90" },
      "protocol": "https", "authentication": "OAuth2" }
  ],
  "controlDesignations": [
    { "controlId": "SC-7", "designation": "common",
      "description": "Boundary protection provided by the GovCloud VPC",
      "providedBy": "c14a9e62-7d0b-4f38-8e5a-2b6f3d91e704" }
  ]
}
```

</details>

## 3. Correlating Results targets with the System

*hdf-results and hdf-system*

Results and System meet at five join points. `systemRef` ties the whole file to a boundary. After that, each Results component resolves to a System component in one of three ways: a label match through `targetSelector`, an exact `componentId`, or a shared `externalIds` value. The baselines that ran are then checked against the component's `baselineRefs`.

```figure
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 580" width="960" height="580" role="img" aria-labelledby="fig-title fig-desc"> <title id="fig-title">Correlating Results targets with the System</title>
<desc id="fig-desc">Side by side hdf-results and hdf-system documents joined by systemRef, label to targetSelector matching, componentId equality, externalIds CMDB matching, and baseline name to baselineRefs, feeding a system-aware roll-up.</desc>
<rect x="0" y="0" width="960" height="580" fill="#ffffff" />
<defs> <marker id="a3" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="8" markerHeight="8" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#16202a" />
</marker>
 </defs>
 <rect x="20" y="20" width="300" height="444" rx="6" fill="#e2f1ef" stroke="#0d7069" stroke-width="1.5" />
 <text x="36" y="46" font-family="Courier New, Courier, monospace" fill="#0d7069" font-size="13" font-weight="600">hdf-results</text>
 <rect x="640" y="20" width="300" height="444" rx="6" fill="#f6ebdc" stroke="#9a5a08" stroke-width="1.5" />
 <text x="656" y="46" font-family="Courier New, Courier, monospace" fill="#9a5a08" font-size="13" font-weight="600">hdf-system</text>
 <rect x="34" y="72" width="272" height="48" rx="4" fill="#ffffff" stroke="#0d7069" stroke-width="1" />
 <text x="46" y="92" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">systemRef</text>
 <text x="46" y="110" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">"portal-prod.hdf-system.json"</text>
 <rect x="654" y="72" width="272" height="48" rx="4" fill="#ffffff" stroke="#9a5a08" stroke-width="1" />
 <text x="666" y="92" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">systemId, name</text>
 <text x="666" y="110" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">3b1f...c7d2, "Enterprise Portal"</text>
 <rect x="34" y="140" width="272" height="72" rx="4" fill="#ffffff" stroke="#0d7069" stroke-width="1" />
 <text x="46" y="160" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">host, ip-10-0-1-50</text>
 <text x="46" y="180" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">labels.component: WebTier</text>
 <text x="46" y="198" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">labels.environment: production</text>
 <rect x="654" y="140" width="272" height="72" rx="4" fill="#ffffff" stroke="#9a5a08" stroke-width="1" />
 <text x="666" y="160" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">WebTier, application</text>
 <text x="666" y="180" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">targetSelector:</text>
 <text x="666" y="198" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">{ "labels.component": "WebTier" }</text>
 <rect x="34" y="232" width="272" height="60" rx="4" fill="#ffffff" stroke="#0d7069" stroke-width="1" />
 <text x="46" y="254" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">containerImage, portal-api:1.8.2</text>
 <text x="46" y="276" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">componentId: 9a4e...41c0</text>
 <rect x="654" y="232" width="272" height="60" rx="4" fill="#ffffff" stroke="#9a5a08" stroke-width="1" />
 <text x="666" y="254" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">API Service, containerPlatform</text>
 <text x="666" y="276" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">componentId: 9a4e...41c0</text>
 <rect x="34" y="312" width="272" height="60" rx="4" fill="#ffffff" stroke="#0d7069" stroke-width="1" />
 <text x="46" y="334" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">cloudAccount, 123456789012</text>
 <text x="46" y="356" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">externalIds.cmdb: CI0045</text>
 <rect x="654" y="312" width="272" height="60" rx="4" fill="#ffffff" stroke="#9a5a08" stroke-width="1" />
 <text x="666" y="334" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">GovCloud Account</text>
 <text x="666" y="356" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">externalIds.cmdb: CI0045</text>
 <rect x="34" y="392" width="272" height="60" rx="4" fill="#ffffff" stroke="#0d7069" stroke-width="1" />
 <text x="46" y="414" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">baselines[].name</text>
 <text x="46" y="436" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">"RHEL9-STIG" to results[].status</text>
 <rect x="654" y="392" width="272" height="60" rx="4" fill="#ffffff" stroke="#9a5a08" stroke-width="1" />
 <text x="666" y="414" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">components[].baselineRefs</text>
 <text x="666" y="436" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">[ "RHEL9-STIG" ]</text>
 <g> <line x1="306" y1="96" x2="370" y2="96" fill="none" stroke="#16202a" stroke-width="1.4" />
 <line x1="590" y1="96" x2="650" y2="96" marker-end="url(#a3)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <rect x="370" y="76" width="220" height="40" rx="20" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="480" y="93" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="12" font-weight="600">systemRef to System</text>
 <text x="480" y="108" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">document-level scope</text>
 <circle cx="306" cy="176" r="3" fill="#16202a" />
<circle cx="654" cy="176" r="3" fill="#16202a" />
 <line x1="306" y1="176" x2="370" y2="176" fill="none" stroke="#16202a" stroke-width="1.4" />
<line x1="590" y1="176" x2="654" y2="176" fill="none" stroke="#16202a" stroke-width="1.4" />
 <rect x="370" y="156" width="220" height="40" rx="20" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="480" y="173" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="12" font-weight="600">labels and targetSelector</text>
 <text x="480" y="188" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">dynamic, all keys must match</text>
 <circle cx="306" cy="262" r="3" fill="#16202a" />
<circle cx="654" cy="262" r="3" fill="#16202a" />
 <line x1="306" y1="262" x2="370" y2="262" fill="none" stroke="#16202a" stroke-width="1.4" />
<line x1="590" y1="262" x2="654" y2="262" fill="none" stroke="#16202a" stroke-width="1.4" />
 <rect x="370" y="242" width="220" height="40" rx="20" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="480" y="259" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="12" font-weight="600">componentId = componentId</text>
 <text x="480" y="274" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">exact, strongest binding</text>
 <circle cx="306" cy="342" r="3" fill="#16202a" />
<circle cx="654" cy="342" r="3" fill="#16202a" />
 <line x1="306" y1="342" x2="370" y2="342" fill="none" stroke="#16202a" stroke-width="1.4" stroke-dasharray="4 3" />
<line x1="590" y1="342" x2="654" y2="342" fill="none" stroke="#16202a" stroke-width="1.4" stroke-dasharray="4 3" />
 <rect x="370" y="322" width="220" height="40" rx="20" fill="#ffffff" stroke="#16202a" stroke-width="1.2" stroke-dasharray="4 3" />
 <text x="480" y="339" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="12" font-weight="600">externalIds.cmdb match</text>
 <text x="480" y="354" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">pipeline convention, CMDB bridge</text>
 <circle cx="306" cy="422" r="3" fill="#16202a" />
<circle cx="654" cy="422" r="3" fill="#16202a" />
 <line x1="306" y1="422" x2="370" y2="422" fill="none" stroke="#16202a" stroke-width="1.4" />
<line x1="590" y1="422" x2="654" y2="422" fill="none" stroke="#16202a" stroke-width="1.4" />
 <rect x="370" y="402" width="220" height="40" rx="20" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="480" y="419" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="12" font-weight="600">baseline name and baselineRefs</text>
 <text x="480" y="434" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">did the required baselines run?</text>
 </g>
 <line x1="170" y1="464" x2="170" y2="493" marker-end="url(#a3)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <line x1="790" y1="464" x2="790" y2="493" marker-end="url(#a3)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <rect x="20" y="496" width="920" height="70" rx="6" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="36" y="518" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">System-aware roll-up</text>
 <text x="36" y="538" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">hdf diff --system portal-prod.hdf-system.json feb-scan.json mar-scan.json <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">to per-component compliance</tspan></text>
 <text x="36" y="556" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">The same componentId scopes Amendments.componentRef, Plan assessments.componentRef, and Evidence Package contents[].componentRef</text>
 </svg>
```

*Figure 3. Solid joins are defined by the spec. The dashed externalIds join is a convention your pipeline can enforce: the schema defines the map (aws, azure, cmdb, emass keys) but does not treat it as a correlation key. Prefer componentId when the producer can stamp it, and use targetSelector so new hosts join their System component through labels without an edit to the System document.*

**Text description of Figure 3**

Correlating Results targets with the System. Side by side hdf-results and hdf-system documents joined by systemRef, label to targetSelector matching, componentId equality, externalIds CMDB matching, and baseline name to baselineRefs, feeding a system-aware roll-up.

- Group "hdf-results" contains: systemRef - portal-prod.hdf-system.json; host, ip-10-0-1-50 - labels.component = WebTier - labels.environment = production; containerImage, portal-api 1.8.2 - componentId = 9a4e...41c0; cloudAccount, 123456789012 - externalIds.cmdb = CI0045; baselines[].name - RHEL9-STIG to results[].status.
- Group "hdf-system" contains: systemId, name - 3b1f...c7d2, Enterprise Portal; WebTier, application - targetSelector { labels.component = WebTier }; API Service, containerPlatform - componentId = 9a4e...41c0; GovCloud Account - externalIds.cmdb = CI0045; components[].baselineRefs - [ RHEL9-STIG ].
- systemRef - portal-prod.hdf-system.json points to systemId, name - 3b1f...c7d2, Enterprise Portal: systemRef to System (document scope).
- host, ip-10-0-1-50 - labels.component = WebTier - labels.environment = production and WebTier, application - targetSelector { labels.component = WebTier } are linked both ways: labels matches targetSelector (dynamic, all keys match).
- containerImage, portal-api 1.8.2 - componentId = 9a4e...41c0 and API Service, containerPlatform - componentId = 9a4e...41c0 are linked both ways: componentId = componentId (exact, strongest).
- cloudAccount, 123456789012 - externalIds.cmdb = CI0045 and GovCloud Account - externalIds.cmdb = CI0045 are linked both ways (dashed): externalIds.cmdb (pipeline convention).
- baselines[].name - RHEL9-STIG to results[].status and components[].baselineRefs - [ RHEL9-STIG ] are linked both ways: baseline name matches baselineRefs.
- hdf-results points to System-aware roll-up - hdf diff --system portal-prod.hdf-system.json feb.json mar.json - to per-component compliance - componentId also scopes Amendments, Plan and Evidence Package refs.
- hdf-system points to System-aware roll-up - hdf diff --system portal-prod.hdf-system.json feb.json mar.json - to per-component compliance - componentId also scopes Amendments, Plan and Evidence Package refs.

| Join | Results side | System side | Strength |
|---|---|---|---|
| Document scope | `systemRef` | the System file (`systemId`, `name`) | defined by spec |
| Label selector | `components[].labels` | `components[].targetSelector` | defined by spec, dynamic, all keys must match |
| Component identity | `components[].componentId` | `components[].componentId` | defined by spec, exact, strongest |
| System of record | `components[].externalIds.cmdb` | `components[].externalIds.cmdb` | pipeline convention |
| Baseline coverage | `baselines[].name` | `components[].baselineRefs` | defined by spec |

> **Note:** The schema defines the `externalIds` map (`aws`, `azure`, `cmdb`, `emass`) but does not treat it as a correlation key; enforce it in your pipeline if you rely on it. Prefer `componentId` when the producer can stamp it, and use `targetSelector` so new hosts join their System component through labels without an edit to the System document.

<details>
<summary>Pipeline commands for the join</summary>

```bash
# 1. Stamp the label the System's targetSelector expects
hdf label set results.json system="Enterprise Portal" component=WebTier environment=production

# 2. Inspect what will match
hdf label show results.json

# 3. Roll results up against the boundary
hdf diff --system portal-prod.hdf-system.json feb-scan.json mar-scan.json
```

</details>

---

Example identifiers, UUIDs and account numbers are illustrative.

**Sources**

- [HDF v3.7.0 Specification](https://mitre.github.io/hdf-libs/docs/specification/hdf-specification.html)
- [Well-Known Label Keys Reference](https://mitre.github.io/hdf-libs/docs/guides/label-keys-reference.html)
- [hdf-libs #354: SAF supplement normalization](https://github.com/mitre/hdf-libs/pull/354)
- [hdf-libs #370: hdf target / passthrough commands](https://github.com/mitre/hdf-libs/pull/370)
