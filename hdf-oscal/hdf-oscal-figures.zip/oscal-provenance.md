# OSCAL Provenance Chain

Every OSCAL document carries three kinds of provenance. Metadata says who produced it, when, and who approved it. Control responses say how each control is met, by which component, and who is responsible. Back-matter holds the evidence itself, located by URI and pinned by hash. All of it is linked by UUID, so a tool can follow a claim to its evidence without a person reading a PDF. That traversal is what makes automated assessment possible.

Field names and enumerations follow the OSCAL v1.2.3 JSON schemas; every JSON example on this page validates against them.

> How to read the diagrams: every box sits inside a labeled group or carries its document name (metadata, SSP, back-matter, SAR), and every connection is labeled with the field that links it. Color repeats that grouping but carries no extra meaning. Each figure has a numbered caption and a text description.

## Terms

- **OSCAL**: Open Security Controls Assessment Language
- **SSP**: System Security Plan
- **SAP**: Security Assessment Plan
- **SAR**: Security Assessment Results
- **POAM**: Plan of Action and Milestones
- **ODP**: Organization-defined parameter
- **HDF**: Heimdall Data Format
- **UUID**: Universally unique identifier

## 1. Metadata answers who, when, and which version

*metadata (on every OSCAL document)*

The `metadata` block is required on every catalog, profile, component definition, SSP, SAP, SAR and POAM. Four fields are mandatory: `title`, `last-modified`, `version` and `oscal-version`. The optional parts carry the rest of the provenance: a change history in `revisions`, stable identity in `document-ids`, accountable people through `roles`, `responsible-parties` and `parties`, and approvals recorded as `actions`.

```figure
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 520" width="960" height="520" role="img" aria-labelledby="fig-title fig-desc"> <title id="fig-title">Metadata answers who, when, and which version</title>
<desc id="fig-desc">The OSCAL metadata block with six field groups, each answering one provenance question: when it was produced, which release and schema, what changed, whether it is the same document, who is accountable, and who approved it.</desc>
<rect x="0" y="0" width="960" height="520" fill="#ffffff" />
<defs><marker id="m1" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="8" markerHeight="8" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#16202a" />
</marker>
</defs>
 <rect x="40" y="30" width="400" height="470" rx="6" fill="#e4ecf7" stroke="#2d5896" stroke-width="1.5" />
 <text x="56" y="56" font-family="Courier New, Courier, monospace" fill="#2d5896" font-size="13" font-weight="600">metadata</text>
 <text x="424" y="56" text-anchor="end" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">required on every OSCAL document</text>
 <rect x="56" y="80" width="368" height="56" rx="4" fill="#ffffff" stroke="#2d5896" stroke-width="1" />
 <text x="70" y="102" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">last-modified*, published</text>
 <text x="70" y="123" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">2026-09-28T14:02:00-05:00</text>
 <rect x="56" y="146" width="368" height="56" rx="4" fill="#ffffff" stroke="#2d5896" stroke-width="1" />
 <text x="70" y="168" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">version*, oscal-version*</text>
 <text x="70" y="189" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">"3.2.0", "1.2.3"</text>
 <rect x="56" y="212" width="368" height="56" rx="4" fill="#ffffff" stroke="#2d5896" stroke-width="1" />
 <text x="70" y="234" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">revisions[]</text>
 <text x="70" y="255" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">version, last-modified, remarks per change</text>
 <rect x="56" y="278" width="368" height="56" rx="4" fill="#ffffff" stroke="#2d5896" stroke-width="1" />
 <text x="70" y="300" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">document-ids[]</text>
 <text x="70" y="321" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">{ scheme, identifier } stable across versions</text>
 <rect x="56" y="344" width="368" height="78" rx="4" fill="#ffffff" stroke="#2d5896" stroke-width="1" />
 <text x="70" y="366" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">roles[] to responsible-parties[] to parties[]</text>
 <text x="70" y="388" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">role-id: "system-owner" to party-uuids[]</text>
 <text x="70" y="410" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">party: uuid, type, name, external-ids</text>
 <rect x="56" y="432" width="368" height="56" rx="4" fill="#ffffff" stroke="#2d5896" stroke-width="1" />
 <text x="70" y="454" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">actions[]</text>
 <text x="70" y="475" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">uuid, date, type, system, responsible-parties</text>
 <line x1="424" y1="108" x2="596" y2="108" marker-end="url(#m1)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <line x1="424" y1="174" x2="596" y2="174" marker-end="url(#m1)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <line x1="424" y1="240" x2="596" y2="240" marker-end="url(#m1)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <line x1="424" y1="306" x2="596" y2="306" marker-end="url(#m1)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <line x1="424" y1="383" x2="596" y2="383" marker-end="url(#m1)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <line x1="424" y1="460" x2="596" y2="460" marker-end="url(#m1)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <rect x="600" y="83" width="320" height="50" rx="4" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="614" y="102" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">When was it produced?</text>
 <text x="614" y="121" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">timezone-aware timestamps</text>
 <rect x="600" y="149" width="320" height="50" rx="4" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="614" y="168" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Which release, on which schema?</text>
 <text x="614" y="187" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">document version, OSCAL model version</text>
 <rect x="600" y="215" width="320" height="50" rx="4" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="614" y="234" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">What changed, and when?</text>
 <text x="614" y="253" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">history travels inside the file</text>
 <rect x="600" y="281" width="320" height="50" rx="4" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="614" y="300" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Is this the same document?</text>
 <text x="614" y="319" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">identity that survives re-versioning</text>
 <rect x="600" y="358" width="320" height="50" rx="4" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="614" y="377" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Who is accountable?</text>
 <text x="614" y="396" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">roles resolved to named parties</text>
 <rect x="600" y="435" width="320" height="50" rx="4" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="614" y="454" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Who approved it, and when?</text>
 <text x="614" y="473" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">approval recorded as data, with a date</text>
 <text x="920" y="512" text-anchor="end" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">* required. Every responsible-roles[].role-id elsewhere in the document resolves here.</text>
 </svg>
```

*Figure 1. Provenance lives in one block, in the same shape on every model. A role cited anywhere in the document, including in a control response, resolves through metadata to a named party. An approval is an action with a date and a responsible party, not a signature image.*

**Text description of Figure 1**

Metadata answers who, when, and which version. The OSCAL metadata block with six field groups, each answering one provenance question: when it was produced, which release and schema, what changed, whether it is the same document, who is accountable, and who approved it.

- Group "metadata (required on every OSCAL document)" contains: last-modified (req), published - 2026-09-28; version (req), oscal-version (req) - 3.2.0, 1.2.3; revisions[] - version, last-modified, remarks; document-ids[] - { scheme, identifier }; roles[] to responsible-parties[] to parties[] - role-id = system-owner to party-uuids[]; actions[] - uuid, date, type, system, responsible-parties.
- last-modified (req), published - 2026-09-28 points to When was it produced?
- version (req), oscal-version (req) - 3.2.0, 1.2.3 points to Which release, on which schema?
- revisions[] - version, last-modified, remarks points to What changed, and when?
- document-ids[] - { scheme, identifier } points to Is this the same document?
- roles[] to responsible-parties[] to parties[] - role-id = system-owner to party-uuids[] points to Who is accountable?
- actions[] - uuid, date, type, system, responsible-parties points to Who approved it, and when?

| Provenance question | Metadata field(s) |
|---|---|
| When was it produced? | `last-modified`\*, `published` |
| Which release, on which schema? | `version`\*, `oscal-version`\* |
| What changed, and when? | `revisions[]` (`version`, `last-modified`, `remarks`) |
| Is this the same document? | `document-ids[]` (`scheme`, `identifier`) |
| Who is accountable? | `roles[]` to `responsible-parties[]` (`role-id`, `party-uuids`) to `parties[]` |
| Who approved it, and when? | `actions[]` (`uuid`, `date`, `type`, `system`, `responsible-parties`) |

> **Note:** \* required. Every `responsible-roles[].role-id` elsewhere in the document resolves through metadata to a named party.

<details>
<summary>Example metadata (SSP)</summary>

```json
"metadata": {
  "title": "Enterprise Portal System Security Plan",
  "published": "2026-09-01T09:00:00-05:00",
  "last-modified": "2026-09-28T14:02:00-05:00",
  "version": "3.2.0",
  "oscal-version": "1.2.3",
  "revisions": [
    { "version": "3.1.0", "last-modified": "2026-06-15T10:00:00-05:00",
      "remarks": "Annual review; AC family updated" }
  ],
  "document-ids": [
    { "scheme": "http://www.doi.org/", "identifier": "10.99999/portal-ssp" }
  ],
  "roles": [
    { "id": "system-owner", "title": "System Owner" },
    { "id": "identity-admin", "title": "Identity Administrator" }
  ],
  "parties": [
    { "uuid": "5f2c1a7e-9b3d-4e61-8a0f-2d7c4b91e036", "type": "person",
      "name": "Pat Rivera", "email-addresses": [ "pat.rivera@agency.example.gov" ] }
  ],
  "responsible-parties": [
    { "role-id": "system-owner",
      "party-uuids": [ "5f2c1a7e-9b3d-4e61-8a0f-2d7c4b91e036" ] }
  ],
  "actions": [
    { "uuid": "e71d0c42-6a9b-4f35-b2e8-0c5a1f97d4b3",
      "date": "2026-09-28T15:30:00-05:00",
      "type": "approval", "system": "http://csrc.nist.gov/ns/oscal",
      "responsible-parties": [
        { "role-id": "system-owner",
          "party-uuids": [ "5f2c1a7e-9b3d-4e61-8a0f-2d7c4b91e036" ] } ] }
  ]
}
```

</details>

## 2. Control responses are claims with an address

*system-security-plan, control-implementation*

A control response in OSCAL is structured data, not a paragraph in a Word template. Each `implemented-requirement` names a `control-id`. Each `statement` names the exact catalog part it answers. Each `by-component` entry ties the prose (`description`) to one component, with a status, a responsible role, and links to evidence. Every one of those is a reference a tool can resolve.

```figure
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 520" width="960" height="520" role="img" aria-labelledby="fig-title fig-desc"> <title id="fig-title">Control responses are claims with an address</title>
<desc id="fig-desc">An implemented requirement for AC-2 with a statement for ac-2_smt.a and a by-component entry. Its references resolve to the catalog control and part, a system-implementation component, metadata roles, a back-matter resource, and a leveraged system's exported capability.</desc>
<rect x="0" y="0" width="960" height="520" fill="#ffffff" />
<defs><marker id="m2" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="8" markerHeight="8" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#16202a" />
</marker>
</defs>
 <rect x="40" y="30" width="480" height="400" rx="6" fill="#e2f1ef" stroke="#0d7069" stroke-width="1.5" />
 <text x="56" y="56" font-family="Courier New, Courier, monospace" fill="#0d7069" font-size="13" font-weight="600">control-implementation</text>
 <text x="504" y="56" text-anchor="end" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">system-security-plan</text>
 <rect x="56" y="76" width="448" height="64" rx="4" fill="#ffffff" stroke="#0d7069" stroke-width="1" />
 <text x="70" y="98" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5" font-weight="600">implemented-requirements[]</text>
 <text x="70" y="118" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">uuid 4c1e...07ab, control-id: ac-2</text>
 <text x="70" y="133" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">set-parameters: ac-02_odp.01 = "90 days"</text>
 <rect x="76" y="156" width="428" height="56" rx="4" fill="#ffffff" stroke="#0d7069" stroke-width="1" />
 <text x="90" y="178" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5" font-weight="600">statements[]</text>
 <text x="90" y="199" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">statement-id: ac-2_smt.a, uuid 8d2a...c311</text>
 <rect x="96" y="228" width="408" height="188" rx="4" fill="#ffffff" stroke="#0d7069" stroke-width="1" />
 <text x="110" y="250" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5" font-weight="600">by-components[] <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f" font-weight="400">one per component</tspan></text>
 <text x="110" y="276" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">component-uuid <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">9a4e...41c0</tspan></text>
 <text x="110" y="300" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">description <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">"Accounts are provisioned..." (prose)</tspan></text>
 <text x="110" y="324" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">implementation-status <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">{ state: implemented }</tspan></text>
 <text x="110" y="348" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">responsible-roles <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">role-id: identity-admin</tspan></text>
 <text x="110" y="372" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">links <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">href "#b7f0...", rel reference</tspan></text>
 <text x="110" y="396" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">inherited <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">provided-uuid (leveraged system)</tspan></text>
 <path d="M504,108 C560,108 560,108 596,108" marker-end="url(#m2)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <path d="M504,184 C560,184 560,184 596,184" marker-end="url(#m2)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <path d="M504,272 C560,272 560,268 596,268" marker-end="url(#m2)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <path d="M504,344 C560,344 560,332 596,332" marker-end="url(#m2)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <path d="M504,368 C560,368 560,396 596,396" marker-end="url(#m2)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <path d="M504,392 C552,392 552,460 596,460" marker-end="url(#m2)" fill="none" stroke="#16202a" stroke-width="1.4" stroke-dasharray="5 4" />
 <rect x="600" y="83" width="320" height="50" rx="4" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="614" y="102" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Catalog control, via import-profile</text>
 <text x="614" y="121" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">ac-2, parameter ac-02_odp.01</text>
 <rect x="600" y="159" width="320" height="50" rx="4" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="614" y="178" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">The exact catalog part answered</text>
 <text x="614" y="197" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">part id ac-2_smt.a</text>
 <rect x="600" y="243" width="320" height="50" rx="4" fill="#ffffff" stroke="#0d7069" stroke-width="1" />
 <text x="614" y="262" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">system-implementation.components[]</text>
 <text x="614" y="281" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">uuid 9a4e...41c0, type, status</text>
 <rect x="600" y="307" width="320" height="50" rx="4" fill="#ffffff" stroke="#2d5896" stroke-width="1" />
 <text x="614" y="326" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">metadata roles[] to parties[]</text>
 <text x="614" y="345" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">identity-admin resolves to a named party</text>
 <rect x="600" y="371" width="320" height="50" rx="4" fill="#ffffff" stroke="#9a5a08" stroke-width="1" />
 <text x="614" y="390" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">back-matter.resources[]</text>
 <text x="614" y="409" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">#b7f0... to procedure file + SHA-256</text>
 <rect x="600" y="435" width="320" height="50" rx="4" fill="#f3f6f7" stroke="#56636f" stroke-width="1.2" stroke-dasharray="4 3" />
 <text x="614" y="454" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Leveraged system's export</text>
 <text x="614" y="473" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">provided[], responsibilities[] to satisfied</text>
 <text x="56" y="458" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">implementation-status.state: implemented, partial, planned, alternative, not-applicable</text>
 <text x="56" y="476" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">by-component requires component-uuid, uuid and description</text>
 </svg>
```

*Figure 2. The prose is still there, and it is what the assessor judges. But it is attached to a control part, a component, a role and an evidence resource, each by identifier. Inheritance is also explicit: inherited.provided-uuid points at what a leveraged system exports, and satisfied.responsibility-uuid records that the customer side of a shared responsibility was met.*

**Text description of Figure 2**

Control responses are claims with an address. An implemented requirement for AC-2 with a statement for ac-2_smt.a and a by-component entry. Its references resolve to the catalog control and part, a system-implementation component, metadata roles, a back-matter resource, and a leveraged system's exported capability.

- Group "system-security-plan, control-implementation" contains: implemented-requirements[] - control-id = ac-2 - set-parameters ac-02_odp.01 = 90 days; statements[] - statement-id = ac-2_smt.a, uuid 8d2a...c311; by-components[] - component-uuid, description (prose) - implementation-status, responsible-roles - links, inherited.
- implemented-requirements[] - control-id = ac-2 - set-parameters ac-02_odp.01 = 90 days points to statements[] - statement-id = ac-2_smt.a, uuid 8d2a...c311.
- statements[] - statement-id = ac-2_smt.a, uuid 8d2a...c311 points to by-components[] - component-uuid, description (prose) - implementation-status, responsible-roles - links, inherited.
- implemented-requirements[] - control-id = ac-2 - set-parameters ac-02_odp.01 = 90 days points to Catalog control via import-profile - ac-2, ac-02_odp.01: control-id.
- statements[] - statement-id = ac-2_smt.a, uuid 8d2a...c311 points to Catalog part - ac-2_smt.a: statement-id.
- by-components[] - component-uuid, description (prose) - implementation-status, responsible-roles - links, inherited points to system-implementation.components[] - uuid 9a4e...41c0: component-uuid.
- by-components[] - component-uuid, description (prose) - implementation-status, responsible-roles - links, inherited points to metadata roles[] to parties[]: responsible-roles.role-id.
- by-components[] - component-uuid, description (prose) - implementation-status, responsible-roles - links, inherited points to back-matter.resources[] - #b7f0... to file + SHA-256: links[].href #uuid.
- by-components[] - component-uuid, description (prose) - implementation-status, responsible-roles - links, inherited points to Leveraged system's export - provided[], responsibilities[] (dashed): inherited.provided-uuid.

| Field | Resolves to |
|---|---|
| `implemented-requirements[].control-id` | Catalog control, through `import-profile` |
| `set-parameters[].param-id` | Catalog/profile parameter (e.g. `ac-02_odp.01`) |
| `statements[].statement-id` | The exact catalog part (e.g. `ac-2_smt.a`) |
| `by-components[].component-uuid` | `system-implementation.components[].uuid` |
| `by-components[].responsible-roles[].role-id` | `metadata.roles[]` to `parties[]` |
| `by-components[].links[].href` (`#uuid`) | `back-matter.resources[]` |
| `by-components[].inherited.provided-uuid` | A leveraged system's `export.provided[]` |
| `by-components[].satisfied.responsibility-uuid` | A leveraged system's `export.responsibilities[]` |

> **Note:** `implementation-status.state` is one of `implemented`, `partial`, `planned`, `alternative`, `not-applicable`. A `by-component` requires `component-uuid`, `uuid` and `description`.

<details>
<summary>Example implemented-requirement</summary>

```json
{
  "uuid": "4c1e2f90-7d3a-4b58-9e61-a2c8f5d307ab",
  "control-id": "ac-2",
  "set-parameters": [
    { "param-id": "ac-02_odp.01", "values": [ "90 days" ] }
  ],
  "statements": [
    { "statement-id": "ac-2_smt.a",
      "uuid": "8d2a6b14-3e0f-4c97-a5d2-7f19e4b8c311",
      "by-components": [
        { "component-uuid": "9a4e7c21-3f5b-4d8e-a2c6-7e1f0d9b41c0",
          "uuid": "0b6f3e58-21c4-4a9d-8f73-e5d20c1a9b46",
          "description": "Accounts are provisioned through the IdP group workflow; each group maps to one application role.",
          "implementation-status": { "state": "implemented" },
          "responsible-roles": [ { "role-id": "identity-admin" } ],
          "links": [
            { "href": "#b7f04d29-8c1e-4f6a-9b35-d20e7a61c5f8", "rel": "reference",
              "text": "Account Management Procedure v4" } ] }
      ] }
  ]
}
```

</details>

## 3. Back-matter pins the evidence

*back-matter (on every OSCAL document)*

A `resource` in `back-matter` is where a reference lands. Anything in the document can point to it with `href: "#uuid"`. The resource then says what the thing is (`title`, `document-ids`, `citation`), where to fetch it (`rlinks[].href` with a `media-type`), and what it must hash to (`rlinks[].hashes`). It can also carry an embedded copy in `base64`. A reference plus a hash lets a tool check that the evidence is the same file the author cited.

```figure
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 490" width="960" height="490" role="img" aria-labelledby="fig-title fig-desc"> <title id="fig-title">Back-matter pins the evidence</title>
<desc id="fig-desc">Four kinds of references point by fragment identifier into one back-matter resource. The resource's rlinks locate a results file and a procedure document, and its SHA-256 hashes let a tool verify both.</desc>
<rect x="0" y="0" width="960" height="490" fill="#ffffff" />
<defs> <marker id="m3" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="8" markerHeight="8" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#16202a" />
</marker>
 <marker id="m3b" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="8" markerHeight="8" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#9a5a08" />
</marker>
 </defs>
 <text x="20" y="44" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">points in with href "#uuid"</text>
 <rect x="20" y="60" width="260" height="56" rx="4" fill="#ffffff" stroke="#0d7069" stroke-width="1" />
 <text x="34" y="82" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">import-profile.href</text>
 <text x="34" y="102" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">the baseline this SSP applies</text>
 <rect x="20" y="136" width="260" height="56" rx="4" fill="#ffffff" stroke="#0d7069" stroke-width="1" />
 <text x="34" y="158" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">by-components[].links[].href</text>
 <text x="34" y="178" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">evidence for one control response</text>
 <rect x="20" y="212" width="260" height="56" rx="4" fill="#ffffff" stroke="#0d7069" stroke-width="1" />
 <text x="34" y="234" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">relevant-evidence[].href</text>
 <text x="34" y="254" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">evidence for one SAR observation</text>
 <rect x="20" y="288" width="260" height="56" rx="4" fill="#ffffff" stroke="#2d5896" stroke-width="1" />
 <text x="34" y="310" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">diagrams[].links, parties[].links</text>
 <text x="34" y="330" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">boundary diagrams, logos, contracts</text>
 <path d="M280,88 C312,88 312,150 336,150" marker-end="url(#m3)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <path d="M280,164 C312,164 312,170 336,170" marker-end="url(#m3)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <path d="M280,240 C312,240 312,190 336,190" marker-end="url(#m3)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <path d="M280,316 C312,316 312,210 336,210" marker-end="url(#m3)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <rect x="340" y="40" width="300" height="400" rx="6" fill="#f6ebdc" stroke="#9a5a08" stroke-width="1.5" />
 <text x="356" y="66" font-family="Courier New, Courier, monospace" fill="#9a5a08" font-size="13" font-weight="600">back-matter.resources[]</text>
 <line x1="340" y1="80" x2="640" y2="80" stroke="#c7d1d9" stroke-width="1" />
 <text x="356" y="104" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">uuid* <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">b7f04d29-...-d20e7a61c5f8</tspan></text>
 <text x="356" y="128" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">title <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">"Account Management Procedure v4"</tspan></text>
 <text x="356" y="152" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">document-ids <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">[{ scheme, identifier }]</tspan></text>
 <text x="356" y="176" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">citation <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">{ text* }</tspan></text>
 <text x="356" y="200" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">props <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">[{ name, value, ns }]</tspan></text>
 <rect x="356" y="218" width="268" height="118" rx="4" fill="#ffffff" stroke="#9a5a08" stroke-width="1" />
 <text x="370" y="240" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5" font-weight="600">rlinks[]</text>
 <text x="370" y="262" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">href* <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">https://evidence.../proc-v4.pdf</tspan></text>
 <text x="370" y="284" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">media-type <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">application/pdf</tspan></text>
 <text x="370" y="306" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">hashes <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">[{ algorithm: SHA-256,</tspan></text>
 <text x="370" y="324" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5"> value: 3f9a... }]</text>
 <rect x="356" y="350" width="268" height="72" rx="4" fill="#ffffff" stroke="#9a5a08" stroke-width="1" stroke-dasharray="4 3" />
 <text x="370" y="372" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5" font-weight="600">base64 <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f" font-weight="400">optional embedded copy</tspan></text>
 <text x="370" y="394" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">filename, media-type, value*</text>
 <text x="370" y="412" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">travels with the document</text>
 <path d="M624,262 C660,262 660,120 700,120" marker-end="url(#m3b)" fill="none" stroke="#9a5a08" stroke-width="1.5" />
 <rect x="704" y="92" width="236" height="56" rx="4" fill="#f3f6f7" stroke="#56636f" stroke-width="1.2" stroke-dasharray="4 3" />
 <text x="718" y="114" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Document repository</text>
 <text x="718" y="134" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">proc-v4.pdf, application/pdf</text>
 <rect x="704" y="182" width="236" height="56" rx="4" fill="#f3f6f7" stroke="#56636f" stroke-width="1.2" stroke-dasharray="4 3" />
 <text x="718" y="204" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Evidence store</text>
 <text x="718" y="224" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">c93d... to results.hdf.json</text>
 <path d="M624,312 C680,312 680,318 700,318" marker-end="url(#m3b)" fill="none" stroke="#9a5a08" stroke-width="1.5" />
 <rect x="704" y="282" width="236" height="72" rx="4" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="718" y="304" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Verify before trusting</text>
 <text x="718" y="324" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">fetch href to SHA-256 to</text>
 <text x="718" y="342" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">compare with hashes[].value</text>
 <text x="20" y="462" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">* required. OSCAL hash algorithms: SHA-224/256/384/512, SHA3-224/256/384/512.</text>
 <text x="20" y="478" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">Each resource has its own rlinks, the evidence store is the target of a second resource with the same shape.</text>
 </svg>
```

*Figure 3. One resource, many referrers. The SSP, the SAP and the SAR each have their own back-matter, and every link, import and evidence reference resolves the same way: fragment identifier to resource, resource to location, location to hash.*

**Text description of Figure 3**

Back-matter pins the evidence. Four kinds of references point by fragment identifier into one back-matter resource. The resource's rlinks locate a results file and a procedure document, and its SHA-256 hashes let a tool verify both.

- Group "back-matter.resources[]" contains: rlinks[] - href (req), media-type - hashes [{ algorithm = SHA-256, value }]; uuid (req), title, document-ids - citation { text (req) }, props; base64 (optional) - filename, media-type, value (req).
- import-profile.href points to back-matter.resources[]: #uuid.
- by-components[].links[].href points to back-matter.resources[]: #uuid.
- relevant-evidence[].href points to back-matter.resources[]: #uuid.
- diagrams[].links, parties[].links points to back-matter.resources[]: #uuid.
- rlinks[] - href (req), media-type - hashes [{ algorithm = SHA-256, value }] points to Document repository - proc-v4.pdf, application/pdf: href.
- Document repository - proc-v4.pdf, application/pdf points to Verify before trusting - SHA-256 must equal rlinks[].hashes[].value: fetched bytes.

| Resource field | Role |
|---|---|
| `uuid`\* | Target of every `href: "#uuid"` in the document |
| `title`, `description`, `document-ids`, `citation` | What the thing is |
| `rlinks[].href`\*, `media-type` | Where to fetch it, and in what format |
| `rlinks[].hashes[]` (`algorithm`, `value`) | What it must hash to: SHA-224/256/384/512 or SHA3-224/256/384/512 |
| `base64` (`filename`, `media-type`, `value`\*) | An embedded copy that travels with the document |

> **Note:** Each resource has its own `rlinks`. The SSP, SAP and SAR each have their own back-matter, and every link, import and evidence reference resolves the same way: fragment identifier to resource, resource to location, location to hash.

<details>
<summary>Example back-matter resources</summary>

```json
"back-matter": {
  "resources": [
    { "uuid": "b7f04d29-8c1e-4f6a-9b35-d20e7a61c5f8",
      "title": "Account Management Procedure v4",
      "citation": { "text": "Enterprise Portal, Account Management Procedure, v4, 2026" },
      "rlinks": [
        { "href": "https://evidence.example.gov/portal/proc-v4.pdf",
          "media-type": "application/pdf",
          "hashes": [ { "algorithm": "SHA-256", "value": "3f9a..." } ] } ] },
    { "uuid": "c93d5e10-4b7a-4d2f-a8e6-91f0b3c72d58",
      "title": "InSpec AC-2 results, pipeline 88231",
      "rlinks": [
        { "href": "https://evidence.example.gov/portal/88231/results.hdf.json",
          "media-type": "application/json",
          "hashes": [ { "algorithm": "SHA-256", "value": "9b2d..." } ] } ] }
  ]
}
```

</details>

<details>
<summary>Verify a resource</summary>

```bash
# verify a resource before using it
curl -sSfo proc-v4.pdf https://evidence.example.gov/portal/proc-v4.pdf
sha256sum proc-v4.pdf   # must equal rlinks[].hashes[].value
```

</details>

## 4. How the three unlock automated assessment

*catalog to profile to SSP to SAP to SAR*

Each model imports the one before it by `href`, so a Security Assessment Results document sits at the end of a resolvable chain. Inside the SAR, an `observation` records who or what collected it (`origins[].actors[]`), what it was about (`subjects[]`), and where the proof is (`relevant-evidence[]`). A `finding` then names the statement it judges and gives a determination. Each of those fields points back to something from views 1 to 3. When every pointer resolves, a tool can assess a control without a person reading a narrative.

```figure
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 610" width="960" height="610" role="img" aria-labelledby="fig-title fig-desc"> <title id="fig-title">How the three unlock automated assessment</title>
<desc id="fig-desc">The import chain from catalog to SAR, and a SAR observation and finding whose actors, subjects, evidence and target resolve back to metadata parties, SSP components, back-matter resources and SSP statements. HDF results convert into the SAR.</desc>
<rect x="0" y="0" width="960" height="610" fill="#ffffff" />
<defs><marker id="m4" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="8" markerHeight="8" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#16202a" />
</marker>
</defs>
 <rect x="20" y="24" width="160" height="58" rx="4" fill="#f3f6f7" stroke="#56636f" stroke-width="1.2" />
 <text x="34" y="47" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Catalog</text>
<text x="34" y="67" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">controls, parts</text>
 <rect x="210" y="24" width="160" height="58" rx="4" fill="#f3f6f7" stroke="#56636f" stroke-width="1.2" />
 <text x="224" y="47" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">Profile</text>
<text x="224" y="67" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">imports[].href</text>
 <rect x="400" y="24" width="160" height="58" rx="4" fill="#e2f1ef" stroke="#0d7069" stroke-width="1.5" />
 <text x="414" y="47" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">SSP</text>
<text x="414" y="67" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">import-profile.href</text>
 <rect x="590" y="24" width="160" height="58" rx="4" fill="#f3f6f7" stroke="#56636f" stroke-width="1.2" />
 <text x="604" y="47" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">SAP</text>
<text x="604" y="67" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">import-ssp.href</text>
 <rect x="780" y="24" width="160" height="58" rx="4" fill="#f3f6f7" stroke="#56636f" stroke-width="1.2" />
 <text x="794" y="47" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">SAR</text>
<text x="794" y="67" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">import-ap.href</text>
 <line x1="210" y1="53" x2="184" y2="53" marker-end="url(#m4)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <line x1="400" y1="53" x2="374" y2="53" marker-end="url(#m4)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <line x1="590" y1="53" x2="564" y2="53" marker-end="url(#m4)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <line x1="780" y1="53" x2="754" y2="53" marker-end="url(#m4)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <rect x="20" y="118" width="380" height="372" rx="6" fill="none" stroke="#56636f" stroke-width="1.2" stroke-dasharray="6 4" />
 <text x="36" y="140" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">what the SAR points back to</text>
 <rect x="40" y="156" width="340" height="50" rx="4" fill="#ffffff" stroke="#2d5896" stroke-width="1" />
 <text x="54" y="176" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">metadata.parties[]</text>
 <text x="54" y="195" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">assessor, when actor type is party</text>
 <rect x="40" y="216" width="340" height="50" rx="4" fill="#ffffff" stroke="#0d7069" stroke-width="1" />
 <text x="54" y="236" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">SSP system-implementation.components[]</text>
 <text x="54" y="255" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">uuid 9a4e...41c0, API Service</text>
 <rect x="40" y="276" width="340" height="50" rx="4" fill="#ffffff" stroke="#9a5a08" stroke-width="1" />
 <text x="54" y="296" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">SAR back-matter.resources[]</text>
 <text x="54" y="315" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">#c93d... to results.hdf.json, SHA-256</text>
 <rect x="40" y="394" width="340" height="68" rx="4" fill="#ffffff" stroke="#0d7069" stroke-width="1" />
 <text x="54" y="414" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">SSP statement ac-2_smt.a</text>
 <text x="54" y="433" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">uuid 8d2a...c311</text>
 <text x="54" y="451" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">by-component prose, status, evidence links</text>
 <rect x="560" y="118" width="380" height="372" rx="6" fill="#f3f6f7" stroke="#56636f" stroke-width="1.2" />
 <text x="576" y="140" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="13" font-weight="600">SAR results[]</text>
 <rect x="576" y="152" width="348" height="162" rx="4" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="590" y="172" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5" font-weight="600">observations[]</text>
 <text x="590" y="196" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">origins.actors <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">type: tool, actor-uuid</tspan></text>
 <text x="590" y="228" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">subjects <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">type: component, subject-uuid</tspan></text>
 <text x="590" y="260" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">relevant-evidence <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">href "#c93d..."</tspan></text>
 <text x="590" y="292" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">methods <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">[TEST], collected, expires</tspan></text>
 <rect x="576" y="330" width="348" height="146" rx="4" fill="#ffffff" stroke="#16202a" stroke-width="1.2" />
 <text x="590" y="350" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5" font-weight="600">findings[]</text>
 <text x="590" y="376" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">target <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">type: statement-id, ac-2_smt.a</tspan></text>
 <text x="590" y="396" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">status: { state: satisfied }</text>
 <text x="590" y="424" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">implementation-statement-uuid</text>
 <text x="590" y="440" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">8d2a...c311</text>
 <text x="590" y="464" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">related-observations <tspan font-size="10.5" font-family="Courier New, Courier, monospace" fill="#56636f">to observation uuid</tspan></text>
 <line x1="730" y1="152" x2="730" y2="86" marker-end="url(#m4)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <text x="736" y="112" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">tool to SAP assessment-assets</text>
 <path d="M576,196 C480,196 480,181 384,181" marker-end="url(#m4)" fill="none" stroke="#16202a" stroke-width="1.4" stroke-dasharray="5 4" />
 <text x="480" y="178" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="10.5">or type: party</text>
 <path d="M576,224 C480,224 480,241 384,241" marker-end="url(#m4)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <path d="M576,256 C480,256 480,301 384,301" marker-end="url(#m4)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <path d="M576,372 C480,372 480,420 384,420" marker-end="url(#m4)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <path d="M576,430 C480,430 480,432 384,432" marker-end="url(#m4)" fill="none" stroke="#16202a" stroke-width="1.4" />
 <rect x="20" y="512" width="920" height="86" rx="6" fill="#e2f1ef" stroke="#0d7069" stroke-width="1.5" />
 <text x="36" y="535" font-family="Arial, Helvetica, sans-serif" fill="#16202a" font-size="13" font-weight="600">HDF Results into the SAR</text>
 <text x="36" y="556" font-family="Courier New, Courier, monospace" fill="#16202a" font-size="10.5">hdf convert --from hdf --to oscal-sar results.json -o sar.json</text>
 <text x="36" y="575" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">baselines[] to results[], requirements[] to findings[], passed to satisfied, failed to not-satisfied</text>
 <text x="36" y="591" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">Convention: reuse the HDF componentId as the OSCAL component uuid so subjects resolve with no lookup table</text>
 <line x1="750" y1="512" x2="750" y2="494" marker-end="url(#m4)" fill="none" stroke="#16202a" stroke-width="1.4" />
 </svg>
```

*Figure 4. Automated assessment is a traversal. From a finding, a tool follows implementation-statement-uuid to the SSP claim, subjects to the component, relevant-evidence to a back-matter resource and its hash, and actors to the tool or party that collected it. If any hop fails to resolve, the evidence chain is incomplete, and the tool can say exactly where.*

**Text description of Figure 4**

How the three unlock automated assessment. The import chain from catalog to SAR, and a SAR observation and finding whose actors, subjects, evidence and target resolve back to metadata parties, SSP components, back-matter resources and SSP statements. HDF results convert into the SAR.

- Group "SAR results[]" contains: observations[] - origins.actors, subjects - relevant-evidence, methods, collected; findings[] - target statement-id ac-2_smt.a, state satisfied - implementation-statement-uuid, related-observations.
- SAR - import-ap.href points to SAP - import-ssp.href.
- SAP - import-ssp.href points to SSP - import-profile.href.
- SSP - import-profile.href points to Profile - imports[].href.
- Profile - imports[].href points to Catalog.
- findings[] - target statement-id ac-2_smt.a, state satisfied - implementation-statement-uuid, related-observations points to observations[] - origins.actors, subjects - relevant-evidence, methods, collected: related-observations.
- observations[] - origins.actors, subjects - relevant-evidence, methods, collected points to SAP - import-ssp.href: actors type = tool.
- observations[] - origins.actors, subjects - relevant-evidence, methods, collected points to metadata.parties[] (dashed): actors type = party.
- observations[] - origins.actors, subjects - relevant-evidence, methods, collected points to SSP system-implementation.components[] - uuid 9a4e...41c0: subjects.subject-uuid.
- observations[] - origins.actors, subjects - relevant-evidence, methods, collected points to SAR back-matter.resources[] - #c93d... to results.hdf.json, SHA-256: relevant-evidence.href #uuid.
- findings[] - target statement-id ac-2_smt.a, state satisfied - implementation-statement-uuid, related-observations points to SSP statement ac-2_smt.a - uuid 8d2a...c311: implementation-statement-uuid.
- findings[] - target statement-id ac-2_smt.a, state satisfied - implementation-statement-uuid, related-observations points to SSP statement ac-2_smt.a - uuid 8d2a...c311: target-id.
- HDF Results - hdf convert --from hdf --to oscal-sar - baselines to results, requirements to findings points to SAR results[].

| SAR field | Resolves to |
|---|---|
| `import-ap.href` | The SAP, which imports the SSP (`import-ssp`), which imports the profile (`import-profile`) |
| `observations[].origins[].actors[]` (`type: tool`) | A tool in the SAP `assessment-assets` |
| `observations[].origins[].actors[]` (`type: party`) | `metadata.parties[]` |
| `observations[].subjects[].subject-uuid` (`type: component`) | SSP `system-implementation.components[].uuid` |
| `observations[].relevant-evidence[].href` | `back-matter.resources[]` to `rlinks` + hash |
| `findings[].target` (`type: statement-id`) | The catalog part answered by the SSP statement |
| `findings[].implementation-statement-uuid` | The SSP statement `uuid` |
| `findings[].related-observations[]` | The observations above |

> **Note:** HDF Results convert into a SAR with `hdf convert --from hdf --to oscal-sar results.json -o sar.json`: baselines become results, requirements become findings, passed becomes satisfied and failed becomes not-satisfied. Reusing the HDF `componentId` as the OSCAL component `uuid` is a convention, not a schema rule; it lets `subjects` resolve with no lookup table.

<details>
<summary>Example observation and finding</summary>

```json
"observations": [
  { "uuid": "a3e8f1d2-5c6b-4a70-9e84-1f2d3c4b5a69",
    "description": "InSpec control ac-2-a: every IdP group maps to one application role.",
    "methods": [ "TEST" ],
    "types": [ "control-objective" ],
    "origins": [ { "actors": [
      { "type": "tool", "actor-uuid": "d4b2c6e8-1f3a-4b5c-9d7e-8f0a1b2c3d4e" } ] } ],
    "subjects": [
      { "subject-uuid": "9a4e7c21-3f5b-4d8e-a2c6-7e1f0d9b41c0", "type": "component" } ],
    "relevant-evidence": [
      { "href": "#c93d5e10-4b7a-4d2f-a8e6-91f0b3c72d58",
        "description": "HDF results from pipeline 88231" } ],
    "collected": "2026-09-29T02:10:00-05:00",
    "expires": "2026-10-29T02:10:00-05:00" }
],
"findings": [
  { "uuid": "f6c1b9a4-2d8e-4e3f-b5a7-0c9d8e7f6a51",
    "title": "AC-2(a) account types defined",
    "description": "Automated test passed against the API Service component.",
    "target": { "type": "statement-id", "target-id": "ac-2_smt.a",
                "status": { "state": "satisfied", "reason": "pass" } },
    "implementation-statement-uuid": "8d2a6b14-3e0f-4c97-a5d2-7f19e4b8c311",
    "related-observations": [
      { "observation-uuid": "a3e8f1d2-5c6b-4a70-9e84-1f2d3c4b5a69" } ] }
]
```

</details>

---

Example identifiers, UUIDs, names and hashes are illustrative.

**Sources**

- [OSCAL v1.2.3 SSP JSON reference](https://pages.nist.gov/OSCAL-Reference/models/v1.2.3/system-security-plan/json-reference/)
- [OSCAL v1.2.3 assessment results JSON outline](https://pages.nist.gov/OSCAL-Reference/models/v1.2.3/assessment-results/json-outline/)
- [OSCAL releases (v1.2.3 schemas)](https://github.com/usnistgov/OSCAL/releases)
- [HDF OSCAL Alignment Guide](https://mitre.github.io/hdf-libs/docs/guides/oscal-alignment.html)
