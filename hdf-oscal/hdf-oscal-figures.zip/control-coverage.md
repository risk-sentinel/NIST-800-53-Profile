# HDF and OSCAL Automation Coverage

Coverage of every statement part in NIST SP 800-53 Rev 5: 1749 parts across the 1014 active controls and enhancements
(each lettered item such as AC-2 d.3 is one part; a control or enhancement with no lettered items is one part).
HDF and OSCAL each work on their own. HDF proves how the system is configured; OSCAL records the claim, its evidence and its
parameters. Together they give 765 parts (44%) automated evidence, and OSCAL can validate the
organization-defined parameter (ODP) values in 530 of the remaining parts.

## Terms

- **HDF**: Heimdall Data Format
- **OSCAL**: Open Security Controls Assessment Language
- **ODP**: Organization-defined parameter, the [Assignment] values in a control
- **POAM**: Plan of Action and Milestones
- **SSP / SAP / SAR**: System Security Plan / Security Assessment Plan / Security Assessment Results
- **ASFF**: AWS Security Finding Format
- **SCAP**: Security Content Automation Protocol
- **CWE**: Common Weakness Enumeration
- **CCI**: Control Correlation Identifier (DISA STIG)
- **STIG**: Security Technical Implementation Guide
- **SRG**: Security Requirements Guide (DISA)
- **SARIF**: Static Analysis Results Interchange Format
- **SBOM**: Software Bill of Materials
- **VEX**: Vulnerability Exploitability eXchange

## Summary

| Measure | Parts | Share |
|---|---|---|
| Automated evidence from HDF or OSCAL | 765 | 44% |
| HDF (explicit part tag, single-part control, or HDF document type) | 348 | 20% |
| HDF counting control-level tags too | 529 | 30% |
| OSCAL evidence (document, record or inheritance) | 454 | 26% |
| Both HDF and OSCAL evidence | 37 | 2% |
| No evidence, but OSCAL validates the ODP value | 530 | 30% |
| Neither: evidence stays human or attested | 454 | 26% |

```figure
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 334" width="960" height="334" role="img" aria-labelledby="fig-title fig-desc"><title id="fig-title">All 1749 statement parts by source of automated evidence</title>
<desc id="fig-desc">Bar chart. HDF only 311 parts (18 percent), HDF and OSCAL evidence 37 parts (2 percent), OSCAL evidence only 417 parts (24 percent), OSCAL ODP check only 530 parts (30 percent), Neither 454 parts (26 percent).</desc>
<rect x="0" y="0" width="960" height="334" fill="#ffffff"/>
<text x="20.0" y="32.0" font-family="Arial, Helvetica, sans-serif" font-size="16" font-weight="700" fill="#16202a" text-anchor="start">All 1,749 statement parts by source of automated evidence</text>
<line x1="250.0" y1="52" x2="250.0" y2="288" stroke="#d5dbe0" stroke-width="1"/>
<text x="250.0" y="314.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="middle">0</text>
<line x1="343.3" y1="52" x2="343.3" y2="288" stroke="#d5dbe0" stroke-width="1"/>
<text x="343.3" y="314.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="middle">100</text>
<line x1="436.7" y1="52" x2="436.7" y2="288" stroke="#d5dbe0" stroke-width="1"/>
<text x="436.7" y="314.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="middle">200</text>
<line x1="530.0" y1="52" x2="530.0" y2="288" stroke="#d5dbe0" stroke-width="1"/>
<text x="530.0" y="314.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="middle">300</text>
<line x1="623.3" y1="52" x2="623.3" y2="288" stroke="#d5dbe0" stroke-width="1"/>
<text x="623.3" y="314.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="middle">400</text>
<line x1="716.7" y1="52" x2="716.7" y2="288" stroke="#d5dbe0" stroke-width="1"/>
<text x="716.7" y="314.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="middle">500</text>
<line x1="810.0" y1="52" x2="810.0" y2="288" stroke="#d5dbe0" stroke-width="1"/>
<text x="810.0" y="314.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="middle">600</text>
<text x="238.0" y="80.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="400" fill="#16202a" text-anchor="end">HDF only</text>
<rect x="250" y="60" width="290.3" height="30" rx="3" fill="#00695c"/>
<text x="548.3" y="80.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="400" fill="#16202a" text-anchor="start">311 (18%)</text>
<text x="238.0" y="128.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="400" fill="#16202a" text-anchor="end">HDF and OSCAL evidence</text>
<rect x="250" y="108" width="34.5" height="30" rx="3" fill="#33691e"/>
<text x="292.5" y="128.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="400" fill="#16202a" text-anchor="start">37 (2%)</text>
<text x="238.0" y="176.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="400" fill="#16202a" text-anchor="end">OSCAL evidence only</text>
<rect x="250" y="156" width="389.2" height="30" rx="3" fill="#9a4a12"/>
<text x="647.2" y="176.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="400" fill="#16202a" text-anchor="start">417 (24%)</text>
<text x="238.0" y="224.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="400" fill="#16202a" text-anchor="end">OSCAL ODP check only</text>
<rect x="250" y="204" width="494.7" height="30" rx="3" fill="#6d5a00"/>
<text x="752.7" y="224.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="400" fill="#16202a" text-anchor="start">530 (30%)</text>
<text x="238.0" y="272.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="400" fill="#16202a" text-anchor="end">Neither</text>
<rect x="250" y="252" width="423.7" height="30" rx="3" fill="#455a64"/>
<text x="681.7" y="272.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="400" fill="#16202a" text-anchor="start">454 (26%)</text>
<text x="250.0" y="330.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="start">statement parts</text>
</svg>
```

*Figure 1. Where the evidence for each of the 1,749 statement parts comes from.*

**Text description of Figure 1**

All 1749 statement parts by source of automated evidence. Bar chart. HDF only 311 parts (18 percent), HDF and OSCAL evidence 37 parts (2 percent), OSCAL evidence only 417 parts (24 percent), OSCAL ODP check only 530 parts (30 percent), Neither 454 parts (26 percent).

- HDF only: 311 (18%).
- HDF and OSCAL: 37 (2%).
- OSCAL evidence only: 417 (24%).
- OSCAL ODP check only: 530 (30%).
- Neither: 454 (26%).

## Where each format reaches

The circles are area-proportional. OSCAL evidence and ODP validation do not overlap by construction: a part counts as an
ODP check only when OSCAL has no stronger evidence for it.

```figure
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 780 464" width="780" height="464" role="img" aria-labelledby="fig-title fig-desc"><title id="fig-title">Statement parts with automated evidence or checks, areas proportional</title>
<desc id="fig-desc">Venn diagram of 1749 statement parts. HDF 348 parts, OSCAL evidence 454, OSCAL ODP check 715. HDF and OSCAL evidence share 37. HDF and ODP check share 185. OSCAL evidence and ODP check share none. 454 parts are outside all three.</desc>
<rect x="0" y="0" width="780" height="464" fill="#ffffff"/>
<text x="20.0" y="32.0" font-family="Arial, Helvetica, sans-serif" font-size="16" font-weight="700" fill="#16202a" text-anchor="start">Parts with automated evidence or checks (areas to scale)</text>
<circle cx="190.1" cy="250" r="150.1" fill="#6d5a00" fill-opacity="0.1" stroke="#6d5a00" stroke-width="2.5"/>
<circle cx="321.9" cy="250" r="104.7" fill="#00695c" fill-opacity="0.1" stroke="#00695c" stroke-width="2.5"/>
<circle cx="504.7" cy="250" r="119.6" fill="#9a4a12" fill-opacity="0.1" stroke="#9a4a12" stroke-width="2.5"/>
<text x="127.1" y="228.0" font-family="Arial, Helvetica, sans-serif" font-size="15" font-weight="700" fill="#16202a" text-anchor="middle">OSCAL ODP check</text>
<text x="127.1" y="250.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="400" fill="#16202a" text-anchor="middle">715 parts</text>
<text x="127.1" y="268.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="400" fill="#16202a" text-anchor="middle">530 only here</text>
<text x="321.9" y="119.3" font-family="Arial, Helvetica, sans-serif" font-size="15" font-weight="700" fill="#16202a" text-anchor="middle">HDF</text>
<text x="321.9" y="136.3" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="400" fill="#16202a" text-anchor="middle">348 parts</text>
<text x="364.8" y="310.0" font-family="Arial, Helvetica, sans-serif" font-size="14" font-weight="700" fill="#16202a" text-anchor="middle">126</text>
<text x="364.8" y="327.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="middle">HDF only</text>
<text x="531.1" y="228.0" font-family="Arial, Helvetica, sans-serif" font-size="15" font-weight="700" fill="#16202a" text-anchor="middle">OSCAL evidence</text>
<text x="531.1" y="250.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="400" fill="#16202a" text-anchor="middle">454 parts</text>
<text x="531.1" y="268.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="400" fill="#16202a" text-anchor="middle">417 only here</text>
<text x="278.7" y="310.0" font-family="Arial, Helvetica, sans-serif" font-size="14" font-weight="700" fill="#16202a" text-anchor="middle">185</text>
<text x="278.7" y="326.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="middle">both</text>
<text x="405.9" y="246.0" font-family="Arial, Helvetica, sans-serif" font-size="14" font-weight="700" fill="#16202a" text-anchor="middle">37</text>
<text x="405.9" y="263.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="middle">both</text>
<text x="20.0" y="436.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#4a5561" text-anchor="start">Outside all three circles: 454 parts with no automated evidence or ODP check.</text>
<text x="20.0" y="453.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#4a5561" text-anchor="start">OSCAL evidence and ODP checks never overlap: a part counts as an ODP check only when OSCAL has no stronger evidence.</text>
</svg>
```

*Figure 2. HDF, OSCAL evidence and OSCAL ODP checks. Circle areas and overlaps are drawn to scale.*

**Text description of Figure 2**

Statement parts with automated evidence or checks, areas proportional. Venn diagram of 1749 statement parts. HDF 348 parts, OSCAL evidence 454, OSCAL ODP check 715. HDF and OSCAL evidence share 37. HDF and ODP check share 185. OSCAL evidence and ODP check share none. 454 parts are outside all three.

- Set HDF 348.
- Set OSCAL evidence 454.
- Set ODP validated 715.
- Overlap of HDF 348 and OSCAL evidence 454: 37.
- Overlap of HDF 348 and ODP validated 715: 185.
- Overlap of OSCAL evidence 454 and ODP validated 715: none.
- Overlap of HDF 348 and OSCAL evidence 454 and ODP validated 715: none.

| OSCAL tier | Parts | What makes it automatable |
|---|---|---|
| Evidence | 261 | The OSCAL document is the evidence: SSP, profile, SAP, SAR, POAM, authorization actions, leveraged authorizations, inventory, hashed plans in back-matter |
| Documentary | 116 | The part asks for a record (document, define, designate, review and update, maintain a list or plan): back-matter resource with hash, metadata dates, responsible role |
| Inherited | 77 | PE parts marked inherited with provided-uuid pointing at a leveraged cloud authorization (cloud-hosted systems only) |
| ODP validated | 715 | The part has an organization-defined parameter: the value lives in SSP set-parameters and can be checked against profile constraints and against tool settings such as InSpec inputs or AWS Config rule parameters |

## What drives HDF's reach

All 47 inbound converters in hdf-libs, plus saf CLI's prowler2hdf entry point, are charted below; legacy HDF and Splunk
share the InSpec row, CKL and CKLB share one row, and the four VEX converters share one. Each tags findings to NIST in one of
four ways, and the way it tags sets its reach. Content converters pass through the controls the benchmark itself names.
Mapping-table converters look each rule or plugin up in a table shipped with hdf-mappings. CWE converters map the weakness
on the finding through the 404-entry CWE table. Default-tag converters stamp every finding with a fixed control.

```figure
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1325" width="1000" height="1325" role="img" aria-labelledby="fig-title fig-desc"><title id="fig-title">Statement parts reached by each HDF converter</title>
<desc id="fig-desc">Horizontal bar chart, one bar per converter, grouped by how it tags. Content carries its own tags: InSpec (native HDF) 196 named, 285 total, CKL and CKLB checklists 211 named, 253 total, XCCDF results (SCAP) 211 named, 253 total, 71 more dropped, OSCAL to HDF reach set by the OSCAL content. Per-rule or per-plugin mapping table: AWS Config 92 named, 271 total, AWS Security Hub (ASFF) 92 named, 276 total, Nessus and Tenable 212 named, 296 total, Checkov 50 named, 129 total, ScoutSuite 17 named, 91 total, Nikto 2 named, 25 total, Hipcheck 2 named, 21 total. CWE or OWASP on the finding: SonarQube 12 named, 43 total, Netsparker (Invicti) 12 named, 51 total, Burp Suite 12 named, 40 total, CycloneDX SBOM 12 named, 40 total, DefectDojo 12 named, 40 total, Dependency-Track 12 named, 40 total, Fortify 12 named, 40 total, GitLab 12 named, 40 total, JFrog Xray 12 named, 40 total, KICS 12 named, 40 total, SARIF 12 named, 40 total, Semgrep 12 named, 40 total, Snyk 12 named, 40 total, ZAP 12 named, 40 total, gosec 12 named, 44 total, NeuVector 12 named, 44 total, Veracode 12 named, 44 total. Fixed default tags: Prisma Cloud 0 named, 17 total, Twistlock 0 named, 12 total, Prowler (ASFF) 0 named, 13 total, 255 more dropped, Grype and Anchore 0 named, 13 total, Trivy 0 named, 13 total, Conveyor 0 named, 13 total, DbProtect 0 named, 13 total, Defender for Endpoint 0 named, 13 total, Microsoft Secure Score 0 named, 13 total, JUnit 0 named, 5 total, Ion Channel 0 named, 6 total, TruffleHog 1 named, 1 total. No NIST tags today: Defender for Cloud no NIST tags, Defender for DevOps no NIST tags. Amendments, not results: VEX converters (4) amendments, no control tags.</desc>
<rect x="0" y="0" width="1000" height="1325" fill="#ffffff"/>
<text x="20.0" y="32.0" font-family="Arial, Helvetica, sans-serif" font-size="16" font-weight="700" fill="#16202a" text-anchor="start">Statement parts reached by each HDF converter</text>
<rect x="300" y="50" width="16" height="12" fill="#083029"/>
<text x="322.0" y="60.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">Tag names the part</text>
<rect x="460" y="50" width="16" height="12" fill="#43978b"/>
<text x="482.0" y="60.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">Control-level tag only</text>
<rect x="635" y="51" width="15" height="11" fill="#ffffff" stroke="#9a4a12" stroke-width="2" stroke-dasharray="4 2"/>
<text x="657.0" y="60.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">Dropped by the converter today</text>
<text x="20.0" y="106.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="700" fill="#16202a" text-anchor="start">Content carries its own tags</text>
<line x1="20" y1="112" x2="980" y2="112" stroke="#d5dbe0" stroke-width="1"/>
<text x="20.0" y="234.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="700" fill="#16202a" text-anchor="start">Per-rule or per-plugin mapping table</text>
<line x1="20" y1="240" x2="980" y2="240" stroke="#d5dbe0" stroke-width="1"/>
<text x="20.0" y="431.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="700" fill="#16202a" text-anchor="start">CWE or OWASP on the finding</text>
<line x1="20" y1="437" x2="980" y2="437" stroke="#d5dbe0" stroke-width="1"/>
<text x="20.0" y="858.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="700" fill="#16202a" text-anchor="start">Fixed default tags</text>
<line x1="20" y1="864" x2="980" y2="864" stroke="#d5dbe0" stroke-width="1"/>
<text x="20.0" y="1170.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="700" fill="#16202a" text-anchor="start">No NIST tags today</text>
<line x1="20" y1="1176" x2="980" y2="1176" stroke="#d5dbe0" stroke-width="1"/>
<text x="20.0" y="1252.0" font-family="Arial, Helvetica, sans-serif" font-size="13" font-weight="700" fill="#16202a" text-anchor="start">Amendments, not results</text>
<line x1="20" y1="1258" x2="980" y2="1258" stroke="#d5dbe0" stroke-width="1"/>
<line x1="300.0" y1="78" x2="300.0" y2="1289" stroke="#d5dbe0" stroke-width="1"/>
<text x="300.0" y="1303.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="middle">0</text>
<line x1="371.4" y1="78" x2="371.4" y2="1289" stroke="#d5dbe0" stroke-width="1"/>
<text x="371.4" y="1303.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="middle">50</text>
<line x1="442.9" y1="78" x2="442.9" y2="1289" stroke="#d5dbe0" stroke-width="1"/>
<text x="442.9" y="1303.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="middle">100</text>
<line x1="514.3" y1="78" x2="514.3" y2="1289" stroke="#d5dbe0" stroke-width="1"/>
<text x="514.3" y="1303.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="middle">150</text>
<line x1="585.7" y1="78" x2="585.7" y2="1289" stroke="#d5dbe0" stroke-width="1"/>
<text x="585.7" y="1303.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="middle">200</text>
<line x1="657.1" y1="78" x2="657.1" y2="1289" stroke="#d5dbe0" stroke-width="1"/>
<text x="657.1" y="1303.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="middle">250</text>
<line x1="728.6" y1="78" x2="728.6" y2="1289" stroke="#d5dbe0" stroke-width="1"/>
<text x="728.6" y="1303.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="middle">300</text>
<line x1="800.0" y1="78" x2="800.0" y2="1289" stroke="#d5dbe0" stroke-width="1"/>
<text x="800.0" y="1303.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="middle">350</text>
<text x="288.0" y="133.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">InSpec (native HDF)</text>
<rect x="300" y="120" width="407.1" height="16" fill="#43978b"/>
<rect x="300" y="120" width="280.0" height="16" fill="#083029"/>
<text x="715.1" y="133.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">196 named, 285 total</text>
<text x="288.0" y="156.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">CKL and CKLB checklists</text>
<rect x="300" y="143" width="361.4" height="16" fill="#43978b"/>
<rect x="300" y="143" width="301.4" height="16" fill="#083029"/>
<text x="669.4" y="156.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">211 named, 253 total</text>
<text x="288.0" y="179.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">XCCDF results (SCAP)</text>
<rect x="661.4" y="167" width="101.4" height="14" fill="#ffffff" stroke="#9a4a12" stroke-width="2" stroke-dasharray="4 2"/>
<rect x="300" y="166" width="361.4" height="16" fill="#43978b"/>
<rect x="300" y="166" width="301.4" height="16" fill="#083029"/>
<text x="770.9" y="179.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">211 named, 253 total, +71 dropped</text>
<text x="288.0" y="202.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">OSCAL to HDF</text>
<text x="306.0" y="202.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#4a5561" text-anchor="start">reach set by the OSCAL content</text>
<text x="288.0" y="261.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">AWS Config</text>
<rect x="300" y="248" width="387.1" height="16" fill="#43978b"/>
<rect x="300" y="248" width="131.4" height="16" fill="#083029"/>
<text x="695.1" y="261.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">92 named, 271 total</text>
<text x="288.0" y="284.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">AWS Security Hub (ASFF)</text>
<rect x="300" y="271" width="394.3" height="16" fill="#43978b"/>
<rect x="300" y="271" width="131.4" height="16" fill="#083029"/>
<text x="702.3" y="284.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">92 named, 276 total</text>
<text x="288.0" y="307.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Nessus and Tenable</text>
<rect x="300" y="294" width="422.9" height="16" fill="#43978b"/>
<rect x="300" y="294" width="302.9" height="16" fill="#083029"/>
<text x="730.9" y="307.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">212 named, 296 total</text>
<text x="288.0" y="330.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Checkov</text>
<rect x="300" y="317" width="184.3" height="16" fill="#43978b"/>
<rect x="300" y="317" width="71.4" height="16" fill="#083029"/>
<text x="492.3" y="330.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">50 named, 129 total</text>
<text x="288.0" y="353.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">ScoutSuite</text>
<rect x="300" y="340" width="130.0" height="16" fill="#43978b"/>
<rect x="300" y="340" width="24.3" height="16" fill="#083029"/>
<text x="438.0" y="353.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">17 named, 91 total</text>
<text x="288.0" y="376.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Nikto</text>
<rect x="300" y="363" width="35.7" height="16" fill="#43978b"/>
<rect x="300" y="363" width="2.9" height="16" fill="#083029"/>
<text x="343.7" y="376.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">2 named, 25 total</text>
<text x="288.0" y="399.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Hipcheck</text>
<rect x="300" y="386" width="30.0" height="16" fill="#43978b"/>
<rect x="300" y="386" width="2.9" height="16" fill="#083029"/>
<text x="338.0" y="399.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">2 named, 21 total</text>
<text x="288.0" y="458.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">SonarQube</text>
<rect x="300" y="445" width="61.4" height="16" fill="#43978b"/>
<rect x="300" y="445" width="17.1" height="16" fill="#083029"/>
<text x="369.4" y="458.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">12 named, 43 total</text>
<text x="288.0" y="481.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Netsparker (Invicti)</text>
<rect x="300" y="468" width="72.9" height="16" fill="#43978b"/>
<rect x="300" y="468" width="17.1" height="16" fill="#083029"/>
<text x="380.9" y="481.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">12 named, 51 total</text>
<text x="288.0" y="504.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Burp Suite</text>
<rect x="300" y="491" width="57.1" height="16" fill="#43978b"/>
<rect x="300" y="491" width="17.1" height="16" fill="#083029"/>
<text x="365.1" y="504.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">12 named, 40 total</text>
<text x="288.0" y="527.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">CycloneDX SBOM</text>
<rect x="300" y="514" width="57.1" height="16" fill="#43978b"/>
<rect x="300" y="514" width="17.1" height="16" fill="#083029"/>
<text x="365.1" y="527.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">12 named, 40 total</text>
<text x="288.0" y="550.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">DefectDojo</text>
<rect x="300" y="537" width="57.1" height="16" fill="#43978b"/>
<rect x="300" y="537" width="17.1" height="16" fill="#083029"/>
<text x="365.1" y="550.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">12 named, 40 total</text>
<text x="288.0" y="573.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Dependency-Track</text>
<rect x="300" y="560" width="57.1" height="16" fill="#43978b"/>
<rect x="300" y="560" width="17.1" height="16" fill="#083029"/>
<text x="365.1" y="573.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">12 named, 40 total</text>
<text x="288.0" y="596.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Fortify</text>
<rect x="300" y="583" width="57.1" height="16" fill="#43978b"/>
<rect x="300" y="583" width="17.1" height="16" fill="#083029"/>
<text x="365.1" y="596.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">12 named, 40 total</text>
<text x="288.0" y="619.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">GitLab</text>
<rect x="300" y="606" width="57.1" height="16" fill="#43978b"/>
<rect x="300" y="606" width="17.1" height="16" fill="#083029"/>
<text x="365.1" y="619.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">12 named, 40 total</text>
<text x="288.0" y="642.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">JFrog Xray</text>
<rect x="300" y="629" width="57.1" height="16" fill="#43978b"/>
<rect x="300" y="629" width="17.1" height="16" fill="#083029"/>
<text x="365.1" y="642.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">12 named, 40 total</text>
<text x="288.0" y="665.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">KICS</text>
<rect x="300" y="652" width="57.1" height="16" fill="#43978b"/>
<rect x="300" y="652" width="17.1" height="16" fill="#083029"/>
<text x="365.1" y="665.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">12 named, 40 total</text>
<text x="288.0" y="688.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">SARIF</text>
<rect x="300" y="675" width="57.1" height="16" fill="#43978b"/>
<rect x="300" y="675" width="17.1" height="16" fill="#083029"/>
<text x="365.1" y="688.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">12 named, 40 total</text>
<text x="288.0" y="711.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Semgrep</text>
<rect x="300" y="698" width="57.1" height="16" fill="#43978b"/>
<rect x="300" y="698" width="17.1" height="16" fill="#083029"/>
<text x="365.1" y="711.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">12 named, 40 total</text>
<text x="288.0" y="734.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Snyk</text>
<rect x="300" y="721" width="57.1" height="16" fill="#43978b"/>
<rect x="300" y="721" width="17.1" height="16" fill="#083029"/>
<text x="365.1" y="734.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">12 named, 40 total</text>
<text x="288.0" y="757.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">ZAP</text>
<rect x="300" y="744" width="57.1" height="16" fill="#43978b"/>
<rect x="300" y="744" width="17.1" height="16" fill="#083029"/>
<text x="365.1" y="757.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">12 named, 40 total</text>
<text x="288.0" y="780.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">gosec</text>
<rect x="300" y="767" width="62.9" height="16" fill="#43978b"/>
<rect x="300" y="767" width="17.1" height="16" fill="#083029"/>
<text x="370.9" y="780.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">12 named, 44 total</text>
<text x="288.0" y="803.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">NeuVector</text>
<rect x="300" y="790" width="62.9" height="16" fill="#43978b"/>
<rect x="300" y="790" width="17.1" height="16" fill="#083029"/>
<text x="370.9" y="803.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">12 named, 44 total</text>
<text x="288.0" y="826.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Veracode</text>
<rect x="300" y="813" width="62.9" height="16" fill="#43978b"/>
<rect x="300" y="813" width="17.1" height="16" fill="#083029"/>
<text x="370.9" y="826.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">12 named, 44 total</text>
<text x="288.0" y="885.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Prisma Cloud</text>
<rect x="300" y="872" width="24.3" height="16" fill="#43978b"/>
<text x="332.3" y="885.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">0 named, 17 total</text>
<text x="288.0" y="908.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Twistlock</text>
<rect x="300" y="895" width="17.1" height="16" fill="#43978b"/>
<text x="325.1" y="908.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">0 named, 12 total</text>
<text x="288.0" y="931.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Prowler (ASFF)</text>
<rect x="318.6" y="919" width="364.3" height="14" fill="#ffffff" stroke="#9a4a12" stroke-width="2" stroke-dasharray="4 2"/>
<rect x="300" y="918" width="18.6" height="16" fill="#43978b"/>
<text x="690.9" y="931.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">0 named, 13 total, +255 dropped</text>
<text x="288.0" y="954.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Grype and Anchore</text>
<rect x="300" y="941" width="18.6" height="16" fill="#43978b"/>
<text x="326.6" y="954.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">0 named, 13 total</text>
<text x="288.0" y="977.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Trivy</text>
<rect x="300" y="964" width="18.6" height="16" fill="#43978b"/>
<text x="326.6" y="977.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">0 named, 13 total</text>
<text x="288.0" y="1000.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Conveyor</text>
<rect x="300" y="987" width="18.6" height="16" fill="#43978b"/>
<text x="326.6" y="1000.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">0 named, 13 total</text>
<text x="288.0" y="1023.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">DbProtect</text>
<rect x="300" y="1010" width="18.6" height="16" fill="#43978b"/>
<text x="326.6" y="1023.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">0 named, 13 total</text>
<text x="288.0" y="1046.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Defender for Endpoint</text>
<rect x="300" y="1033" width="18.6" height="16" fill="#43978b"/>
<text x="326.6" y="1046.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">0 named, 13 total</text>
<text x="288.0" y="1069.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Microsoft Secure Score</text>
<rect x="300" y="1056" width="18.6" height="16" fill="#43978b"/>
<text x="326.6" y="1069.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">0 named, 13 total</text>
<text x="288.0" y="1092.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">JUnit</text>
<rect x="300" y="1079" width="7.1" height="16" fill="#43978b"/>
<text x="315.1" y="1092.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">0 named, 5 total</text>
<text x="288.0" y="1115.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Ion Channel</text>
<rect x="300" y="1102" width="8.6" height="16" fill="#43978b"/>
<text x="316.6" y="1115.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">0 named, 6 total</text>
<text x="288.0" y="1138.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">TruffleHog</text>
<rect x="300" y="1125" width="1.4" height="16" fill="#43978b"/>
<rect x="300" y="1125" width="1.4" height="16" fill="#083029"/>
<text x="309.4" y="1138.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#16202a" text-anchor="start">1 named, 1 total</text>
<text x="288.0" y="1197.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Defender for Cloud</text>
<text x="306.0" y="1197.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#4a5561" text-anchor="start">no NIST tags</text>
<text x="288.0" y="1220.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">Defender for DevOps</text>
<text x="306.0" y="1220.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#4a5561" text-anchor="start">no NIST tags</text>
<text x="288.0" y="1279.0" font-family="Arial, Helvetica, sans-serif" font-size="12.5" font-weight="400" fill="#16202a" text-anchor="end">VEX converters (4)</text>
<text x="306.0" y="1279.0" font-family="Arial, Helvetica, sans-serif" font-size="12" font-weight="400" fill="#4a5561" text-anchor="start">amendments, no control tags</text>
<text x="300.0" y="1321.0" font-family="Arial, Helvetica, sans-serif" font-size="11" font-weight="400" fill="#4a5561" text-anchor="start">statement parts</text>
</svg>
```

*Figure 3. Parts reached by each HDF converter, grouped by how it tags. Dark segment: parts the tag names. Light segment: parts reached only through control-level tags. Dashed segment: parts the converter would reach if it kept references it drops today.*

**Text description of Figure 3**

Statement parts reached by each HDF converter. Horizontal bar chart, one bar per converter, grouped by how it tags. Content carries its own tags: InSpec (native HDF) 196 named, 285 total, CKL and CKLB checklists 211 named, 253 total, XCCDF results (SCAP) 211 named, 253 total, 71 more dropped, OSCAL to HDF reach set by the OSCAL content. Per-rule or per-plugin mapping table: AWS Config 92 named, 271 total, AWS Security Hub (ASFF) 92 named, 276 total, Nessus and Tenable 212 named, 296 total, Checkov 50 named, 129 total, ScoutSuite 17 named, 91 total, Nikto 2 named, 25 total, Hipcheck 2 named, 21 total. CWE or OWASP on the finding: SonarQube 12 named, 43 total, Netsparker (Invicti) 12 named, 51 total, Burp Suite 12 named, 40 total, CycloneDX SBOM 12 named, 40 total, DefectDojo 12 named, 40 total, Dependency-Track 12 named, 40 total, Fortify 12 named, 40 total, GitLab 12 named, 40 total, JFrog Xray 12 named, 40 total, KICS 12 named, 40 total, SARIF 12 named, 40 total, Semgrep 12 named, 40 total, Snyk 12 named, 40 total, ZAP 12 named, 40 total, gosec 12 named, 44 total, NeuVector 12 named, 44 total, Veracode 12 named, 44 total. Fixed default tags: Prisma Cloud 0 named, 17 total, Twistlock 0 named, 12 total, Prowler (ASFF) 0 named, 13 total, 255 more dropped, Grype and Anchore 0 named, 13 total, Trivy 0 named, 13 total, Conveyor 0 named, 13 total, DbProtect 0 named, 13 total, Defender for Endpoint 0 named, 13 total, Microsoft Secure Score 0 named, 13 total, JUnit 0 named, 5 total, Ion Channel 0 named, 6 total, TruffleHog 1 named, 1 total. No NIST tags today: Defender for Cloud no NIST tags, Defender for DevOps no NIST tags. Amendments, not results: VEX converters (4) amendments, no control tags.

- InSpec (native HDF): today plus dropped references 285, today with control-level tags 285, parts the tag names 196.
- CKL and CKLB checklists: today plus dropped references 253, today with control-level tags 253, parts the tag names 211.
- XCCDF results (SCAP): today plus dropped references 324, today with control-level tags 253, parts the tag names 211.
- AWS Config: today plus dropped references 271, today with control-level tags 271, parts the tag names 92.
- AWS Security Hub (ASFF): today plus dropped references 276, today with control-level tags 276, parts the tag names 92.
- Nessus and Tenable: today plus dropped references 296, today with control-level tags 296, parts the tag names 212.
- Checkov: today plus dropped references 129, today with control-level tags 129, parts the tag names 50.
- ScoutSuite: today plus dropped references 91, today with control-level tags 91, parts the tag names 17.
- Nikto: today plus dropped references 25, today with control-level tags 25, parts the tag names 2.
- Hipcheck: today plus dropped references 21, today with control-level tags 21, parts the tag names 2.
- SonarQube: today plus dropped references 43, today with control-level tags 43, parts the tag names 12.
- Netsparker (Invicti): today plus dropped references 51, today with control-level tags 51, parts the tag names 12.
- Burp Suite: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- CycloneDX SBOM: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- DefectDojo: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- Dependency-Track: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- Fortify: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- GitLab: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- JFrog Xray: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- KICS: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- SARIF: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- Semgrep: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- Snyk: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- ZAP: today plus dropped references 40, today with control-level tags 40, parts the tag names 12.
- gosec: today plus dropped references 44, today with control-level tags 44, parts the tag names 12.
- NeuVector: today plus dropped references 44, today with control-level tags 44, parts the tag names 12.
- Veracode: today plus dropped references 44, today with control-level tags 44, parts the tag names 12.
- Prisma Cloud: today plus dropped references 17, today with control-level tags 17, parts the tag names 0.
- Twistlock: today plus dropped references 12, today with control-level tags 12, parts the tag names 0.
- Prowler (ASFF): today plus dropped references 268, today with control-level tags 13, parts the tag names 0.
- Grype and Anchore: today plus dropped references 13, today with control-level tags 13, parts the tag names 0.
- Trivy: today plus dropped references 13, today with control-level tags 13, parts the tag names 0.
- Conveyor: today plus dropped references 13, today with control-level tags 13, parts the tag names 0.
- DbProtect: today plus dropped references 13, today with control-level tags 13, parts the tag names 0.
- Defender for Endpoint: today plus dropped references 13, today with control-level tags 13, parts the tag names 0.
- Microsoft Secure Score: today plus dropped references 13, today with control-level tags 13, parts the tag names 0.
- JUnit: today plus dropped references 5, today with control-level tags 5, parts the tag names 0.
- Ion Channel: today plus dropped references 6, today with control-level tags 6, parts the tag names 0.
- TruffleHog: today plus dropped references 1, today with control-level tags 1, parts the tag names 1.

Each bar has up to three segments. The inner segment, starting at zero, counts parts the tag names. The middle segment adds
parts reached only through a control-level tag. The outer segment, on XCCDF results and Prowler only, adds the parts the
converter would reach if it kept references that its input carries but it drops today. OSCAL to HDF, Defender for Cloud,
Defender for DevOps and the VEX converters have no bar: the first carries whatever the OSCAL names, the next two emit no NIST
tags, and VEX converters emit amendments. The same values are in the table below and in the text description.

| How it tags | Converter | Mechanisms | Reach today | Reach it drops | Notes |
|---|---|---|---|---|---|
| Content carries its own tags | InSpec (native HDF) | InSpec tag nist | 196 named, 285 with control-level tags |  | saf CLI and Heimdall read InSpec JSON directly; legacyhdf, hdf-passthrough and the Splunk fetcher carry the same tags |
| Content carries its own tags | CKL and CKLB checklists | DISA SRG/STIG CCI | 211 named, 253 with control-level tags |  | STIG Viewer, Evaluate-STIG and SCC checklists; CCI to NIST |
| Content carries its own tags | XCCDF results (SCAP) | DISA SRG/STIG CCI | 211 named, 253 with control-level tags | +71 parts if it kept ComplianceAsCode NIST references | OpenSCAP and SCC results; NIST only from CCI idents, so ComplianceAsCode NIST references are dropped |
| Content carries its own tags | OSCAL to HDF | - | set by the OSCAL content |  | control-ids from the OSCAL SAR, POAM or SSP; reach is whatever the OSCAL names |
| Per-rule or per-plugin mapping table | AWS Config | AWS Config table, default CM-6 | 92 named, 271 with control-level tags |  | also the awsconfig fetcher |
| Per-rule or per-plugin mapping table | AWS Security Hub (ASFF) | AWS Config table, default CM-6, default SA-11 RA-5, default SI-2 RA-5 | 92 named, 276 with control-level tags |  | Config-rule findings through the AWS Config table; also the aws-securityhub fetcher |
| Per-rule or per-plugin mapping table | Nessus and Tenable | Nessus plugin-family table, DISA SRG/STIG CCI, default SI-2 RA-5 | 212 named, 296 with control-level tags |  | plugin-family table, plus CCI from compliance-audit results (DISA STIG audits) |
| Per-rule or per-plugin mapping table | Checkov | Checkov table, default SA-11 RA-5 | 50 named, 129 with control-level tags |  |  |
| Per-rule or per-plugin mapping table | ScoutSuite | ScoutSuite table | 17 named, 91 with control-level tags |  |  |
| Per-rule or per-plugin mapping table | Nikto | Nikto table, default SA-11 RA-5 | 2 named, 25 with control-level tags |  |  |
| Per-rule or per-plugin mapping table | Hipcheck | Hipcheck table | 2 named, 21 with control-level tags |  |  |
| CWE or OWASP on the finding | SonarQube | CWE table, OWASP table | 12 named, 43 with control-level tags |  | also the sonarqube fetcher |
| CWE or OWASP on the finding | Netsparker (Invicti) | CWE table, OWASP table, default SA-11 RA-5 | 12 named, 51 with control-level tags |  |  |
| CWE or OWASP on the finding | Burp Suite | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  |  |
| CWE or OWASP on the finding | CycloneDX SBOM | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  | CWE on vulnerabilities |
| CWE or OWASP on the finding | DefectDojo | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  | also the defectdojo fetcher |
| CWE or OWASP on the finding | Dependency-Track | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  |  |
| CWE or OWASP on the finding | Fortify | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  | plus control-level NIST from rulepack references in the FVDL |
| CWE or OWASP on the finding | GitLab | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  | also the gitlab fetcher |
| CWE or OWASP on the finding | JFrog Xray | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  |  |
| CWE or OWASP on the finding | KICS | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  | per-query table is defined but empty today |
| CWE or OWASP on the finding | SARIF | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  |  |
| CWE or OWASP on the finding | Semgrep | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  |  |
| CWE or OWASP on the finding | Snyk | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  |  |
| CWE or OWASP on the finding | ZAP | CWE table, default SA-11 RA-5 | 12 named, 40 with control-level tags |  |  |
| CWE or OWASP on the finding | gosec | CWE table, default SI-2 RA-5 | 12 named, 44 with control-level tags |  |  |
| CWE or OWASP on the finding | NeuVector | CWE table, default SI-2 RA-5 | 12 named, 44 with control-level tags |  |  |
| CWE or OWASP on the finding | Veracode | CWE table, default SI-2 RA-5 | 12 named, 44 with control-level tags |  |  |
| Fixed default tags | Prisma Cloud | default SI-2 RA-5, default SA-11 RA-5 | 0 named, 17 with control-level tags |  |  |
| Fixed default tags | Twistlock | default SI-2 RA-5 | 0 named, 12 with control-level tags |  |  |
| Fixed default tags | Prowler (ASFF) | default SA-11 RA-5 | 0 named, 13 with control-level tags | +255 parts if it kept Prowler requirement IDs | saf CLI prowler2hdf; ASFF drops Compliance.RelatedRequirements |
| Fixed default tags | Grype and Anchore | default SA-11 RA-5 | 0 named, 13 with control-level tags |  |  |
| Fixed default tags | Trivy | default SA-11 RA-5 | 0 named, 13 with control-level tags |  |  |
| Fixed default tags | Conveyor | default SA-11 RA-5 | 0 named, 13 with control-level tags |  |  |
| Fixed default tags | DbProtect | default SA-11 RA-5 | 0 named, 13 with control-level tags |  |  |
| Fixed default tags | Defender for Endpoint | default SA-11 RA-5 | 0 named, 13 with control-level tags |  |  |
| Fixed default tags | Microsoft Secure Score | default SA-11 RA-5 | 0 named, 13 with control-level tags |  |  |
| Fixed default tags | JUnit | default SA-11 | 0 named, 5 with control-level tags |  |  |
| Fixed default tags | Ion Channel | default CM-8 | 0 named, 6 with control-level tags |  |  |
| Fixed default tags | TruffleHog | default IA-5 (7) | 1 named, 1 with control-level tags |  |  |
| No NIST tags today | Defender for Cloud | - | none |  | findings carry categories and MITRE tactics, no NIST |
| No NIST tags today | Defender for DevOps | - | none |  | no NIST |
| Amendments, not results | VEX converters (4) | - | none |  | emit HDF Amendments that adjust findings; no control reach of their own |

Three findings from reading the converter code:

- **XCCDF results take NIST only from CCI idents.** DISA STIG benchmarks carry CCIs, so SCC and OpenSCAP runs against DISA
  content are tagged. ComplianceAsCode content (CIS, PCI, OSPP and other non-STIG profiles) carries NIST 800-53 as
  `reference` elements, which the converter keeps as references but not as tags, so those results arrive with an empty
  tags.nist.
- **ASFF drops Compliance.RelatedRequirements.** Prowler writes its NIST 800-53 Rev 5 requirement IDs there; both the
  hdf-libs converter and saf CLI's prowler2hdf fall back to SA-11 and RA-5 instead. Security Hub findings from AWS Config
  rules still map through the AWS Config table.
- **The KICS per-query table is defined but empty,** and Defender for Cloud and Defender for DevOps emit no NIST tags at
  all. KICS falls back to the CWE table.

Carrying those references would add 168 parts to HDF's reach.

### Tools that reach HDF through a standard format

Many tools have no converter of their own but export a format one of the converters reads. Their reach is the carrier's row
above.

| Tool | Export | Converter that reads it |
|---|---|---|
| Sonatype Lifecycle (Nexus IQ) | CycloneDX SBOM with vulnerabilities | CycloneDX |
| Tenable Vulnerability Management (Tenable.io) | .nessus export | Nessus and Tenable |
| Tenable Security Center (Tenable.sc) | .nessus export, or the Tenable.sc API loader in Heimdall | Nessus and Tenable |
| Tenable compliance audits (DISA STIG .audit) | .nessus export with compliance results | Nessus and Tenable (CCI path) |
| GitHub CodeQL and code scanning | SARIF | SARIF |
| Checkmarx One | SARIF report | SARIF |
| Bandit, ESLint, hadolint, tfsec and other SARIF emitters | SARIF | SARIF |
| OWASP Dependency-Check | SARIF report | SARIF |
| Syft and other SBOM generators with a vulnerability pass | CycloneDX | CycloneDX |
| Anchore Enterprise and Grype | Grype JSON (saf convert anchoregrype2hdf) | Grype and Anchore |
| DISA SCC, OpenSCAP | XCCDF results or ARF | XCCDF results (SCAP) |
| DISA STIG Viewer, Evaluate-STIG | CKL or CKLB | CKL and CKLB checklists |
| AWS Security Hub sources (GuardDuty, Inspector, Firewall Manager, Prowler) | ASFF | AWS Security Hub (ASFF) |
| Any tool already exporting to DefectDojo, GitLab or Splunk | the platform API (fetchers) | DefectDojo, GitLab, Splunk |

Control-level tags (for example "SI-2" or "SA-11" with no letter) do not say which part the check proves, so they are not
counted in the HDF total. That is why the default-tag and CWE converters add little at part level even though they run in
most pipelines. Tagging to the part letter in mapping tables would move them over.

| How HDF reaches a counted part | Parts |
|---|---|
| Tag names the whole control or enhancement, which has a single part | 212 |
| Tag names the part letter, Rev 5 | 0 |
| Tag names the part letter, revision not stated | 82 |
| Tag names the part letter, Rev 4 only (letter may have shifted in Rev 5) | 43 |
| HDF document type (Plan for CA-2, Amendments for CA-5 and RA-7) | 11 |

Not yet counted, because the content is not in these repositories: the DISA STIG library beyond the 7 SRGs and 4 STIGs in
the Vulcan seed set, Tenable's audit library beyond its DISA STIG audits, Fortify rulepack NIST references, Azure and GCP
NIST mappings, and SAF InSpec profiles that could not be cloned. Each would add reach.

## POAM: automated management, not just a list

An OSCAL POAM risk has a status lifecycle (open, investigating, remediating, deviation-requested, deviation-approved, closed),
a deadline, remediation tasks of type milestone, and a risk-log of dated status changes. Fed by HDF results on every run, it
tracks the remediation windows in RA-5 d and SI-2 c. HDF can run a simpler version on its own with Amendments of type poam,
waivers and risk adjustments, each with a required expiresAt.

```figure
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 340" width="960" height="340" role="img" aria-labelledby="fig-title fig-desc"> <title id="fig-title">POAandM: automated management, not just a list</title>
<desc id="fig-desc">Remediation loop: an HDF failed result becomes a SAR finding, then a POAandM item and risk with a deadline, then risk-log status changes, then a rescan passes and closes the risk. Below, HDF Amendments manage POAandMs and waivers without OSCAL.</desc>
<rect x="0" y="0" width="960" height="340" fill="#ffffff" />
<defs> <marker id="a" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="8" markerHeight="8" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#17212a" />
</marker>
 <marker id="am" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="8" markerHeight="8" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#56636f" />
</marker>
 </defs>
 <rect x="20" y="40" width="168" height="112" rx="5" fill="#e0f2ef" stroke="#009683" stroke-width="1.5" />
 <text x="34" y="64" font-family="Arial, Helvetica, sans-serif" fill="#17212a" font-size="13" font-weight="600">HDF result</text>
 <text x="34" y="86" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">check tagged RA-5</text>
 <text x="34" y="104" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">or SI-2</text>
 <text x="34" y="122" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">status: failed</text>
 <rect x="208" y="40" width="168" height="112" rx="5" fill="#f8e9df" stroke="#b4541a" stroke-width="1.5" />
 <text x="222" y="64" font-family="Arial, Helvetica, sans-serif" fill="#17212a" font-size="13" font-weight="600">SAR finding</text>
 <text x="222" y="86" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">hdf convert</text>
 <text x="222" y="104" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">--to oscal-sar</text>
 <text x="222" y="122" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">state: not-satisfied</text>
 <rect x="396" y="40" width="168" height="112" rx="5" fill="#f8e9df" stroke="#b4541a" stroke-width="1.5" />
 <text x="410" y="64" font-family="Arial, Helvetica, sans-serif" fill="#17212a" font-size="13" font-weight="600">POAM item + risk</text>
 <text x="410" y="86" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">status: open</text>
 <text x="410" y="104" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">deadline</text>
 <text x="410" y="122" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">remediations[].tasks</text>
 <text x="410" y="140" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">type: milestone</text>
 <rect x="584" y="40" width="168" height="112" rx="5" fill="#f8e9df" stroke="#b4541a" stroke-width="1.5" />
 <text x="598" y="64" font-family="Arial, Helvetica, sans-serif" fill="#17212a" font-size="13" font-weight="600">risk-log entries</text>
 <text x="598" y="86" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">status-change:</text>
 <text x="598" y="104" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">remediating, or</text>
 <text x="598" y="122" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">deviation-requested</text>
 <text x="598" y="140" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">to deviation-approved</text>
 <rect x="772" y="40" width="168" height="112" rx="5" fill="#e0f2ef" stroke="#009683" stroke-width="1.5" />
 <text x="786" y="64" font-family="Arial, Helvetica, sans-serif" fill="#17212a" font-size="13" font-weight="600">Rescan</text>
 <text x="786" y="86" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">HDF result: passed</text>
 <text x="786" y="104" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">risk status: closed</text>
 <text x="786" y="122" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">history kept in log</text>
 <line x1="188" y1="96" x2="204" y2="96" marker-end="url(#a)" fill="none" stroke="#17212a" stroke-width="1.4" />
 <line x1="376" y1="96" x2="392" y2="96" marker-end="url(#a)" fill="none" stroke="#17212a" stroke-width="1.4" />
 <line x1="564" y1="96" x2="580" y2="96" marker-end="url(#a)" fill="none" stroke="#17212a" stroke-width="1.4" />
 <line x1="752" y1="96" x2="768" y2="96" marker-end="url(#a)" fill="none" stroke="#17212a" stroke-width="1.4" />
 <path d="M856,152 V184 H104 V156" marker-end="url(#am)" fill="none" stroke="#56636f" stroke-width="1.4" stroke-dasharray="5 4" />
 <text x="480" y="178" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="11">every pipeline run</text>
 <text x="20" y="226" font-family="Arial, Helvetica, sans-serif" fill="#56636f" font-size="12.5">HDF on its own, without OSCAL, Amendments</text>
 <rect x="20" y="238" width="290" height="80" rx="5" fill="#ffffff" stroke="#707b86" stroke-width="1.2" />
 <text x="34" y="262" font-family="Arial, Helvetica, sans-serif" fill="#17212a" font-size="13" font-weight="600">type: poam</text>
 <text x="34" y="284" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">milestones[], expiresAt required</text>
 <text x="34" y="302" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">tracks work, leaves status alone</text>
 <rect x="335" y="238" width="290" height="80" rx="5" fill="#ffffff" stroke="#707b86" stroke-width="1.2" />
 <text x="349" y="262" font-family="Arial, Helvetica, sans-serif" fill="#17212a" font-size="13" font-weight="600">waiver, riskAdjustment</text>
 <text x="349" y="284" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">appliedBy, approvedBy, reason</text>
 <text x="349" y="302" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">sets effectiveStatus / impact</text>
 <rect x="650" y="238" width="290" height="80" rx="5" fill="#ffffff" stroke="#707b86" stroke-width="1.2" />
 <text x="664" y="262" font-family="Arial, Helvetica, sans-serif" fill="#17212a" font-size="13" font-weight="600">Tamper evidence</text>
 <text x="664" y="284" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">previousChecksum chain</text>
 <text x="664" y="302" font-family="Courier New, Courier, monospace" fill="#56636f" font-size="10.5">hdf amend verify, signature</text>
 </svg>
```

*Figure 4. This loop is why CA-5, RA-5, RA-7 and SI-2 sit in the overlap. HDF detects and re-tests, the POAandM carries deadline, owner, milestones and an auditable status history. HDF Amendments have no permanent entries: every override requires expiresAt.*

**Text description of Figure 4**

POAandM: automated management, not just a list. Remediation loop: an HDF failed result becomes a SAR finding, then a POAandM item and risk with a deadline, then risk-log status changes, then a rescan passes and closes the risk. Below, HDF Amendments manage POAandMs and waivers without OSCAL.

- HDF result - check tagged RA-5 d or SI-2 c - status failed points to SAR finding - hdf convert --to oscal-sar - state not-satisfied.
- SAR finding - hdf convert --to oscal-sar - state not-satisfied points to POAM item and risk - status open - deadline - remediation tasks, type milestone.
- POAM item and risk - status open - deadline - remediation tasks, type milestone points to risk-log entries - status-change remediating, or deviation-requested then deviation-approved.
- risk-log entries - status-change remediating, or deviation-requested then deviation-approved points to Rescan - HDF result passed - risk status closed.
- Rescan - HDF result passed - risk status closed points to HDF result - check tagged RA-5 d or SI-2 c - status failed (dashed): every pipeline run.

## Coverage by family

| Family | Parts | HDF | OSCAL evidence | Either | ODP validated only | Neither |
|---|---|---|---|---|---|---|
| AC | 214 | 53 | 20 | 73 | 94 | 47 |
| AT | 29 | 1 | 8 | 9 | 12 | 8 |
| AU | 84 | 43 | 15 | 51 | 21 | 12 |
| CA | 57 | 12 | 37 | 39 | 6 | 12 |
| CM | 108 | 31 | 37 | 61 | 32 | 15 |
| CP | 82 | 21 | 29 | 43 | 14 | 25 |
| IA | 96 | 33 | 7 | 40 | 32 | 24 |
| IR | 77 | 6 | 22 | 28 | 20 | 29 |
| MA | 57 | 11 | 12 | 23 | 14 | 20 |
| MP | 35 | 2 | 8 | 10 | 14 | 11 |
| PE | 83 | 0 | 83 | 83 | 0 | 0 |
| PL | 46 | 0 | 39 | 39 | 3 | 4 |
| PM | 98 | 1 | 47 | 48 | 10 | 40 |
| PS | 45 | 0 | 13 | 13 | 11 | 21 |
| PT | 42 | 0 | 7 | 7 | 18 | 17 |
| RA | 48 | 4 | 13 | 16 | 14 | 18 |
| SA | 185 | 19 | 28 | 46 | 74 | 65 |
| SC | 175 | 67 | 9 | 74 | 66 | 35 |
| SI | 151 | 42 | 7 | 48 | 56 | 47 |
| SR | 37 | 2 | 13 | 14 | 19 | 4 |
| All | 1749 | 348 | 454 | 765 | 530 | 454 |

## How this was counted

- Universe: every leaf statement item of the 1014 active controls and enhancements in NIST's official SP 800-53 Rev 5 OSCAL catalog; 24 withdrawn base controls and withdrawn enhancements excluded.
- HDF: what each converter emits today. Mapping tables (AWS Config, ScoutSuite, Nessus, Nikto, Checkov, CWE, OWASP, Hipcheck) were run through hdf-mappings' own Go lookups at Rev 5, so the Rev 4 to Rev 5 crosswalk is the library's. InSpec content is tag nist in the MITRE SAF baselines. STIG content is the CCIs in 7 DISA SRGs and 4 STIGs, mapped CCI to NIST by the same library. Fixed defaults are read from each converter. Tags are parsed to the part (IA-5 (1) (a) becomes ia-5.1_smt.a), and a tag naming a lettered parent covers its child items.
- Dropped references (outer bar segment, not in any total): NIST references in ComplianceAsCode rules and Prowler's AWS NIST 800-53 Rev 5 requirements with checks.
- OSCAL evidence: the control-level classification (SSP, profile, SAP, SAR, POAM, actions, inventory, back-matter plans) applied to every part of those base controls, except RA-5 and SI-2 where only the remediation-window parts (RA-5 d, SI-2 c) count.
- OSCAL documentary: parts whose text starts with a record-keeping verb, or with establish, maintain, update or develop followed by a record word (policy, plan, procedure, criteria, list, inventory, baseline, agreement and similar).
- ODP validated: any remaining part whose text contains an organization-defined parameter.
- A count means a tool can produce evidence tagged to that part, not that the part is satisfied.

The full classification of all 1749 parts is in control-coverage-parts.csv.

## Sources

- [mitre/hdf-libs (hdf-mappings data)](https://github.com/mitre/hdf-libs)
- [MITRE SAF validation content](https://saf.mitre.org/content/?pillar=validate)
- [ComplianceAsCode content](https://github.com/ComplianceAsCode/content)
- [Prowler NIST 800-53 Rev 5 compliance (AWS)](https://github.com/prowler-cloud/prowler/tree/master/prowler/compliance/aws)
- [MITRE SAF CLI convert commands](https://github.com/mitre/saf)
- [MITRE Vulcan (DISA SRG and STIG seed content)](https://github.com/mitre/vulcan)
- [NIST SP 800-53 Rev 5 OSCAL catalog](https://github.com/usnistgov/oscal-content)
- [OSCAL v1.2.3 POAM model](https://pages.nist.gov/OSCAL-Reference/models/v1.2.3/plan-of-action-and-milestones/json-outline/)
- [HDF v3.7.0 specification](https://mitre.github.io/hdf-libs/docs/specification/hdf-specification.html)
