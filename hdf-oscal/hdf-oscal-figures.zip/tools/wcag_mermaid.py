#!/usr/bin/env python3
"""Make Mermaid diagrams in Markdown meet WCAG 2.1 AA text-alternative needs (1.1.1, 1.3.1).

For every ```mermaid block in each Markdown file:
  * adds accTitle / accDescr (the diagram's accessible name and summary) where the diagram type supports them
    (flowchart, pie, xychart-beta; venn-beta has no accessibility keywords, so it relies on the text description);
  * inserts a visible "Text description" list right after the block, generated from the diagram source itself,
    so the text alternative always matches the picture.
Idempotent: re-running replaces the previous description instead of adding a second one.
Usage: wcag_mermaid.py FILE.md [FILE.md ...]   (writes files in place; prints what it did)
"""
import re, sys

ARROW = r'(<-->|<-\.->|-\.->|-->|-\.-|---|==>)'
SHAPES = [('([', '])'), ('[(', ')]'), ('{{', '}}'), ('((', '))'), ('[', ']'), ('(', ')'), ('{', '}')]
DESC_START = '**Text description of the diagram above**'
GEN_SUMMARY = re.compile(r'(Flowchart with \d+ items and \d+ connections|Pie chart with \d+ slices|Venn diagram|Bar chart of \d+ categories)')

def node_def(tok):
    tok = tok.strip()
    for o, c in SHAPES:
        i = tok.find(o)
        if i > 0 and tok.endswith(c):
            nid, lab = tok[:i].strip(), tok[i + len(o):-len(c)].strip()
            return nid, lab.strip('"')
    return tok, None

def parse_flowchart(lines):
    labels, groups, order, edges, stack = {}, {}, [], [], []
    for raw in lines:
        l = raw.strip()
        if not l or l.startswith('%%') or re.match(r'(classDef|class|style|linkStyle|direction|flowchart|graph|accTitle|accDescr)\b', l):
            continue
        if l.startswith('subgraph'):
            gid, glab = node_def(l[len('subgraph'):].strip())
            labels[gid] = glab or gid; groups[gid] = []; order.append(gid); stack.append(gid); continue
        if l == 'end':
            stack and stack.pop(); continue
        parts = re.split(ARROW + r'\s*(?:\|"?([^|]*?)"?\|)?', l)
        nodes = []
        for i in range(0, len(parts), 3):
            nid, lab = node_def(parts[i])
            if lab is not None: labels[nid] = lab
            if nid and stack and nid not in groups and nid not in groups[stack[-1]]: groups[stack[-1]].append(nid)
            nodes.append(nid)
        for i in range(1, len(parts) - 1, 3):
            a, arrow, lab = nodes[i // 3], parts[i], (parts[i + 1] or '').strip()
            b = nodes[i // 3 + 1]
            edges.append((a, b, arrow, lab))
    return labels, groups, order, edges

def describe_flowchart(lines):
    labels, groups, order, edges = parse_flowchart(lines)
    name = lambda n: labels.get(n, n)
    out = []
    for g in order:
        if groups[g]:
            out.append(f'- Group "{name(g)}" contains: ' + '; '.join(name(n) for n in groups[g]) + '.')
    for a, b, arrow, lab in edges:
        style = ' (dashed)' if '.' in arrow else ''
        if arrow.startswith('<'):
            s = f'- {name(a)} and {name(b)} are linked both ways{style}'
        else:
            s = f'- {name(a)} points to {name(b)}{style}'
        out.append(s + (f': {lab}.' if lab else '.'))
    summary = f'Flowchart with {sum(1 for n in labels if n not in groups)} items and {len(edges)} connections'
    return summary, out

def describe_pie(lines):
    rows = [(m.group(1), float(m.group(2))) for l in lines if (m := re.match(r'\s*"([^"]+)"\s*:\s*([\d.]+)', l))]
    tot = sum(v for _, v in rows) or 1
    return f'Pie chart with {len(rows)} slices', [f'- {k}: {v:g} ({v / tot * 100:.0f}%).' for k, v in rows]

def describe_xy(lines):
    cats = next((re.findall(r'"([^"]+)"', l) for l in lines if l.strip().startswith('x-axis')), [])
    series = [list(map(float, re.findall(r'[\d.]+', l.split('[', 1)[1]))) for l in lines if re.match(r'\s*(bar|line)\s*\[', l)]
    names = next((l.split(':', 1)[1].split(',') for l in lines if l.strip().startswith('%% series:')), [f'series {i + 1}' for i in range(len(series))])
    names = [n.strip() for n in names]
    out = [f'- {c}: ' + ', '.join(f'{names[j]} {series[j][i]:g}' for j in range(len(series))) + '.' for i, c in enumerate(cats)]
    return f'Bar chart of {len(cats)} categories', out

def describe_venn(lines):
    out, lab = [], {}
    for l in lines:
        s = l.strip()
        if m := re.match(r'set (\w+)(?:\["([^"]*)"\])?(?::([\d.]+))?', s):
            lab[m.group(1)] = m.group(2) or m.group(1)
            out.append(f'- Set {lab[m.group(1)]}' + (f', size {m.group(3)}' if m.group(3) and m.group(3) not in lab[m.group(1)] else '') + '.')
        elif m := re.match(r'union ([\w,]+)(?:\["([^"]*)"\])?(?::([\d.]+))?', s):
            names = ' and '.join(lab.get(x, x) for x in m.group(1).split(','))
            size = m.group(3)
            out.append(f'- Overlap of {names}: ' + ('none.' if size in ('0', '0.0') else f'{m.group(2) or size}.'))
        elif m := re.match(r'text "([^"]*)"', s):
            out.append(f'  - {m.group(1)}')
    return 'Venn diagram', out

KINDS = {'flowchart': describe_flowchart, 'graph': describe_flowchart, 'pie': describe_pie, 'xychart-beta': describe_xy, 'venn-beta': describe_venn}
ACC_OK = {'flowchart', 'graph', 'pie', 'xychart-beta'}

def process(md):
    lines = md.split('\n'); out = []; i = 0; heading = ''; done = 0
    while i < len(lines):
        l = lines[i]
        if re.match(r'#{1,6} ', l) and not out[-1:] == ['```']: heading = l.lstrip('#').strip()
        if l.strip() == '```mermaid':
            j = i + 1
            while lines[j].strip() != '```': j += 1
            body = [b for b in lines[i + 1:j] if not re.match(r'\s*acc(Title|Descr)\b', b)]
            kind_idx = next(k for k, b in enumerate(body) if b.strip() and not b.strip().startswith('%%'))
            kind = body[kind_idx].split()[0]
            title_line = next((b.strip()[6:].strip().strip('"') for b in body if b.strip().startswith('title ')), None)
            summary, desc = KINDS.get(kind, lambda _: ('Diagram', []))(body)
            acc_title = re.sub(r'\s*[:;<>&]\s*', ' - ', title_line or heading or 'Diagram').strip(' -')
            if kind in ACC_OK:
                body = body[:kind_idx + 1] + [f'  accTitle: {acc_title}', f'  accDescr: {summary}. A full text description follows the diagram.'] + body[kind_idx + 1:]
            out += ['```mermaid'] + body + ['```']
            k = j + 1
            # drop an existing generated description
            while k < len(lines) and lines[k].strip() == '': k += 1
            if k < len(lines) and lines[k].strip() == DESC_START:
                k += 1
                while k < len(lines) and lines[k].strip() == '': k += 1
                # one generated summary sentence, then the generated list
                if k < len(lines) and not re.match(r'\s*(- |#|```|\||\*)', lines[k]): k += 1
                while k < len(lines) and (lines[k].strip() == '' or lines[k].lstrip().startswith('- ')): k += 1
            # drop stale copies left by earlier runs: a generated summary sentence followed by its list
            while True:
                k0 = k
                while k < len(lines) and lines[k].strip() == '': k += 1
                if k < len(lines) and GEN_SUMMARY.search(lines[k]) and not lines[k].lstrip().startswith('- '):
                    k += 1
                    while k < len(lines) and (lines[k].strip() == '' or lines[k].lstrip().startswith('- ')): k += 1
                    continue
                k = k0; break
            desc = [re.sub(r'([?!.])\.$', r'\1', d) for d in desc]
            out += ['', DESC_START, '', f'{acc_title.rstrip(".")}. {summary}.', ''] + desc + ['']
            i = k; done += 1; continue
        out.append(l); i += 1
    return '\n'.join(out), done

if __name__ == '__main__':
    for f in sys.argv[1:]:
        t, n = process(open(f).read())
        t = re.sub(r'\n{3,}', '\n\n', t)
        open(f, 'w').write(t)
        print(f'{f}: {n} diagrams given accessible names and text descriptions')
