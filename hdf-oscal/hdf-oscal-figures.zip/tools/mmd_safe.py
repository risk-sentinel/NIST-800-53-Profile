"""Rewrite Mermaid sources so they survive Confluence HTML-encoding: ASCII only, no & < > in labels, no <br/>."""
import re, sys, html
REP = [('<br/>', ' - '), ('·', ','), ('→', 'to'), ('←', 'from'), ('↔', 'matches'), ('…', '...'), ('×', 'x'), ('&', 'and'), ('—', '-'), ('–', '-')]
SYNTAX = re.compile(r'^\s*(classDef|style|class|linkStyle|%%|accTitle|accDescr|title|set|union|text|x-axis|y-axis|bar|line|pie|\"[^\"]*\"\s*:)')
def fix_labels(l):
    if SYNTAX.match(l): return l
    def f(m):
        t = m.group(0)
        t = t.replace('2026-09-28T14:02:00-05:00', '2026-09-28')
        t = t.replace('portal-api:1.8.2', 'portal-api 1.8.2')
        t = re.sub(r' :(\d+)', r' port \1', t)
        t = re.sub(r'(\S) : ', r'\1 - ', t)
        t = re.sub(r'^(["|(\[]*hdf-system): ', r'\1 - ', t)
        t = re.sub(r'(\w[\w.\]-]*)\*', r'\1 (req)', t)
        t = re.sub(r'([\w.\]-]+): ', r'\1 = ', t)
        return t
    return re.sub(r'"[^"]*"|\|[^|]*\|', f, l)
def fix_line(l):
    l = fix_labels(l)
    # protect Mermaid arrow syntax, fix only text
    for a, b in REP: l = l.replace(a, b)
    l = re.sub(r' ,', ',', l); l = re.sub(r' {2,}', ' ', l) if not l.startswith('  ') else re.sub(r'(?<=\S) {2,}', ' ', l)
    return l
def check(text):
    probs = []
    for i, l in enumerate(text.splitlines(), 1):
        if any(ord(c) > 127 for c in l): probs.append((i, 'non-ASCII', l))
        body = re.sub(r'(<-->|-->|-\.->|<-\.->|-\.-|---|==>)', '', l)   # arrows are syntax
        if re.search(r'[<>&]', body): probs.append((i, '<>& in text', l))
        if ';' in l: probs.append((i, 'semicolon', l))
        if not SYNTAX.match(l) and ':' in l: probs.append((i, 'colon in label', l))
        enc = html.escape(body, quote=False)
        if ';' in enc: probs.append((i, 'encodes to ;', l))
    return probs
if __name__ == '__main__':
    for f in sys.argv[1:]:
        t = open(f).read(); n = '\n'.join(fix_line(l) for l in t.splitlines()) + '\n'
        open(f, 'w').write(n)
        p = check(n); print(f, 'OK' if not p else p)
