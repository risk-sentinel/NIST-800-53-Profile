import re, sys, glob
def lum(h):
    h = h.lstrip('#'); h = ''.join(c*2 for c in h) if len(h) == 3 else h
    c = [int(h[i:i+2], 16) / 255 for i in (0, 2, 4)]
    c = [x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4 for x in c]
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]
def tint(h, a):
    # venn-beta paints a set's fill at low opacity over white; text sits on that tint, and the fill colour is the circle outline
    h = h.lstrip('#'); c = [int(h[i:i+2], 16) for i in (0, 2, 4)]
    return '#' + ''.join(f'{round(255 - (255 - x) * a):02x}' for x in c)
def cr(a, b):
    la, lb = sorted([lum(a), lum(b)], reverse=True); return (la + 0.05) / (lb + 0.05)
if __name__ == '__main__':
    fails = 0
    for f in sys.argv[1:]:
        t = open(f).read(); venn = t.lstrip().startswith('venn-beta') or '\nvenn-beta' in t
        for m in re.finditer(r'(classDef \w+|style \w+) ([^\n]+)', t):
            props = dict(p.split(':', 1) for p in m.group(2).split(',') if ':' in p)
            fill = props.get('fill'); stroke = props.get('stroke'); color = props.get('color', '#333333')
            if venn and fill and fill.startswith('#'):
                r = cr(fill, '#ffffff'); ok = r >= 3; fails += not ok
                print(f'{f.split("/")[-1]:32s} {m.group(1):22s} outline {fill} vs white: {r:5.2f} {"ok" if ok else "FAIL 3.0"}')
                fill = tint(fill, 0.1)
            if fill and fill.startswith('#') and color.startswith('#'):
                r = cr(fill, color); ok = r >= 4.5; fails += not ok
                print(f'{f.split("/")[-1]:32s} {m.group(1):22s} text {color} on {fill}: {r:5.2f} {"ok" if ok else "FAIL 4.5"}')
            if stroke and stroke.startswith('#'):
                r = cr(stroke, '#ffffff'); ok = r >= 3; fails += not ok
                print(f'{f.split("/")[-1]:32s} {m.group(1):22s} border {stroke} vs white: {r:5.2f} {"ok" if ok else "FAIL 3.0"}')
        for m in re.finditer(r'"(pie\d)": "(#[0-9a-fA-F]{6})"', t):
            r = cr(m.group(2), '#ffffff'); fails += r < 3; print(f'{f.split("/")[-1]:32s} {m.group(1):22s} slice {m.group(2)} vs white: {r:5.2f} {"ok" if r >= 3 else "FAIL 3.0"}')
        for m in re.finditer(r'plotColorPalette": "([^"]+)"', t):
            cs = [x.strip() for x in m.group(1).split(',')]
            for c in cs:
                r = cr(c, '#ffffff'); fails += r < 3; print(f'{f.split("/")[-1]:32s} {"xychart bar":22s} {c} vs white: {r:5.2f} {"ok" if r >= 3 else "FAIL 3.0"}')
            for a, b in zip(cs, cs[1:]):   # overlaid series: each segment meets the next one
                r = cr(a, b); fails += r < 3; print(f'{f.split("/")[-1]:32s} {"xychart adjacent":22s} {a} vs {b}: {r:5.2f} {"ok" if r >= 3 else "FAIL 3.0"}')
    print('FAILS', fails)
