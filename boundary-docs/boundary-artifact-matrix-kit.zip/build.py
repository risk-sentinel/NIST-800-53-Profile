#!/usr/bin/env python3
"""Build the 800-53A Boundary Artifact Matrix from NIST's OSCAL content.

Standard library only (Python 3.9+). Outputs land in dist/:
  matrix.csv                     one row per determination statement / ODP
  matrix.json                    same rows plus control metadata (pipeline friendly)
  boundary-artifact-matrix.html  single-file offline viewer/editor

Usage:
  python3 build.py                      # fetch NIST files into .cache/ if missing, build
  python3 build.py --offline            # never touch the network (air-gapped)
  python3 build.py --nist-dir ./nist    # use NIST OSCAL JSON you already have
  python3 build.py --tailoring tailoring/  # apply org tailoring (default: ./tailoring)
  python3 build.py --cdn                # load SheetJS from cdnjs instead of inlining vendor/
"""
import argparse, csv, glob, json, os, re, sys, urllib.request
from collections import Counter
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
NIST_BASE = "https://raw.githubusercontent.com/usnistgov/oscal-content/main/nist.gov/SP800-53/rev5/json/"
NIST_FILES = {
    "catalog": "NIST_SP-800-53_rev5_catalog.json",
    "L": "NIST_SP-800-53_rev5_LOW-baseline_profile.json",
    "M": "NIST_SP-800-53_rev5_MODERATE-baseline_profile.json",
    "H": "NIST_SP-800-53_rev5_HIGH-baseline_profile.json",
    "P": "NIST_SP-800-53_rev5_PRIVACY-baseline_profile.json",
}
BL_NAMES = {"L": "Low", "M": "Moderate", "H": "High", "P": "Privacy"}


# ---------------------------------------------------------------- inputs
def load_nist(nist_dir, offline):
    os.makedirs(nist_dir, exist_ok=True)
    out = {}
    for key, fname in NIST_FILES.items():
        path = os.path.join(nist_dir, fname)
        if not os.path.exists(path):
            if offline:
                sys.exit(f"missing {path} (offline mode). Copy the NIST OSCAL JSON files into {nist_dir}.")
            print(f"fetching {fname}")
            urllib.request.urlretrieve(NIST_BASE + fname, path)  # honors HTTPS_PROXY
        with open(path, encoding="utf-8") as fh:
            out[key] = json.load(fh)
    return out


def load_documents(path):
    """config/documents.psv: family|document|note|controls|type|source|owner|oscal"""
    raw = open(path, encoding="utf-8").read().strip()
    cur = {}
    for line in raw.split("\n"):
        f, d, n, cs, t, s, o, x = line.split("|")
        for part in cs.split(","):
            part = part.strip()
            ids = []
            m = re.match(r"([A-Z]{2})-(\d+)\(([\d,\-]+)\)$", part)
            if m:
                for e in m[3].split(","):
                    if "-" in e:
                        a, b = e.split("-")
                        ids += [f"{m[1].lower()}-{int(m[2])}.{i}" for i in range(int(a), int(b) + 1)]
                    else:
                        ids.append(f"{m[1].lower()}-{int(m[2])}.{int(e)}")
            elif " to " in part:
                a, b = part.split(" to ")
                fa = a.split("-")[0].lower()
                ids = [f"{fa}-{i}" for i in range(int(a.split("-")[1]), int(b.split("-")[1]) + 1)]
            else:
                m = re.match(r"([A-Z]{2})-(\d+)(?:\((\d+)\))?", part)
                if m:
                    ids = [f"{m[1].lower()}-{int(m[2])}" + (f".{int(m[3])}" if m[3] else "")]
            for k in ids:
                cur.setdefault(k, []).append(d)
    return raw, cur


def load_tailoring(tdir):
    """Merge every *.json in tailoring/ (sorted by name). Same format as the page's 'Changes only' export."""
    edits = {}
    for path in sorted(glob.glob(os.path.join(tdir, "*.json"))):
        data = json.load(open(path, encoding="utf-8"))
        for sid, e in (data.get("edits") or {}).items():
            if e is None:
                edits.pop(sid, None)
            else:
                e = dict(e); e["id"] = sid
                edits[sid] = e
    return edits


# ---------------------------------------------------------------- classification rules
SYSWORDS = re.compile(r"\bsystem components?\b|\bcomponents?\b|\bwithin the system\b|\bsystem-level\b|\baccounts?\b|\bports?\b|\bprotocols?\b|\bservices\b|\bsoftware\b|\bfirmware\b|\binterfaces?\b|\bevents?\b|\bsettings?\b|\bmechanisms?\b|\bhardware\b")
KIND_RULES = [
    ("Training record", r"\btrained\b|training is provided|training (is|are) (provided|updated|documented|retained|monitored)|training activities|training records"),
    ("Test", r"\btest(ed|s|ing)? (is|are)\b|\bis tested\b|\bare tested\b|\bexercis(ed|es)\b|penetration test"),
    ("Assessment", r"\bassess(ed|ment|ments)\b"),
    ("Review record", r"\breview(ed|s)?\b|\banaly[sz]ed\b|\bupdated\b"),
    ("Inventory", r"\binventor(y|ies)\b"),
    ("Notification / report", r"\bnotif(ied|y|ication)\b|\breport(ed|s)?\b|\balert(ed|s)?\b"),
    ("Approval record", r"\bapprov(ed|al|als)\b|\bsigned\b|\backnowledg|\baccepts?\b|\bauthorizes\b"),
    ("Designation", r"\bdesignat(ed|es)\b|\b(is|are) assigned\b|\bappointed\b"),
    ("Dissemination", r"\bdisseminated\b|\bdistributed\b"),
    ("Agreement", r"\bagreements?\b|\bcontracts?\b"),
    ("Configuration", r"^(the )?(system|information system)\b|automated mechanisms?|\bmechanisms? (is|are)\b|\bthe system (automatically|enforces|prevents|provides|implements|protects|uses|employs|generates|supports|limits|separates|denies|terminates|locks|displays|restricts|isolates|validates|verifies|checks|compares|uniquely|identifies|authenticates|audits|produces|records|retains|maintains|fails|executes|routes|monitors)|cryptographic|\bencrypt|\b(is|are) configured\b|\baudit records\b|\bare logged\b|\bis logged\b|\b(is|are) (enforced|employed|implemented) (by|on|within|in) the system"),
    ("Documentation", r"\bdocumented\b|\bdeveloped\b|\bplan\b|\bdescri(bed|bes)\b|\bspecified\b|\bdefined\b|\bidentified\b|\bdetermined\b|\bcategorized\b"),
]
TECH_FAMILIES = {"ac", "au", "ia", "sc", "si"}
TECH_CONTROLS = {"cm-5", "cm-6", "cm-7", "cm-11", "cm-14", "cp-9", "cp-10", "mp-4"}


def kind_of(tl, tech):
    for k, rx in KIND_RULES:
        if re.search(rx, tl):
            return k
    if tech and not re.search(r"in accordance with|\bprocess(es)?\b|\bprocedures?\b|personnel", tl):
        return "Configuration"
    return "Process record"


class Classifier:
    def __init__(self, cfg, cur):
        self.cfg, self.cur, self.party = cfg, cur, cfg["parties"]
        self.ent = {}
        for label, ids in cfg["enterprise_services"].items():
            for i in ids:
                self.ent[i] = label

    def doc_for(self, k, cid, title, prefix=""):
        cur = self.cur.get(cid) or self.cur.get(cid.split(".")[0])
        primary = cur[0] if cur else None
        T = title
        m = {"Training record": "Training completion records",
             "Test": f"{T}: test plan and results",
             "Assessment": primary or f"{T}: assessment report",
             "Review record": f"{T}: review records",
             "Notification / report": f"{T}: notification / report records",
             "Designation": "Designation / appointment memo",
             "Approval record": f"{T}: approval records",
             "Dissemination": "Distribution / acknowledgment records",
             "Agreement": primary if primary and re.search("agreement|contract|SLA", primary, re.I) else f"{T}: contract / agreement clauses",
             "Inventory": primary if primary and "inventor" in primary.lower() else f"{T}: inventory",
             "Documentation": primary or f"SSP implementation statement: {T}",
             "Configuration": f"{T}: configuration export / scan evidence",
             "Process record": f"{T}: procedure and execution records"}
        return prefix + m[k] if prefix and k == "Documentation" and not primary else m[k]

    def classify(self, fam, num, cid, title, famname, t, is_odp):
        """Returns (evidence kind, comes-from, party code, evidence artifact)."""
        base_id = cid.split(".")[0]
        tech = fam in TECH_FAMILIES or base_id in TECH_CONTROLS
        tl = t.lower()
        is_base = re.match(r"[a-z]{2}-\d+$", cid) is not None
        if is_odp:
            if num == 1:
                if "designat" in tl or "official" in tl:
                    return ("Parameter (ODP)", "Org policy", "O", "Policy: designated official named")
                return ("Parameter (ODP)", "Org policy", "P" if fam == "pt" else ("PM" if fam == "pm" else "O"), f"{famname} policy (defines the value)")
            if fam == "pm": return ("Parameter (ODP)", "Org policy", "PM", "Org program plan / strategy")
            if fam == "pe": return ("Parameter (ODP)", "Org policy", "F", "Facility / physical security standard")
            if fam == "pt": return ("Parameter (ODP)", "Org policy", "P", "Privacy program policy / SORN")
            if fam == "ps": return ("Parameter (ODP)", "Org policy", "H", "Personnel security policy")
            if SYSWORDS.search(tl): return ("Parameter (ODP)", "Shared", "S", "Org standard sets floor; SSP parameter table records system value")
            return ("Parameter (ODP)", "Org policy", "O", "Org policy / standard; restated in SSP parameter table")
        if num == 1 and is_base:
            owner = "P" if fam == "pt" else ("PM" if fam == "pm" else "O")
            if "designated to manage" in tl: return ("Designation", "Org policy", "OFF", "Designation memo / delegation of authority")
            if "procedures" in tl and ("reviewed" in tl or "updated" in tl): return ("Review record", "Shared", "S", f"{famname} procedures: review/update history")
            if "policy" in tl and ("reviewed" in tl or "updated" in tl): return ("Review record", "Org policy", owner, f"{famname} policy: review/update history")
            if "procedures" in tl and "disseminated" in tl: return ("Dissemination", "Shared", "S", f"{famname} procedures: distribution record")
            if "policy" in tl and "disseminated" in tl: return ("Dissemination", "Org policy", owner, f"{famname} policy: distribution record")
            if "procedures" in tl: return ("Procedure", "Shared", "S", f"{famname} procedures (system-specific)")
            return ("Policy", "Org policy", owner, f"{famname} policy")
        k = kind_of(tl, tech)
        if fam == "pm":
            return (k, "Org policy", "P" if ("privacy" in tl or "personally identifiable" in tl) else "PM", self.doc_for(k, cid, title, "Org program "))
        if fam == "pe":
            return (k, "Common control", "F", self.doc_for(k, cid, title))
        src, party = "Boundary", "S"
        if "developer" in tl: party = "D"
        elif re.search(r"\bsuppliers?\b|\bcontracts?\b|\bacquisition\b|\bvendors?\b", tl): src, party = "Shared", "Q"
        if base_id == "ca-6" or "authorizing official" in tl: party = "A"
        if base_id in ("ca-2", "ca-8") and k in ("Assessment", "Test"): party = "X"
        if fam == "at": src = "Shared"; party = "T" if base_id in ("at-2", "at-4") else "S"
        if fam == "ir": src = "Shared"; party = "E" if base_id in ("ir-4", "ir-5", "ir-6", "ir-7") or k != "Configuration" else "S"
        if fam == "ps": src, party = ("Shared", "S") if re.search(r"\baccess\b|\bsystem\b|\baccounts?\b|\bauthenticators?\b", tl) else ("Org policy", "H")
        if fam == "pt" or re.search(r"personally identifiable|\bpii\b|privacy (notice|act|officer|program|impact)|system of records", tl):
            if fam == "pt" or k != "Configuration":
                src = "Shared" if src == "Boundary" else src
                party = "P" if party == "S" else party
        if fam == "sr" and party == "S" and k != "Configuration": src = "Shared"
        if base_id in ("au-6", "si-4") and k != "Configuration": src, party = "Shared", "E"
        if base_id in ("ia-12", "sc-17", "si-8"): src, party = "Common control", "C"
        if base_id in ("cp-6", "cp-7", "cp-8"): src = "Shared"
        if k == "Designation" and re.search(r"official|senior|executive|officer", tl): src = "Org policy"
        return (k, src, party, self.doc_for(k, cid, title))

    def provider(self, fam, cid, num, k, src, is_odp, tl):
        b = cid.split(".")[0]
        csp = self.cfg["csp"]
        if src == "Org policy" and (is_odp or num == 1): return "Organization (policy)"
        if fam == "pm": return "Organization (program)"
        if fam in csp["inherited_families"] or b in csp["inherited_controls"] or cid in csp["inherited_controls"]:
            return csp["label_inherited"]
        p = self.ent.get(cid) or self.ent.get(b)
        if p:
            for rule in self.cfg.get("boundary_plus_rules", []):
                if b in rule["controls"] or cid in rule["controls"]:
                    if "when_text_matches" in rule and re.search(rule["when_text_matches"], tl): return "Boundary + " + p
                    if k in rule.get("when_evidence_kind_in", []): return "Boundary + " + p
            return p
        if b in csp["shared_controls"] or cid in csp["shared_controls"]: return csp["label_shared"]
        if src == "Org policy": return "Organization (policy)"
        if src == "Common control": return "Enterprise: common control"
        return "Boundary"


# ---------------------------------------------------------------- OSCAL walking
def label(p):
    for pp in p.get("props", []):
        if pp["name"] == "label": return pp["value"]
    return ""


def leaves(p):
    ch = [q for q in p.get("parts", []) if q["name"] == "assessment-objective"]
    if not ch: return [p]
    out = [p] if p.get("prose") else []
    for q in ch: out += leaves(q)
    return out


def param_labels(params):
    m = {}
    for p in params:
        lab = p.get("label")
        if "select" in p:
            lab = "Selection: " + "; ".join(re.sub(r"\{\{[^}]*\}\}", "…", x) for x in p["select"].get("choice", []))
        m[p["id"]] = lab or p["id"]
    return m


def resolve(t, pm):
    return re.sub(r"\{\{\s*insert:\s*param,\s*([^ }]+)\s*\}\}", lambda x: "‹" + pm.get(x[1], x[1]) + "›", t or "")


def build_rows(nist, clf, cur):
    bl = {}
    for code in ("L", "M", "H", "P"):
        for imp in nist[code]["profile"]["imports"]:
            for inc in imp.get("include-controls", []):
                for i in inc["with-ids"]:
                    bl[i] = bl.get(i, "") + code
    fams, ctls, rows = {}, [], []

    def walk(ctl, fam, famname, parent=None):
        if any(pp["name"] == "status" and pp["value"] == "withdrawn" for pp in ctl.get("props", [])): return
        cid, title = ctl["id"], ctl["title"]
        num = int(re.match(r"[a-z]+-(\d+)", cid)[1])
        pm = param_labels(ctl.get("params", []))
        ex = ""
        for p in ctl.get("parts", []):
            if p["name"] == "assessment-method" and label(p).endswith("Examine"):
                for q in p.get("parts", []):
                    if q["name"] == "assessment-objects": ex = q.get("prose", "")
        ctls.append({"id": cid, "lab": label(ctl), "t": title, "f": fam, "bl": bl.get(cid, ""),
                     "ex": [re.sub(r"\s+", " ", x).strip().rstrip(".") for x in ex.split("\n") if x.strip()],
                     "cur": cur.get(cid, []), "par": parent})
        for p in ctl.get("params", []):
            l = label(p)
            if "_ODP" not in l: continue
            g = " ".join(x["prose"] for x in p.get("guidelines", []))
            if not g.strip():
                if "select" in p:
                    hm = p["select"].get("how-many", "one")
                    g = ("one or more of" if hm == "one-or-more" else "one of") + " the following is selected: " + "; ".join(p["select"].get("choice", []))
                else:
                    g = (p.get("label") or "value") + " is defined;"
            g = resolve(g, pm)
            k, s, pa, d = clf.classify(fam, num, cid, title, famname, g, True)
            rows.append([cid, l, g, k, s, clf.party[pa], d, clf.provider(fam, cid, num, k, s, True, g.lower())])
        for p in ctl.get("parts", []):
            if p["name"] != "assessment-objective": continue
            for q in leaves(p):
                t = resolve(q.get("prose", ""), pm).strip()
                if not t: continue
                k, s, pa, d = clf.classify(fam, num, cid, title, famname, t, False)
                sid = label(q) or f"{label(ctl)}[{q.get('id', '').split('_obj')[-1].lstrip('.') or 'obj'}]"
                rows.append([cid, sid, t, k, s, clf.party[pa], d, clf.provider(fam, cid, num, k, s, False, t.lower())])
        for sub in ctl.get("controls", []): walk(sub, fam, famname, cid)

    for g in nist["catalog"]["catalog"]["groups"]:
        fams[g["id"]] = g["title"]
        for c in g["controls"]: walk(c, g["id"], g["title"])
    return fams, ctls, rows


# ---------------------------------------------------------------- outputs
def plain(t): return t.replace("‹", "[").replace("›", "]")


def write_outputs(out, fams, ctls, rows, edits, doc_raw, template, xlsx_tag):
    os.makedirs(out, exist_ok=True)
    ci = {c["id"]: c for c in ctls}
    stamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
    cols = ["Family", "Control", "Control title", "Baselines", "Subpart / ODP", "Determination statement", "Evidence kind",
            "Evidence artifact", "Comes from", "Responsible party", "Likely provider", "Notes", "Tailored"]
    recs = []
    for r in rows:
        e = edits.get(r[1]) or {}
        recs.append({"control": ci[r[0]]["lab"], "subpart": r[1], "type": "odp" if "_ODP" in r[1] else "objective",
                     "statement": plain(r[2]), "evidence_kind": r[3], "evidence": e.get("e") or r[6],
                     "comes_from": e.get("s") or r[4], "responsible_party": e.get("p") or r[5],
                     "likely_provider": e.get("v") or r[7], "notes": e.get("n", ""), "tailored": bool(e), "_cid": r[0]})
    with open(os.path.join(out, "matrix.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh); w.writerow(cols)
        for x in recs:
            c = ci[x["_cid"]]
            w.writerow([fams[c["f"]], c["lab"], c["t"], " ".join(BL_NAMES[b] for b in c["bl"]), x["subpart"], x["statement"],
                        x["evidence_kind"], x["evidence"], x["comes_from"], x["responsible_party"], x["likely_provider"],
                        x["notes"], "yes" if x["tailored"] else ""])
    with open(os.path.join(out, "matrix.json"), "w", encoding="utf-8") as fh:
        json.dump({"source": "NIST SP 800-53A Rev 5 (OSCAL catalog and baselines)", "built": stamp,
                   "controls": [{"id": c["lab"], "oscal_id": c["id"], "title": c["t"], "family": fams[c["f"]],
                                 "baselines": [BL_NAMES[b] for b in c["bl"]], "examine": c["ex"], "primary_artifacts": c["cur"]} for c in ctls],
                   "rows": [{k: v for k, v in x.items() if k != "_cid"} for x in recs]}, fh, indent=1, ensure_ascii=False)
    data = json.dumps({"fams": fams, "ctls": ctls, "rows": rows}, separators=(",", ":"), ensure_ascii=False).replace("</", "<\\/")
    baked = json.dumps(edits, separators=(",", ":"), ensure_ascii=False).replace("</", "<\\/")
    html = template.replace("__DATA__", data).replace("__BAKED__", baked).replace("__DOCRAW__", doc_raw.replace("`", "'")).replace("__XLSX__", xlsx_tag)
    if not html.lstrip().lower().startswith("<!doctype"):
        html = ('<!doctype html>\n<html lang="en"><head><meta charset="utf-8">'
                '<meta name="viewport" content="width=device-width,initial-scale=1"></head><body>\n' + html + "\n</body></html>\n")
    with open(os.path.join(out, "boundary-artifact-matrix.html"), "w", encoding="utf-8") as fh:
        fh.write(html)
    return len(html)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--nist-dir", default=os.path.join(HERE, ".cache", "nist"))
    ap.add_argument("--config", default=os.path.join(HERE, "config", "providers.json"))
    ap.add_argument("--documents", default=os.path.join(HERE, "config", "documents.psv"))
    ap.add_argument("--tailoring", default=os.path.join(HERE, "tailoring"))
    ap.add_argument("--out", default=os.path.join(HERE, "dist"))
    ap.add_argument("--offline", action="store_true", help="fail instead of downloading NIST files")
    ap.add_argument("--cdn", action="store_true", help="load SheetJS from cdnjs instead of inlining vendor/xlsx.full.min.js")
    a = ap.parse_args()

    nist = load_nist(a.nist_dir, a.offline)
    doc_raw, cur = load_documents(a.documents)
    cfg = json.load(open(a.config, encoding="utf-8"))
    fams, ctls, rows = build_rows(nist, Classifier(cfg, cur), cur)
    known = {r[1] for r in rows}
    edits = load_tailoring(a.tailoring)
    unknown = [k for k in edits if k not in known]
    for k in unknown: edits.pop(k)

    vendor = os.path.join(HERE, "vendor", "xlsx.full.min.js")
    if not a.cdn and os.path.exists(vendor):
        xlsx_tag = "<script>" + open(vendor, encoding="utf-8").read().replace("</script", "<\\/script") + "</script>"
    else:
        xlsx_tag = '<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>'
    size = write_outputs(a.out, fams, ctls, rows, edits, doc_raw,
                         open(os.path.join(HERE, "web", "template.html"), encoding="utf-8").read(), xlsx_tag)

    print(f"{len(ctls)} controls, {len(rows)} rows ({sum('_ODP' in r[1] for r in rows)} ODPs)")
    print(f"tailoring: {len(edits)} rows applied" + (f", {len(unknown)} unknown ids skipped: {unknown[:5]}" if unknown else ""))
    print("by source:", dict(Counter(r[4] for r in rows)))
    print(f"wrote {a.out}/matrix.csv, matrix.json, boundary-artifact-matrix.html ({size/1e6:.1f} MB)")


if __name__ == "__main__":
    main()
