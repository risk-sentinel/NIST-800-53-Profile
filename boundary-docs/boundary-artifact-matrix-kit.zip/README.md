# Boundary Artifact Matrix

Every NIST SP 800-53A Rev 5 determination statement and organization-defined parameter (ODP), mapped to:

- **Evidence**: the kind of evidence and the artifact that satisfies it
- **Comes from**: Org policy, Boundary, Shared, or Common control
- **Responsible party**: policy owner, designated official, AO, system owner/ISSO, SOC, HR, and so on
- **Likely provider**: CSP (inherited), CSP + boundary, an enterprise service, the organization, or the boundary

Statement ids, statement text, ODPs, baselines, and examine objects come straight from NIST's OSCAL content. The evidence, source, party, and provider columns are rule-based defaults. Tailor them to your inheritance model.

## Build

Requires Python 3.9 or later. No third-party packages.

```bash
python3 build.py              # downloads the 5 NIST OSCAL files into .cache/nist on first run
python3 build.py --offline    # air-gapped: put the files in .cache/nist yourself (or --nist-dir PATH)
```

Outputs in `dist/`:

| File | Use |
|---|---|
| `matrix.csv` | Spreadsheets, GRC import, diffing in git |
| `matrix.json` | Pipelines. Rows plus control metadata (baselines, examine objects, primary artifacts) |
| `boundary-artifact-matrix.html` | Single-file viewer and editor. Opens from disk with no server and no network. Excel export is inlined from `vendor/` |

## Tailor it

There are two layers. Both are plain JSON, so they diff and review cleanly.

1. **`config/providers.json`**: organization-wide defaults. Which controls your CSP fully covers or shares, which enterprise services (identity, SOC, PKI, LMS, HR…) cover which controls, and the party names you use. Change a mapping here and every affected row updates on the next build.
2. **`tailoring/*.json`**: row-level decisions. Files merge in name order, so a system can layer on top of an org baseline:
   ```
   tailoring/00-org-baseline.json
   tailoring/10-aws-govcloud-inheritance.json
   tailoring/20-system-xyz.json
   ```
   The format is exactly what the page's **Export → Changes only** button produces. Edit in the page, export, drop the file here, commit, rebuild.

   ```json
   {"format": "800-53a-matrix-edits/v1",
    "edits": {"AU-08a.": {"v": "CSP + boundary (shared)", "n": "Time sync from the CSP"}}}
   ```
   Fields: `s` Comes from, `p` Responsible party, `v` Likely provider, `e` Evidence artifact, `n` Notes. Setting an id to `null` in a later file drops an earlier edit. Unknown ids are reported and skipped.

`config/documents.psv` holds the document-level list (family | document | note | controls | type | source | owner | OSCAL home) that feeds the "By document" tab and each control's primary artifact.

## Round trip

```
edit in the HTML page  ->  Export "Changes only"  ->  tailoring/NN-name.json  ->  git commit  ->  CI rebuilds dist/
edit in Excel          ->  Import changes (page)  ->  Export "Changes only"   ->  same as above
```

Edits made in the standalone HTML are kept in that browser only until you export them. The committed `tailoring/` files are the source of truth.

## Updating when NIST publishes errata

Delete `.cache/nist/` (or let the scheduled CI job refresh it) and rebuild. Tailoring is keyed by 800-53A subpart id, so it carries forward. The build lists any ids that no longer exist.

## Layout

```
build.py                 build script (stdlib only)
config/providers.json    org-level provider and party mappings
config/documents.psv     document-level list
tailoring/               row-level edits, merged in name order
web/template.html        page template (data injected at build)
vendor/xlsx.full.min.js  SheetJS 0.18.5 (Apache-2.0), inlined for offline Excel export; --cdn to skip
.gitlab-ci.yml           rebuild on change, publish dist/ as job artifacts
```
